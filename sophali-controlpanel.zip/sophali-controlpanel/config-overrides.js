const { override, addLessLoader, addWebpackPlugin, addBabelPlugin, babelInclude } = require('customize-cra');
const path = require('path');
const webpack = require('webpack');

module.exports = override(
  // Include specific node_modules package for transpilation by Babel
  babelInclude([
    path.resolve('src'), // Ensure your source files are included
    path.resolve('node_modules/ml-matrix') // Include ml-matrix for transpilation
  ]),
  addLessLoader({
    javascriptEnabled: true,
  }),
  addWebpackPlugin(new webpack.DefinePlugin({
    'process.env.VERSION': JSON.stringify(require('./package.json').version),
  })),
  addBabelPlugin(['@babel/plugin-proposal-class-properties', { "loose": true }]),
  addBabelPlugin(['@babel/plugin-proposal-private-methods', { "loose": true }]),
  addBabelPlugin(['@babel/plugin-proposal-private-property-in-object', { "loose": true }]),
  config => {
    config.resolve.alias = {
      ...config.resolve.alias,
      assets: path.resolve(__dirname, 'src/assets'), // Define 'assets' alias
      components: path.resolve(__dirname, 'src/components'),
      styles: path.resolve(__dirname, 'src/styles'),
      util: path.resolve(__dirname, 'src/util'),


    };
    return config;
  }
);
