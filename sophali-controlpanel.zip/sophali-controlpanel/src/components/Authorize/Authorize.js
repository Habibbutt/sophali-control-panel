import React from "react";
class Authorize extends React.Component {
  render() {
    const { moduleId, permissions, children } = this.props;
    let userHasPermissions = localStorage.getItem("userPermissions");
    userHasPermissions = JSON.parse(userHasPermissions);
    userHasPermissions = userHasPermissions.filter(
      (ele) => ele.permission_id === moduleId
    );
    if (permissions == "can_read" && userHasPermissions[0].can_read) {
      return <>{children}</>;
    }
    if (permissions == "can_create" && userHasPermissions[0].can_create) {
      return <>{children}</>;
    }
    if (permissions == "can_delete" && userHasPermissions[0].can_delete) {
      return <>{children}</>;
    }
    if (permissions == "can_update" && userHasPermissions[0].can_update) {
      return <>{children}</>;
    }
    return null;
  }
}
export default Authorize;
