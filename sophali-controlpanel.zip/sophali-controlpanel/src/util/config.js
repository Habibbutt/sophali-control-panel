const moment = require('moment');

module.exports = {
  footerText: `Copyright Sophali © ${moment().format('YYYY')}`,
}
