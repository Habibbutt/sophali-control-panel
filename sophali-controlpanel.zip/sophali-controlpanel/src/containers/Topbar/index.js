import React, { useState, useEffect } from "react";
import Pusher from "pusher-js";
import { Layout, Badge } from "antd";
import axios from "axios";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUsers,
  faChartBar,
  faBoxOpen,
  faDollarSign,
  faShoppingCart,
  faUtensils,
} from "@fortawesome/free-solid-svg-icons";

const { Header } = Layout;

const basePath = process.env.REACT_APP_API_URL;
const TopBar = () => {
  const [orderCount, setOrderCount] = useState(0);

  let userId = localStorage.getItem("userId");
  useEffect(() => {
    const pusher = new Pusher("d25a6a9053d2a026b528", {
      cluster: "ap2",
    });

    const channel = pusher.subscribe("merchant");

    channel.bind(`count-${userId}`, (data) => {
      console.log(`🚀🚀🚀  data:`, data);
      getOrderCount(userId);
    });

    return () => {
      channel.unsubscribe();
    };
  }, [userId, orderCount]);
  useEffect(() => {
    const merchantId = localStorage.getItem("userId");
    if (merchantId) getOrderCount(merchantId);
  }, []);
  const getOrderCount = async (merchantId) => {
    try {
      const res = await axios.get(
        `${basePath}/orders/get-order-count?merchant_id=${merchantId}`
      );
      setOrderCount(res.data.orderCount);
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <>
      <Header>
        {[
          {
            label: "icon1",
            text: "KITCHEN ORDERING BOARD (KOB)",
            Icon: faShoppingCart,
            to: "/merchantOrder",
            count: orderCount,
          },
          {
            label: "icon2",
            text: "TRANSACTIONS",
            Icon: faDollarSign,
            to: "/merchantAnalytics",
            count: 0,
          },
          {
            label: "icon3",
            text: "MENU",
            Icon: faUtensils,
            to: "/menu",
            count: 0,
          },
          {
            label: "icon4",
            text: "CHECKED-IN USERS",
            Icon: faUsers,
            to: "/checkedInUsers",
            count: 0,
          },
          {
            label: "icon5",
            text: "COUPONS",
            Icon: faBoxOpen,
            to: "/coupons",
            count: 0,
          },
          {
            label: "icon6",
            text: "ANALYTICS",
            Icon: faChartBar,
            to: "/merchantAnalytics",
            count: 0,
          },
        ].map(({ label, text, Icon, to, count, Func }) => (
          <Link
            key={label}
            to={to + (text === "TRANSACTIONS" ? "#transactions" : "")}
            onClick={Func}
            className="topbar-link"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              textAlign: "center",
            }}
          >
            <Badge
              className="my-badge"
              count={count}
              style={{
                marginBottom: 5,
                display: "flex",
                justifyContent: "center",
                overflow: "visible",
              }}
            >
              <FontAwesomeIcon
                icon={Icon}
                style={{ fontSize: "28px", margin: "0 auto" }}
              />
            </Badge>
            <div style={{ marginTop: 4 }}>{text}</div>
          </Link>
        ))}
      </Header>
    </>
  );
};

export default TopBar;
