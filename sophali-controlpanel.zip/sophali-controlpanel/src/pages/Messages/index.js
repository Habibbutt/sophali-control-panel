import { Button, Form, Input, Select } from "antd";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useSnackbar } from "notistack";
const { TextArea } = Input;

const basePath = process.env.REACT_APP_API_URL;

const Messages = () => {
  const [parent_id, setParentId] = useState();
  const [users, setUsers] = useState([]);
  const [user, setUser] = useState();
  const [message, setMessage] = useState();
  const { enqueueSnackbar } = useSnackbar();
  useEffect(() => {
    let parentId = localStorage.getItem("userId");
    if (
      localStorage.getItem("parent_merchant_id") &&
      localStorage.getItem("userTypeId") === "4"
    ) {
      parentId = localStorage.getItem("parent_merchant_id");
    }
    setParentId(parentId);
  }, []);
  async function fetchUsers() {
    const res = await axios.get(
      `${basePath}/users/subscribe-user-list/${parent_id}`
    );

    setUsers(res.data.userList.filter((e) => !e.checkout_date));
  }
  async function sendMessage() {
    try {
      const res = await axios.post(`${basePath}/send-message`, {
        user_id: user,
        message,
        merchant_name: localStorage.getItem("merchant_name"),
      });
      console.log(`🚀🚀🚀  res:`, res);
      enqueueSnackbar("Message sent successfully", { variant: "success" });
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });

      console.error(error);
    }
  }

  const [form] = Form.useForm();

  useEffect(() => {
    if (parent_id) {
      fetchUsers();
    }
  }, [parent_id]);

  return (
    <div>
      <h1>Message</h1>
      <Form
        form={form}
        layout="vertical"
        onFinish={async () => {
          await sendMessage();
          form.resetFields(); // Replace form.setFieldsValue() with form.resetFields()
          setMessage("");
          setUser("");
        }}
        // initialValues={setting}
      >
        {/* Select User Dropdown */}
        <Form.Item
          label="Select User"
          name="user_id"
          rules={[{ required: true, message: "Please select user!" }]}
        >
          <Select
            showSearch
            placeholder="Select User"
            optionFilterProp="children"
            onChange={(value) => {
              console.log(`🚀🚀🚀  value:`, value);
              setUser(value);
            }}
            value={user}
            // onFocus={onFocus}
            // onBlur={onBlur}
            // onSearch={onSearch}
            filterOption={(input, option) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
          >
            {users.map((user) => (
              <Select.Option key={user.id} value={user.id}>
                {user.screenName
                  ? user.screenName
                  : user.first_name + " " + user.last_name}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>

        {/* Message should be text area or something */}
        <Form.Item
          label="Message"
          name="message"
          rules={[{ required: true, message: "Please enter message!" }]}
          value={message}
          onChange={(e) => {
            console.log(`🚀🚀🚀  e:`, e.target.value);
            setMessage(e.target.value);
          }}
        >
          <TextArea />
        </Form.Item>

        {/* Submit */}
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Send
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default Messages;
