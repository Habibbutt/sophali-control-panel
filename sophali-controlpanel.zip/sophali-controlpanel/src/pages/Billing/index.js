import React, { useEffect, useState } from "react";
import { Button, Input } from "antd";
import OrderTable from "./orders";
import TopupTable from "./topup";
import GiftTable from "./GiftAmount";
import WithdrawlTable from "./withdrawl";
import SubscribeTable from "./Subscription";
import axios from "axios";

const App = () => {
  const [activeButton, setActiveButton] = useState("orders");
  const [searchText, setSearchText] = useState("");
  const [orderdata, setOrderData] = useState({});
  const [tabData, setTabData] = useState({
    list: [],
    total: 0,
    revenue: 0,
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const basePath = process.env.REACT_APP_API_URL;
        const response = await axios.get(`${basePath}/admin/billings`);
        setOrderData(response?.data?.data);
        updateTabData(response?.data?.data, activeButton);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [activeButton]);

  const updateTabData = (data, button) => {
    const selectedData = data[button] || {};
    setTabData({
      list: selectedData?.list || [],
      total: selectedData?.total || 0,
      revenue: selectedData?.revenue || 0,
    });
  };

  const handleButtonClick = (button) => {
    setActiveButton(button?.table_name);
    setSearchText("");
    updateTabData(orderdata, button.table_name);
  };

  // This function dynamically generates the placeholder text based on the active button
  const getSearchPlaceholder = () => {
    switch (activeButton) {
      case "orders":
        return "Search by Name or Purchase ID";
      case "topUps":
        return "Search by Username or U_receipt";
      case "gifts":
        return "Search by Sender Name or GiftID";
      case "withdrawals":
        return "Search by Merchant";
      case "subscriptions":
        return "Search by SubscriberName";
      default:
        return "Search...";
    }
  };

  const renderTableComponent = () => {
    const commonProps = { data: tabData?.list, searchText };
    switch (activeButton) {
      case "orders":
        return <OrderTable {...commonProps} />;
      case "topUps":
        return <TopupTable {...commonProps} />;
      case "gifts":
        return <GiftTable {...commonProps} />;
      case "withdrawals":
        return <WithdrawlTable {...commonProps} />;
      case "subscriptions":
        return <SubscribeTable {...commonProps} />;
      default:
        return null;
    }
  };

  const buttonData = [
    {
      displayName: "Orders",
      table_name: "orders",
      t_amount: `$${parseFloat(orderdata?.orders?.total||0).toFixed(2)}`,
      r_amount: `$${parseFloat(orderdata?.orders?.revenue||0).toFixed(2)}`,
      desc: "Orders Rev.",
    },
    {
      displayName: "Topup",
      table_name: "topUps",
      t_amount: `$${parseFloat(orderdata?.topUps?.total||0).toFixed(2)}`,
      r_amount: `$${parseFloat(orderdata?.topUps?.revenue||0).toFixed(2)}`,
      desc: "Topup Rev.",
    },
    {
      displayName: "Gift Amount",
      table_name: "gifts",
      t_amount: `$${parseFloat(orderdata?.gifts?.total||0).toFixed(2)}`,
      r_amount: `$${parseFloat(orderdata?.gifts?.revenue||0).toFixed(2)}`,
      desc: "Gift Rev.",
    },
    {
      displayName: "Subscription",
      table_name: "subscriptions",
      t_amount: `$${parseFloat(orderdata?.subscriptions?.total||0).toFixed(2)}`,
      r_amount: `$${parseFloat(orderdata?.subscriptions?.revenue||0).toFixed(2)}`,
      desc: "Subscrip. Rev.",
    },
    {
      displayName: "Withdrawal",
      table_name: "withdrawals",
      t_amount: `$${parseFloat(orderdata?.withdrawals?.total||0).toFixed(2)}`,
      r_amount: `$${parseFloat(orderdata?.withdrawals?.revenue||0).toFixed(2)}`,
      desc: "Withdraw Rev.",
    },
  ];

  return (
    <div className="app" style={{ display: "flex", flexDirection: "column" }}>
      <div
        className="topbar"
        style={{
          display: "flex",
          justifyContent: "space-between",
          // alignItems: "center",
          width: "100%",
        }}
      >
        <h1>Billing</h1>
        <Input
          placeholder={getSearchPlaceholder()}
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          style={{ width: "250px" }}
        />
      </div>
      <div
        className="button-card-container"
        style={{ display: "flex", flexWrap: "wrap", paddingTop: "10px" }}
      >
        {buttonData.map((button, index) => (
          <div
            key={index}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              flexGrow: 1,
              minWidth: "180px",
              /* Adjusted minWidth for consistency */ margin: "10px",
            }}
          >
            <Button
              type="default"
              style={{
                width: "100%",
                height: "80px" /* Adjusted height for consistency */,
                backgroundColor:
                  activeButton === button.table_name
                    ? "green"
                    : "transparent",
                color: activeButton === button.table_name ? "white" : "black",
                border:
                  activeButton === button.table_name
                    ? "2px solid green"
                    : "1px solid black",
                textAlign: "center",
                fontSize: "20px",
              }}
              onClick={() => handleButtonClick(button)}
            >
              {button?.displayName}
              <div>{button?.t_amount}</div>
            </Button>
            <div
              className="card"
              style={{
                width: "100%",
                height: "80px" /* Made card height equal to button height */,
                border:
                  activeButton === button?.table_name
                    ? "2px solid green"
                    : "1px solid black",
                borderRadius: "10px",
                paddingTop: "18px",
                textAlign: "center",
                marginTop: "5px",
                alignItems: "flex-start",
              }}
            >
              <h3>{button?.r_amount}</h3>
              <h4>{button?.desc}</h4>
            </div>
          </div>
        ))}
      </div>
      {activeButton !== null && renderTableComponent()}
    </div>
  );
};

export default App;
