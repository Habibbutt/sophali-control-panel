import React, { useEffect, useState } from "react";

import { Button, Form, InputNumber, Modal, Table } from "antd";
import axios from "axios";
import { EyeOutlined } from "@ant-design/icons";
import { useSnackbar } from "notistack";

const CheckedInUsers = () => {
  const [users, setUsers] = useState([]);
  const basePath = process.env.REACT_APP_API_URL;
  let parent_id;
  if (
    localStorage.getItem("parent_merchant_id") &&
    localStorage.getItem("userTypeId") == 4
  ) {
    parent_id = localStorage.getItem("parent_merchant_id");
  } else {
    parent_id = localStorage.getItem("userId");
  }
  async function fetchUsers() {
    const res = await axios.get(
      `${basePath}/users/subscribe-user-list/${parent_id}`
    );
    res.data.userList.forEach((e) => {
      e.name = e.screenName ? e.screenName : e.first_name + " " + e.last_name;
    });

    setUsers(res.data.userList);
  }
  useEffect(() => {
    fetchUsers();
  }, []);
  // const [balance, setBalance] = useState(0);
  // const [token, setToken] = useState(null);
  // const [details, setDetails] = useState(null);
  // const [open, setOpen] = useState(false);
  // const [openDetail, setOpenDetail] = useState(false);
  // const { enqueueSnackbar } = useSnackbar();
  // const [qrModalOpen, setQrModalOpen] = useState(false);

  // const fetchTokens = async () => {
  //   try {
  //     let result;
  //     if (localStorage.getItem("userTypeId") == 3) {
  //       result = await axios.get(
  //         `${basePath}/merchants/merchant-consumed-token?merchant_id=${localStorage.getItem(
  //           "userId"
  //         )}`
  //       );
  //     } else {
  //       result = await axios.get(
  //         `${basePath}/admin/admin-token-balance?user_id=${localStorage.getItem(
  //           "userId"
  //         )}`
  //       );
  //     }
  //     console.log(`🚀🚀🚀  result:`, result);
  //     let res = await axios.get(
  //       `${basePath}/merchants/merchant-token-balance?user_id=${localStorage.getItem(
  //         "userId"
  //       )}`
  //     );
  //     console.log(`🚀🚀🚀  res:`, res);
  //     setBalance(res.data.balance);
  //     let arr = [];
  //     let array = result.data.merchantEarnedToken
  //       ? result.data.merchantEarnedToken
  //       : result.data.adminTokenBalance;
  //     array.forEach((element) => {
  //       arr.push({
  //         id: element.id,
  //         date: element.createdAt,
  //         sophali_tokens: element.sophali_tokens,
  //         amount_usd: element.amount_usd,
  //         status: element.status,
  //       });
  //     });
  //     setTokens(arr.reverse());
  //   } catch (error) {
  //     enqueueSnackbar(error.response.data.message, { variant: "error" });
  //     console.error(error);
  //   }
  // };
  // useEffect(() => {
  //   fetchTokens();
  // }, []);

  // const handleCreate = async (values) => {
  //   let obj = {
  //     amount_usd: values.amount_tokens / 5,
  //     sophali_tokens: values.amount_tokens,
  //     user_id: localStorage.getItem("userId"),
  //     helcium_transation_id: new Date().getTime(),
  //     status: "active",
  //   };
  //   try {
  //     await axios.post(`${basePath}/usertoken/add`, obj);
  //     enqueueSnackbar("Tokens topped up successfully", {
  //       variant: "success",
  //     });
  //   } catch (error) {
  //     enqueueSnackbar(error.response.data.message, { variant: "error" });
  //   } finally {
  //     setOpen(false);
  //     setToken(null);
  //     fetchTokens();
  //   }
  // };
  // const handleWithdraw = async (values) => {
  //   let obj = {
  //     amount_usd: values.amount_tokens / 5,
  //     sophali_tokens: values.amount_tokens,
  //     sophali_token_balance: values.amount_tokens * 5, // token.sophali_tokens_balance,
  //     helcium_transation_id: new Date().getTime(),
  //     status: "active",
  //   };
  //   if (localStorage.getItem("userTypeId") == 1) {
  //     obj.user_id = localStorage.getItem("userId");
  //   } else {
  //     obj.merchant_id = localStorage.getItem("userId");
  //   }

  //   try {
  //     await axios.post(`${basePath}/merchants/withdraw-token`, obj);
  //     enqueueSnackbar("Tokens withdrawn successfully", {
  //       variant: "success",
  //     });
  //   } catch (error) {
  //     enqueueSnackbar(error.response.data.message, { variant: "error" });
  //   } finally {
  //     setOpen(false);
  //     setToken(null);
  //     fetchTokens();
  //   }
  // };

  const columns = [
    {
      title: "Check In Date",
      dataIndex: "checkin_date",
      key: "checkin_date",
      render: (text) => {
        return new Date(text).toLocaleString();
      },
    },
    {
      title: "Check Out Date",
      dataIndex: "checkout_date",
      key: "checkout_date",
      render: (text) => {
        return text ? new Date(text).toLocaleString() : null;
      },
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
  ];

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      ></div>
      <Table
        dataSource={users}
        columns={columns}
        rowKey={(record) => record.id}
      />
    </div>
  );
};

export default CheckedInUsers;
