import { Button, Form, Input, InputNumber, Radio, TimePicker } from "antd";
import moment from "moment";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import {
  setAdminTax,
  setAdminWithdrawFee,
} from "../../appRedux/actions/Common";

const basePath = process.env.REACT_APP_API_URL;

const Settings = () => {
  const adminTax = useSelector((state) => state.common.adminTax);
  const dispatch = useDispatch();

  const [parent_id, setParentId] = useState();
  useEffect(() => {
    let parentId = localStorage.getItem("userId");
    if (
      localStorage.getItem("parent_merchant_id") &&
      localStorage.getItem("userTypeId") === "4"
    ) {
      parentId = localStorage.getItem("parent_merchant_id");
    }
    setParentId(parentId);
  }, []);

  const [form] = Form.useForm();
  const [setting, setSetting] = useState(null);
  const [merchants, setMerchants] = useState(null);
  const fetchAdminTaxData = async (dispatch) => {
    try {
<<<<<<< HEAD
      const response = await axios.get(`${basePath}/setting/1`);
=======
      const response = await axios.get(`${basePath}/setting/admin/1`);
>>>>>>> parent of e14da0a (Updated code with no access to unauthorized users other than superadmin)
      dispatch(setAdminTax(response.data.settings.tax));
      dispatch(setAdminWithdrawFee(response.data.settings.withdraw_fee));
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    fetchAdminTaxData(dispatch);
  }, [dispatch]);
  const fetchSettings = async () => {
    if (parent_id) {
      const response = await axios.get(`${basePath}/setting/${parent_id}`);
      if (response?.data?.settings?.start_time) {
        response.data.settings.start_time = moment(
          response?.data?.settings?.start_time,
          "HH:mm"
        );
      }
      if (response?.data?.settings?.end_time) {
        response.data.settings.end_time = moment(
          response?.data?.settings?.end_time,
          "HH:mm"
        );
      }
      localStorage.setItem("tax", response?.data?.settings?.tax);

      setSetting(response?.data?.settings);
    } else {
    }
  };

  const handleSave = async (values) => {
    let id = setting?.id;
    const response = await axios.post(`${basePath}/setting/update`, {
      id: id ? id : null,
      ...values,
      merchant_id: parent_id,
    });

    fetchSettings();
  };
  // useEffect(() => {
  //   async function fetchMerchants() {
  //     // TODO: Add merchant id based merchants
  //     const res = await axios.post(
  //       `${basePath}/merchants/list
  //       `
  //     );
  //
  //     setMerchants(res.data.merchants.rows);
  //   }
  //   fetchMerchants();
  // }, []);

  useEffect(() => {
    fetchSettings();
  }, [parent_id]);

  useEffect(() => {
    if (form && setting) {
      form.setFieldsValue(setting);
    }
  }, [form, setting]);

  return (
    <div>
      <h1>Settings</h1>
      <Form
        form={form}
        layout="vertical"
        onFinish={handleSave}
        initialValues={setting}
      >
        {localStorage.getItem("userTypeId") !== "1" && (
          <>
            <Form.Item
              label="Status"
              name="status"
              rules={[
                {
                  required: true,
                  message: "Please select a status!",
                },
              ]}
            >
              <Radio.Group>
                <Radio.Button value="Open">Open</Radio.Button>
                <Radio.Button value="Close">Close</Radio.Button>
              </Radio.Group>
            </Form.Item>
            <Form.Item
              label={`Set Tax Rate (Default Global Tax Rate: ${adminTax}%):`}
              name="tax"
            >
              <InputNumber
                formatter={(value) => `${value}%`}
                parser={(value) => value.replace("%", "")}
              />
            </Form.Item>
          </>
        )}
        {localStorage.getItem("userTypeId") === "1" && (
          <>
            <Form.Item label={`Set Global Tax Rate:`} name="tax">
              <InputNumber
                formatter={(value) => `${value}%`}
                parser={(value) => value.replace("%", "")}
              />
            </Form.Item>
            <Form.Item
              label={`Set Weekly Withdrawal Fee %:`}
              name="withdraw_fee"
            >
              <InputNumber
                formatter={(value) => `${value}%`}
                parser={(value) => value.replace("%", "")}
              />
            </Form.Item>
            <Form.Item
              label={`Set Global Withdrawal Limit (Default Global Withdrawal Limit: 7 days):`}
              name="withdraw_limit"
            >
              <InputNumber
                formatter={(value) => `${value} days`}
                parser={(value) => value.replace("days", "")}
              />
            </Form.Item>
          </>
        )}

        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default Settings;
