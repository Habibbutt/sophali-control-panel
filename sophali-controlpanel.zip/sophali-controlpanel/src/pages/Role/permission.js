import { Button, Checkbox, Divider, Modal } from "antd";
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useSnackbar } from "notistack";

const CheckboxGroup = Checkbox.Group;

const Permission = (record) => {
  console.log(`🚀🚀🚀  record:`, record);
  const [visible, setVisible] = useState(false);
  const [permissionList, setPermissionList] = useState([]);
  const { enqueueSnackbar } = useSnackbar();

  const hideModal = () => setVisible(false);
  const basePath = process.env.REACT_APP_API_URL;

  useEffect(() => {
    async function fetchData() {
      const permissionResult = await axios.get(
        `${basePath}/permissions/all?role_id=${record.record.id}`
      );
      setPermissionList(permissionResult.data.permissions);
    }
    fetchData();
  }, []);

  const optionPermissions = ["List", "Add", "Edit", "Delete"];

  const options =
    permissionList &&
    permissionList.map((element) => {
      console.log(`🚀🚀🚀  element:`, element);
      return { id: element.id, name: element.name, options: optionPermissions };
    });

  const [state, setState] = useState(options.map(({ options }) => options));

  const showModal = () => {
    const fetchPermissions = async () => {
      try {
        const result = await axios.post(`${basePath}/get-role-permissions`, {
          role_id: record.record.id,
        });
        const resultForCount = await axios.get(`${basePath}/permissions/all`);
        let array = [];
        for (
          let index = 0;
          index < resultForCount.data.permissions.length;
          index++
        ) {
          let arr = [];
          if (result.data.rolePermissions.rows[index]?.can_create)
            arr.push("Add");
          if (result.data.rolePermissions.rows[index]?.can_delete)
            arr.push("Delete");
          if (result.data.rolePermissions.rows[index]?.can_read)
            arr.push("List");
          if (result.data.rolePermissions.rows[index]?.can_update)
            arr.push("Edit");
          array.push(arr);
        }
        setState(array);

        // setState()
      } catch (error) {
        enqueueSnackbar(error, { variant: "error" });
        console.error(error);
      }
    };

    fetchPermissions();
    setVisible(true);
  };
  const handleCreate = async (permissions) => {
    try {
      permissions.forEach(async (element, index) => {
        let obj = {
          role_id: record.record.id,
          permission_id: options[index]?.id,
          can_create: element.includes("Add") ? 1 : 0,
          can_read: element.includes("List") ? 1 : 0,
          can_update: element.includes("Edit") ? 1 : 0,
          can_delete: element.includes("Delete") ? 1 : 0,
        };
        if (options[index]?.id) {
          const result = await axios.post(
            `${basePath}/set-role-permission`,
            obj
          );
        }
      });
      enqueueSnackbar('Permissions Successfully Updated', { variant: "success" });
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const onChange = (index) => (list) => {
    const newState = state.map((item, i) => (index === i ? list : item));
    setState(newState);
  };

  const onCheckAllChange = () => (e) => {
    setState(
      e.target.checked
        ? options.map(({ options }) => options)
        : options.map(({ options }) => [])
    );
  };

  return (
    <>
      <Button
        type="link"
        onClick={() => {
          showModal();
        }}
      >
        Permissions
      </Button>
      <Modal
        title="Permissions"
        open={visible}
        okText="Save"
        onOk={() => {
          handleCreate(state);
          hideModal();
        }}
        onCancel={hideModal}
        width={500}
      >
        <Checkbox
          indeterminate={state.some(
            (s) => s?.length > 0 && s?.length < options[0].options?.length
          )}
          onChange={onCheckAllChange()}
          checked={state.every((s) => s?.length === options[0].options?.length)}
        >
          Check all
        </Checkbox>
        <Divider />
        {options.map(({ name, options }, index) => (
          <div key={name}>
            <Checkbox
              indeterminate={
                state[index]?.length > 0 &&
                state[index]?.length < options?.length
              }
              onChange={(e) => onChange(index)(e.target.checked ? options : [])}
              checked={state[index]?.length === options?.length}
            >
              {name}
            </Checkbox>
            <Divider />
            <CheckboxGroup
              style={{ paddingLeft: "25px" }}
              options={options}
              value={state[index]}
              onChange={onChange(index)}
            />
            {/* {index < options?.length - 1 && <Divider />} */}
            <Divider />
          </div>
        ))}
      </Modal>
    </>
  );
};

export default Permission;
