import { ExclamationCircleOutlined } from "@ant-design/icons";
import { Button, Form, Input, Modal, Table } from "antd";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Permission from "./permission";
import { useSnackbar } from "notistack";

const { confirm } = Modal;

const showConfirm = (id, onDelete) => {
  confirm({
    title: "Do you want to delete this role?",
    icon: <ExclamationCircleOutlined />,
    onOk() {
      onDelete(id);
    },
    onCancel() {},
  });
};
const AddRoleModal = ({ open, setOpen, role, setRole, onCreate, onCancel }) => {
  const [form] = Form.useForm();
  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(role || {});
  }, [role, form]);

  return (
    <Modal
      forceRender
      open={open}
      title={role ? "Edit Role" : "Add Role"}
      okText={role ? "Update" : "Add"}
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setRole(null);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpen(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        initialValues={role}
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Form.Item
          name="name"
          label="Name"
          rules={[
            {
              required: true,
              message: "Please Enter Name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="description"
          label="Description"
          rules={[
            {
              required: true,
              message: "Please enter description!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="parent_id"
          label="Parent ID"
          style={{ display: "none" }}
        >
          <Input value="1" />
        </Form.Item>
      </Form>
    </Modal>
  );
}; // add role modal ends

const Role = () => {
  const [roles, setRoles] = useState([]);
  const [open, setOpen] = useState(false);
  const [role, setRole] = useState({});
  const { enqueueSnackbar } = useSnackbar();
  let userTypeId = localStorage.getItem("userTypeId");

  const basePath = process.env.REACT_APP_API_URL;
  // const params = useParams();

  useEffect(() => {
    fetchData(userTypeId);
  }, [userTypeId]);
  async function fetchData(userTypeId) {
    let listRole;
    if (userTypeId == 3) {
      listRole = await axios.get(`${basePath}/roles/all?userTypeId=${4}`);
    } else {
      listRole = await axios.get(`${basePath}/roles/all`);
    }

    setRoles(listRole.data.roles.rows);
  }

  // const onCreate = async (values) => {
  //   const res = await axios.post(`${basePath}/roles/add`, values)

  //   const listRole = await axios.get(`${basePath}/roles/all`)
  //   setRoles(listRole.data.roles.rows);

  //   setOpen(false);
  // };

  const handleCreate = async (values) => {
    try {
      if (role) {
        const result = await axios.post(`${basePath}/roles/update`, {
          ...values,
          id: role.id,
        });
        fetchData();
      } else {
        const result = await axios.post(`${basePath}/roles/add`, values);
        fetchData();
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    } finally {
      setOpen(false);
      setRole(null);
    }
  }; // handle create ends

  // const onDelete = async (id) => {
  //   const res = await axios.post(`${basePath}/roles/delete`, { id })
  //   const listRole = await axios.get(`${basePath}/roles/all`)
  //   setRoles(listRole.data.roles.rows);
  // };

  const handleDelete = async (id) => {
    try {
      await axios.post(`${basePath}/roles/delete`, { id });
      const updatedRoles = roles.filter((item) => item.id !== id);
      setRoles(updatedRoles);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  }; // handle delete ends

  const onCancel = async (values) => {
    setOpen(false);
  };

  const columns = [
    {
      title: "Role Name",
      dataIndex: "name",
    },
    {
      title: "Description",
      dataIndex: "description",
    },
    {
      title: "Status",
      dataIndex: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    // {
    //   title: 'Actions',
    //   dataIndex: 'actions',
    //   render: (_, data) => {
    //     return <div><Button onClick={async () => {
    //       await setRole(data);
    //       setOpen(true);
    //     }} size="small">Edit</Button>
    //       <Button danger style={{ marginLeft: "-12px" }} onClick={async () => {
    //         onDelete(data.id);
    //       }} size="small">Delete</Button></div>
    //   },
    // },
    {
      title: "Actions",
      key: "action",
      render: (_text, record) => (
        <span style={{ paddingTop: "30px !important" }}>
          <Permission record={record} />
          {/* <Button
            type="link"
            onClick={() => {
              setOpen(true);
              setRole(record);
            }}
          >
            Edit
          </Button>
          <Button
            type="link"
            onClick={() => {
              showConfirm(record.id, handleDelete);
            }}
          >
            Delete
          </Button> */}
        </span>
      ),
    },
  ];
  return (
    <div>
      {/* <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'baseline'
      }}> */}
      <h2 style={{ marginLeft: "2px" }}>Roles List</h2>
      {/* <Button
          style={{ marginRight: '1px' }}
          type="primary"
          onClick={() => {
            setOpen(true);
            setRole(null);
          }}
        >
          Add Role
        </Button></div> */}

      <Table
        dataSource={roles}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <AddRoleModal
        open={open}
        setOpen={setOpen}
        role={role}
        setRole={setRole}
        onCreate={handleCreate}
        onCancel={() => setOpen(false)}
      />
    </div>
  );
};
export default Role;
