import { ExclamationCircleOutlined } from "@ant-design/icons";
import {
  Button,
  InputNumber,
  Form,
  Input,
  Modal,
  Table,
  Select,
  DatePicker,
  Checkbox,
} from "antd";
import axios from "axios";
import React, { useEffect, useState } from "react";
import Authorize from "../../components/Authorize/Authorize";
import { useSnackbar } from "notistack";
import moment from "moment";
const { confirm } = Modal;
const basePath = process.env.REACT_APP_API_URL;

const SubscribedUsersModal = ({ open, setOpen, users }) => {
  
  let finalusers = users?.map((user) => {
    return {
      ...user,
      name: user.first_name + " " + user.last_name,
      checkin_date: moment(user.checkin_date).format("DD-MM-YYYY"),
    };
  });

  return (
    <Modal
      title="Subscribed Users"
      open={open}
      onCancel={() => setOpen(false)}
      footer={null}
    >
      <Table
        dataSource={finalusers}
        columns={[
          {
            title: "Check In Date",
            dataIndex: "checkin_date",
            key: "checkin_date",
          },
          {
            title: "Name",
            dataIndex: "name",
            key: "name",
          },
          {
            title: "Email",
            dataIndex: "email",
            key: "email",
          },
        ]}
        rowKey={(record) => record.id}
      />
    </Modal>
  );
};
const SentUsersModal = ({ open, setOpen, coupon }) => {
  
  const [users, setUsers] = useState([]);
  async function fetchUsers() {
    let response = await axios.get(
      `${basePath}/couponuser/merchant-coupon-user-list/${localStorage.getItem(
        "userId"
      )}?coupon_id=${coupon.id}`
    );
    
    setUsers(response.data.couponUsers);
  }
  useEffect(() => {
    if (coupon) {
      fetchUsers();
    }
  }, [coupon]);

  return (
    <Modal
      title="Sent Users List"
      open={open}
      onCancel={() => setOpen(false)}
      footer={null}
    >
      <Table
        dataSource={users}
        columns={[
          {
            title: "Sr No.",
            dataIndex: "id",
            key: "id",
          },
          {
            title: "Name",
            dataIndex: "name",
            key: "name",
            render: (text, record) => {
              return (
                <span>
                  {record.User.first_name} {record.User.last_name}
                </span>
              );
            },
          },
          {
            title: "Email",
            dataIndex: "email",
            key: "email",
            render: (text, record) => {
              return <span>{record.User.email}</span>;
            },
          },
        ]}
        rowKey={(record) => record.id}
      />
    </Modal>
  );
};

const SendCouponModal = ({ open, setOpen, users, onSend }) => {
  const [form] = Form.useForm();

  const [selectedUsers, setSelectedUsers] = useState([]);

  const handleChange = (value) => {
    if (value.includes("all")) {
      if (selectedUsers.length !== users.length) {
        setSelectedUsers(users.map((user) => user.id));
      } else {
        setSelectedUsers([]);
      }
    } else {
      setSelectedUsers(value);
    }

    form.setFieldsValue({ users: selectedUsers });
  };

  return (
    <Modal
      title={`Send Coupon to `}
      open={open}
      onCancel={() => setOpen(false)}
      onOk={() => {
        form.validateFields().then((values) => {
          form.resetFields();
          onSend(values.users);
          setOpen(false);
        });
      }}
    >
      <Form form={form} layout="vertical">
        <Form.Item name="users" label="Users">
          <Select
            mode="multiple"
            placeholder="Select users"
            value={selectedUsers}
            onChange={handleChange}
          >
            <Select.Option key="all" value="all">
              Select All
            </Select.Option>
            {users?.map((user) => (
              <Select.Option key={user.id} value={user.id}>
                {user.first_name + " " + user.last_name}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
      </Form>
    </Modal>
  );
};

const showConfirm = (id, onDelete) => {
  confirm({
    title: "Do you want to delete this coupon?",
    icon: <ExclamationCircleOutlined />,
    onOk() {
      onDelete(id);
    },
    onCancel() {},
  });
};
const AddCouponModal = ({
  open,
  setOpen,
  coupon,
  setCoupon,
  onCreate,
  onCancel,
}) => {
  const [form] = Form.useForm();
  const [type, setType] = useState("product");
  const [discountType, setDiscountType] = useState("");
  const [products, setProducts] = useState([]);

  let parent_id;
  if (
    localStorage.getItem("parent_merchant_id") &&
    localStorage.getItem("userTypeId") == 4
  ) {
    parent_id = localStorage.getItem("parent_merchant_id");
  } else {
    parent_id = localStorage.getItem("userId");
  }
  const fetchProducts = async () => {
    try {
      const result = await axios.get(
        `${basePath}/products/list?added_by=${parent_id}`
      );
      
      setProducts(result.data.products.rows);
    } catch (error) {
      // enqueueSnackbar(error, { variant: "error" });
      console.error(error);
    }
  };
  useEffect(() => {
    fetchProducts();
    form.resetFields();
    if (coupon) {
      coupon.expires_at = moment(coupon.expires_at);
      setType(coupon.type);
      form.setFieldsValue(coupon || {});
    }
  }, [coupon, form]);
  return (
    <Modal
      forceRender
      open={open}
      title={coupon ? "Edit Coupon" : "Add Coupon"}
      okText={coupon ? "Update" : "Add"}
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setCoupon(null);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpen(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Form.Item
          name="code"
          label="Code"
          rules={[
            {
              required: true,
              message: "Please Enter Code!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="type"
          label="Coupon Type"
          rules={[
            {
              required: true,
              message: "Please select coupon type!",
            },
          ]}
          initialValue={type}
        >
          <Select
            onChange={(value) => {
              setType(value);
              form.setFieldsValue({ product_ids: undefined });
            }}
          >
            <Select.Option value="product">Specific Products</Select.Option>
            <Select.Option value="all">All Purchased Items</Select.Option>
          </Select>
        </Form.Item>
        <Form.Item name="product_ids" label="Product" dependencies={["type"]}>
          <Select mode="multiple" disabled={type !== "product"}>
            {products.map((product) => (
              <Select.Option key={product.id} value={product.id}>
                {product.title}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          name="discountType"
          label="Discount Type"
          rules={[
            {
              required: true,
              message: "Please select discount type!",
            },
          ]}
          initialValue={discountType}
        >
          <Select
            onChange={(value) => {
              setDiscountType(value);
              form.setFieldsValue({ value: undefined });
            }}
          >
            <Select.Option value="amount">Amount</Select.Option>
            {type === "product" && (
              <Select.Option value="bogof">Buy One Get One Free</Select.Option>
            )}
          </Select>
        </Form.Item>

        {discountType == "amount" && (
          <Form.Item
            name="value"
            label="Discount Value in USD"
            rules={[
              {
                required: true,
                message: "Please enter discount!",
              },
              {
                pattern: /^\d+(\.\d{1,2})?$/,
                message: "Please enter a valid discount amount!",
              },
            ]}
          >
            <Input />
          </Form.Item>
        )}
        {/* <Form.Item
          name="is_percentage"
          valuePropName="checked"
          wrapperCol={{ offset: 6, span: 18 }}
        >
          <Checkbox>Percentage</Checkbox>
        </Form.Item> */}
        {discountType == "amount" && (
          <Form.Item
            name="min_order_amount"
            label="Minimum Order Amount"
            rules={[
              {
                required: true,
                message: "Please enter minimum order amount!",
              },
              {
                pattern: /^\d+(\.\d{1,2})?$/,
                message: "Please enter a valid amount!",
              },
            ]}
          >
            <Input />
          </Form.Item>
        )}
        <Form.Item
          name="expires_at"
          label="Expiration Date"
          rules={[
            {
              required: true,
              message: "Please select expiration date!",
            },
          ]}
        >
          <DatePicker />
        </Form.Item>
        <Form.Item
          name="max_uses"
          label="Max Uses"
          rules={[
            {
              required: true,
              message: "Please enter max uses!",
            },
            {
              pattern: /^\d+$/,
              message: "Please enter a valid number!",
            },
          ]}
        >
          <Input />
        </Form.Item>
      </Form>
    </Modal>
  );
};
const Coupon = () => {
  const [coupons, setCoupons] = useState([]);
  const [coupon, setCoupon] = useState(null);
  const [addCouponModalOpen, setAddCouponModalOpen] = useState(false);
  const [userListModalOpen, setUserListModalOpen] = useState(false);
  const [usedCouponsModalOpen, setUsedCouponsModalOpen] = useState(false);
  const [sendCouponModalOpen, setSendCouponModalOpen] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const [users, setUsers] = useState([]);
  const [user, setUser] = useState(null);
  // const basePath = process.env.REACT_APP_API_URL;
  useEffect(() => {
    fetchCoupons();
    fetchUsers();
  }, []);
  let parent_id;
  if (
    localStorage.getItem("parent_merchant_id") &&
    localStorage.getItem("userTypeId") == 4
  ) {
    parent_id = localStorage.getItem("parent_merchant_id");
  } else {
    parent_id = localStorage.getItem("userId");
  }
  async function fetchCoupons() {
    const res = await axios.get(
      `${basePath}/coupon/all?merchant_id=${parent_id}`
    );
    
    setCoupons(res.data.coupons);
  }
  async function fetchUsers() {
    const res = await axios.get(
      `${basePath}/users/subscribe-user-list/${parent_id}`
    );
    res.data.userList = res.data.userList.filter(e=>!e.checkout_date)
    
    setUsers(res.data.userList);
  }
  async function handleSendCoupon(users) {
    const res = await axios.post(`${basePath}/coupon/send-coupon-users`, {
      ...coupon,
      users,
      merchant_name: localStorage.getItem("merchant_name"),
    });
    
    fetchUsers(res.data.userList);
  }
  const handleCreate = async (values) => {
    
    try {
      if (coupon) {
        const result = await axios.post(`${basePath}/coupon/update`, {
          ...values,
          id: coupon.id,
        });
        enqueueSnackbar("Coupon updated successfully", {
          variant: "success",
        });

        fetchCoupons();
      } else {
        const result = await axios.post(`${basePath}/coupon/add`, {
          ...values,
          merchant_id: parent_id,
        });
        enqueueSnackbar("Coupon added successfully", {
          variant: "success",
        });

        fetchCoupons();
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    } finally {
      setAddCouponModalOpen(false);
      setCoupon(null);
    }
    // const res = await axios.post(`${basePath}/coupon/add`, values);

    // const listCoupon = await axios.get(`${basePath}/coupons/all`)
    // setCoupons(listCoupon.data.coupons.rows);
    // setOpen(false);
  };
  const handleDelete = async (id) => {
    
    try {
      await axios.post(`${basePath}/coupon/delete`, { id });
      enqueueSnackbar("Coupon deleted successfully", {
        variant: "success",
      });
      const updatedCoupons = coupons.filter((item) => item.id !== id);
      setCoupons(updatedCoupons);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });

      console.error(error);
    }
  };
  const columns = [
    {
      title: "Coupon Code",
      dataIndex: "code",
    },
    {
      title: "Coupon Type",
      dataIndex: "type",
    },

    {
      title: "Status",
      dataIndex: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      key: "action",
      render: (text, record) => (
        <span>
          <Authorize moduleId={3} permissions="can_create">
            <Button
              style={{ marginRight: "1px" }}
              type="primary"
              onClick={() => {
                setCoupon(record);
                setSendCouponModalOpen(true);
              }}
            >
              Send Coupon
            </Button>
            <Button
              style={{ marginRight: "1px" }}
              type="primary"
              onClick={() => {
                setCoupon(record);
                setUserListModalOpen(true);
              }}
            >
              Sent List
            </Button>
          </Authorize>

          <Authorize moduleId={3} permissions="can_update">
            <Button
              type="link"
              onClick={() => {
                setAddCouponModalOpen(true);
                setCoupon(record);
              }}
            >
              Edit
            </Button>
          </Authorize>
          <Authorize moduleId={3} permissions="can_delete">
            <Button
              type="link"
              onClick={() => {
                showConfirm(record.id, handleDelete);
              }}
            >
              Delete
            </Button>
          </Authorize>
        </span>
      ),
    },
  ];
  if (localStorage.getItem("userTypeId") == "1") {
    columns.unshift({ title: "Merchant Name", dataIndex: "merchant_name" });
  }
  // const data = coupons.map(coupon => ({
  //   ...coupon,
  // }))
  return (
    // <div>
    //   <div style={{ display: "flex", justifyContent: "space-between" }}><h2 className="title gx-mb-4"><IntlMessages id="sidebar.coupon" /></h2>
    //     <Button type="primary"
    //       onClick={() => {
    //         setOpen(true);
    //       }} size="small">Add</Button>
    //   </div>
    //   <Widget styleName="gx-order-history"
    //     title={
    //       <h2 className="h4 gx-text-capitalize gx-mb-0">
    //         Coupon Listing</h2>
    //     } extra={
    //       <p className="gx-text-primary gx-mb-0 gx-pointer">Details</p>
    //     }>

    //     <div className="gx-table-responsive">
    //       <Table className="gx-table-no-bordered" columns={columns} dataSource={data} pagination={false} bordered={false}
    //         size="small" />
    //     </div>
    //     <AddCouponModal
    //       open={open}
    //       onCreate={onCreate}
    //       onCancel={() => {
    //         setOpen(false);
    //       }}
    //     />
    //   </Widget>
    // </div >
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
          marginBottom: "16px",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Coupons List</h2>
        <div style={{ display: "flex", alignItems: "center" }}>
          <Authorize moduleId={3} permissions="can_create">
            <Button
              style={{ marginRight: "1px" }}
              type="primary"
              onClick={() => {
                setAddCouponModalOpen(true);
                setCoupon(null);
              }}
            >
              Add Coupon
            </Button>
          </Authorize>
          <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              setUsedCouponsModalOpen(true);
              // setCoupon(null);
            }}
          >
            Show Subscribers List
          </Button>
          {/* <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              // setOpen(true);
              // setCoupon(null);
            }}
          >
            Used Coupons
          </Button> */}
          {/* <Authorize moduleId={3} permissions="can_read">
            <Button
              style={{ marginRight: "1px" }}
              type="primary"
              onClick={() => {
                setUsedCouponsModalOpen(true);
              }}
            >
              Used Coupons
            </Button>
          </Authorize> */}
        </div>
      </div>
      <Table
        dataSource={coupons}
        columns={columns}
        rowKey={(record) => {
          return record.id;
        }}
      />
      <AddCouponModal
        open={addCouponModalOpen}
        setOpen={setAddCouponModalOpen}
        coupon={coupon}
        setCoupon={setCoupon}
        onCreate={handleCreate}
        onCancel={() => setAddCouponModalOpen(false)}
      />
      <SentUsersModal
        open={userListModalOpen}
        setOpen={setUserListModalOpen}
        coupon={coupon}
      />
      <SubscribedUsersModal
        open={usedCouponsModalOpen}
        setOpen={setUsedCouponsModalOpen}
        users={users}
      />
      <SendCouponModal
        open={sendCouponModalOpen}
        setOpen={setSendCouponModalOpen}
        users={users}
        onSend={handleSendCoupon}
      />
    </div>
  );
};

export default Coupon;
