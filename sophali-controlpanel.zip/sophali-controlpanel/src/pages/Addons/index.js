import React, { useEffect, useState } from "react";
import { ExclamationCircleOutlined, UploadOutlined } from "@ant-design/icons";
import ImgCrop from "antd-img-crop";
import moment from "moment";

import {
  Button,
  message,
  Form,
  Input,
  InputNumber,
  Modal,
  Select,
  Table,
  Upload,
  Image,
  DatePicker,
  Checkbox,
} from "antd";
// import { CheckboxChangeEvent } from 'antd/es/checkbox';
import axios from "axios";
import Authorize from "../../components/Authorize/Authorize";
import { useSnackbar } from "notistack";
const { confirm } = Modal;
// const { Option } = Select;

const basePath = process.env.REACT_APP_API_URL;

const showConfirm = (id, onDelete) => {
  confirm({
    title: "Do you want to delete this addon?",
    icon: <ExclamationCircleOutlined />,
    onOk() {
      onDelete(id);
    },
    onCancel() {},
  });
};
const AddAddonModal = ({
  categories,
  open,
  setOpen,
  addon,
  setAddon,
  onCreate,
  onCancel,
  handleChange,
  // handleUpload,
}) => {
  const [form] = Form.useForm();
  const [fileList, setFileList] = useState([]);
  const [isTransferable, setIsTransferable] = useState(false);

  const onChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };

  const onTransferChange = (e) => {
    setIsTransferable(e.target.checked);
  };

  const onPreview = async (file) => {
    let src = file.url;
    if (!src) {
      src = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file.originFileObj);
        reader.onload = () => resolve(reader.result);
      });
    }
    const image = new Image();
    image.src = src;
    const imgWindow = window.open(src);
    imgWindow?.document.write(image.outerHTML);
  };
  const onRemove = () => {
    addon.photo = "";
    setFileList([]);
  };
  useEffect(() => {
    form.resetFields();
    if (addon) {
      addon.transfer_expire_date = moment(addon.transfer_expire_date);
      setIsTransferable(addon.is_transferable);
      form.setFieldsValue(addon);
    }
  }, [addon, form]);

  return (
    <Modal
      forceRender
      open={open}
      title={addon ? "Edit Addon" : "Add Addon"}
      okText={addon ? "Update" : "Add"}
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setAddon("");
        setFileList([]);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate({ ...values, fileList });
            setOpen(false);
            setFileList([]);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        {/* <Form.Item
          name="cat_id"
          label="Category"
          rules={[
            {
              required: true,
              message: "Please select category!",
            },
          ]}
        >
          <Select
            options={categories}
            size={"small"}
            className="mission-status"
            value={undefined || null || ""}
          />
        </Form.Item> */}
        <Form.Item
          name="title"
          label="Title"
          rules={[
            {
              required: true,
              message: "Please Enter Title!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        {/* <Form.Item name="description" label="Description">
          <Input />
        </Form.Item>
        <Form.Item name="stock" label="Stock">
          <InputNumber />
        </Form.Item>
        <Form.Item
          name="size"
          label="Size"
          rules={[
            {
              required: true,
              message: "Please Enter Size!",
            },
          ]}
        >
          <Select
            options={[
              { value: "Small", label: "Small" },
              { value: "Medium", label: "Medium" },
              { value: "Large", label: "Large" },
            ]}
            size={"small"}
            className="mission-status"
            value={undefined || null || ""}
          />
        </Form.Item> */}
        <Form.Item
          name="price"
          label="Price in USD"
          rules={[
            {
              required: true,
              message: "Please enter price!",
            },
          ]}
        >
          <InputNumber />
        </Form.Item>
        {/* <Form.Item
          name="time"
          label="Time to make"
          rules={[{ required: true, message: "Please enter time!" }]}
        >
          <InputNumber />
        </Form.Item>
        <Form.Item
          name="time_type"
          label="Time Type"
          rules={[{ required: true, message: "Please select time type!" }]}
        >
          <Select
            options={[
              { value: "minutes", label: "Mints" },
              { value: "hours", label: "Hrs" },
            ]}
            className="time-select"
            value={undefined || null || ""}
          />
        </Form.Item>
        <Form.Item
          name="is_transferable"
          label="Is Transferable.?"
          valuePropName="checked"
        >
          <Checkbox onChange={onTransferChange} />
        </Form.Item>
        {isTransferable && (
          <Form.Item
            name="transfer_expire_date"
            label={<span className="label-text">Transfer Expire Date</span>}
          >
            <DatePicker
              className="input"
              format="MM/YY"
              placeholder="Select expiration date"
              allowClear={false}
            />
          </Form.Item>
        )}
        <Form.Item
          name="discount"
          label="Discount"
          // rules={[
          //   {
          //     required: true,
          //     message: "Please enter discount!",
          //   },
          // ]}
        >
          <InputNumber />
        </Form.Item>
        <Form.Item
          name="vat"
          label="VAT %"
          // rules={[
          //   {
          //     required: true,
          //     message: "Please enter VAT",
          //   },
          // ]}
        >
          <InputNumber />
        </Form.Item> */}
        <Form.Item name="images" label="Image">
          <ImgCrop rotationSlider>
            <Upload
              name="Files"
              action={`${basePath}/upload`}
              listType="picture-card"
              fileList={
                addon && addon.photo && JSON.parse(addon.photo).length
                  ? [
                      {
                        url: `${basePath}/getFileById?uuid=${
                          addon && addon?.photo && JSON.parse(addon.photo)[0]
                        }`,
                      },
                    ]
                  : null || fileList
              }
              onChange={onChange}
              onPreview={onPreview}
              onRemove={onRemove}
            >
              {(addon.photo == "[]" || !addon.photo) &&
                fileList.length < 1 &&
                "+ Upload"}
            </Upload>
          </ImgCrop>
        </Form.Item>
      </Form>
    </Modal>
  );
};

const Addon = () => {
  const [addons, setAddons] = useState([]);
  const [categories, setCategories] = useState([]);
  const [addon, setAddon] = useState("");
  const [open, setOpen] = useState(false);
  const basePath = process.env.REACT_APP_API_URL;
  const { enqueueSnackbar } = useSnackbar();
  useEffect(() => {
    fetchCategories();
    fetchAddons();
  }, []);
  // useEffect(() => {}, []);
  let parent_id;
  if (
    localStorage.getItem("parent_merchant_id") &&
    localStorage.getItem("userTypeId") == 4
  ) {
    parent_id = localStorage.getItem("parent_merchant_id");
  } else {
    parent_id = localStorage.getItem("userId");
  }
  const fetchAddons = async () => {
    try {
      const result = await axios.get(
        `${basePath}/addons/list?added_by=${parent_id}`
      );
      setAddons(result.data.addons.rows);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  async function fetchCategories() {
    // const res = await axios.get(
    //   `${basePath}/categories/list?parent_id=${parent_id}`
    // );
    // setCategories(
    //   res.data.categories.rows.map((element) => ({
    //     value: element.id,
    //     label: element.title,
    //   }))
    // );
  }
  // const handleUpload = async (info) => {
  //   if (info.file.status === "uploading") {
  //     // setLoading(true);
  //     return;
  //   }
  //   if (info.file.status === "done") {
  //     // setLoading(false);
  //     setFile(info.file.response);
  //     try {
  //       // check if the file is already uploaded
  //       if (!file) {
  //         const response = await axios.post(`${basePath}/api/admin/upload`, {
  //           file: info.file.response,
  //         });
  //         setFile(response.data);
  //       }
  //     } catch (error) {
  // enqueueSnackbar(error, { variant: "error" });
  //       console.error(error);
  //     }
  //   }
  // };

  const handleCreate = async (values) => {
    if (!values.photo) {
      values.photo = JSON.stringify(
        values.fileList.map((item) => {
          return item.response.data;
        })
      );
      if (values.photo == "[]") {
        values.photo = addon.photo;
      }
      delete values.fileList;
    }
    try {
      if (addon) {
        const result = await axios.post(`${basePath}/addons/update`, {
          ...values,
          id: addon.id,
        });
        enqueueSnackbar("Addon updated successfully", {
          variant: "success",
        });
        fetchCategories();
        fetchAddons();
      } else {
        const result = await axios.post(`${basePath}/addons/add`, {
          ...values,
          parent_id: parent_id,
          added_by: parent_id,
        });
        enqueueSnackbar("Addon added successfully", {
          variant: "success",
        });
        const resultList = await axios.get(
          `${basePath}/addons/list?added_by=${parent_id}`
        );
        fetchCategories();
        fetchAddons();
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    } finally {
      setOpen(false);
      setAddon("");
    }
  };
  const handleDelete = async (id) => {
    // try {
    //   await axios.post(`${basePath}/addon/delete`, { id });
    //   enqueueSnackbar("Addon deleted successfully", {
    //     variant: "success",
    //   });
    //   const updatedAddons = addons.filter((item) => item.id !== id);
    //   setAddons(updatedAddons);
    // } catch (error) {
    //   enqueueSnackbar(error, { variant: "error" });
    //   console.error(error);
    // }
  };
  // const getImages = async (uuids) => {
  //   try {
  //     let fileList = [];
  //     uuids.forEach(async (element) => {
  //       let res = await axios.get(`${basePath}/getFileById?uuid=${element}`);
  //       fileList.push(res.data);
  //     });
  //     return fileList;
  //   } catch (error) {
  // enqueueSnackbar(error, { variant: "error" });
  //     console.error(error);
  //   }
  // };
  const columns = [
    {
      title: "Image",
      dataIndex: "photo",
      key: "photo",
      render: (text, record) => {
        return (
          <Image
            width={50}
            src={`${basePath}/getFileById?uuid=${
              record && record?.photo && JSON.parse(record.photo)[0]
            }`}
          ></Image>
        );
      },
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
    },
    // {
    //   title: "Description",
    //   dataIndex: "description",
    //   key: "description",
    // },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      dataIndex: "action",
      key: "action",
      render: (text, record) => (
        <span>
          <Authorize moduleId={3} permissions="can_update">
            <Button
              type="link"
              onClick={async () => {
                setOpen(true);

                setAddon(record);
              }}
            >
              Edit
            </Button>
          </Authorize>
          <Authorize moduleId={3} permissions="can_delete">
            <Button
              type="link"
              onClick={() => {
                showConfirm(record.id, handleDelete);
              }}
            >
              Delete
            </Button>
          </Authorize>
        </span>
      ),
    },
  ];
  if (localStorage.getItem("userTypeId") == 1) {
    columns.unshift({ title: "Merchant Name", dataIndex: "merchant_name" });
  }
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Addons List</h2>
        <Authorize moduleId={3} permissions="can_create">
          <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              setOpen(true);
              setAddon("");
            }}
          >
            Add Addon
          </Button>
        </Authorize>
      </div>
      <Table
        dataSource={addons}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <AddAddonModal
        open={open}
        setOpen={setOpen}
        addon={addon}
        setAddon={setAddon}
        onCreate={handleCreate}
        categories={categories}
        // handleUpload={handleUpload}
        onCancel={() => setOpen(false)}
      />
    </div>
  );
};

export default Addon;
