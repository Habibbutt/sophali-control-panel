import { Button, Form, Input, DatePicker, Upload } from "antd";
import React, { useEffect, useState } from "react";
import ImgCrop from "antd-img-crop";
import moment from "moment";
import axios from "axios";
import { useSnackbar } from "notistack";

const basePath = process.env.REACT_APP_API_URL;

const EditProfile = () => {
  const [user, setUser] = useState(null);
  const { enqueueSnackbar } = useSnackbar();
  const [fileList, setFileList] = useState([]);
  const onChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };
  const onPreview = async (file) => {
    let src = file.url;
    if (!src) {
      src = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file.originFileObj);
        reader.onload = () => resolve(reader.result);
      });
    }
    const image = new Image();
    image.src = src;
    const imgWindow = window.open(src);
    imgWindow?.document.write(image.outerHTML);
  };
  const onRemove = () => {
    if (user.company_logo) user.company_logo = "";
    console.log(`🚀🚀🚀  user.company_logo:`, user.company_logo);
    setFileList([]);
  };
  const handleSave = async (values) => {
    values = { ...values, fileList };
    if (!values.company_logo) {
      values.company_logo = values.fileList[0]?.response?.data;
      delete values.fileList;
    }
    try {
      const {
        first_name,
        last_name,
        email,
        street_number,
        street_name,
        city,
        country,
        mobile,
        dob,
        company_logo,
        street_1,
        street_2,
        direct,
        main_line,
        toll_free,
        fax,
        website_url,
      } = values;

      const res = await axios.post(`${basePath}/users/update`, {
        id: user?.id,
        first_name,
        last_name,
        email,
        street_number,
        street_name,
        city,
        country,
        mobile,
        dob,
        company_logo,
        street_1,
        street_2,
        direct,
        main_line,
        toll_free,
        fax,
        website_url,
      });
      enqueueSnackbar("Profile updated successfully", {
        variant: "success",
      });
    } catch (err) {
      enqueueSnackbar(err, { variant: "error" });
      console.error(err);
    }
  };
  const [form] = Form.useForm();

  useEffect(() => {
    async function fetchProfile() {
      const user_id = localStorage.getItem("userId");

      const res = await axios.get(`${basePath}/user/${user_id}`);
      res.data.user.dob = moment(res.data.user.dob, "YYYY-MM-DD");

      setUser(res.data.user);
      form.setFieldsValue(res.data.user);
    }
    fetchProfile();
  }, []);

  return (
    <div>
      <h1>Edit Profile</h1>
      <Form layout="vertical" onFinish={handleSave} form={form}>
        <Form.Item
          label="First Name"
          name="first_name"
          rules={[
            {
              required: true,
              message: "Please enter your first name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Last Name"
          name="last_name"
          rules={[
            {
              required: true,
              message: "Please enter your last name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item label="Company Name" name="company_name">
          <Input />
        </Form.Item>
        <Form.Item
          label="Email"
          name="email"
          rules={[
            {
              type: "email",
              message: "Please enter a valid email address!",
            },
            {
              required: true,
              message: "Please enter your email address!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Mobile"
          name="mobile"
          rules={[
            {
              required: true,
              message: "Please enter your mobile number!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item label="Address" name="address">
          <Input.TextArea />
        </Form.Item>
        <Form.Item label="Street Number" name="street_number">
          <Input />
        </Form.Item>
        <Form.Item label="Street Name" name="street_name">
          <Input />
        </Form.Item>
        <Form.Item label="City" name="city">
          <Input />
        </Form.Item>
        <Form.Item label="Country" name="country">
          <Input />
        </Form.Item>
        <Form.Item label="Date of Birth" name="dob">
          <DatePicker />
        </Form.Item>
        <Form.Item label="Contact Person Name" name="contactPersonName">
          <Input />
        </Form.Item>
        <Form.Item label="Contact Person Phone" name="contactPersonPhone">
          <Input />
        </Form.Item>
        <Form.Item name="images" label="Logo">
          <ImgCrop rotationSlider aspect={3 / 4}>
            <Upload
              name="Files"
              action={`${basePath}/upload`}
              listType="picture-card"
              fileList={
                user && user?.company_logo
                  ? [
                      {
                        url: `${basePath}/getFileById?uuid=${
                          user && user?.company_logo
                        }`,
                      },
                    ]
                  : null || fileList
              }
              onChange={onChange}
              onPreview={onPreview}
              onRemove={onRemove}
            >
              {!user?.company_logo && fileList.length < 1 && "+ Upload"}
            </Upload>
          </ImgCrop>
        </Form.Item>
        <Form.Item
          label="Street 1"
          name="street_1"
          rules={[
            {
              required: true,
              message: "Street 1 is required",
            },
            {
              pattern: /^[A-Za-z0-9.,'\/#\-]+$/,
              message:
                "Street 1 can only contain letters, numbers, and special characters: . , ' / # -",
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Street 2"
          name="street_2"
          rules={[
            {
              pattern: /^[A-Za-z0-9.,'\/#\-]*$/,
              message:
                "Street 2 can only contain letters, numbers, and special characters: . , ' / # -",
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Direct"
          name="direct"
          rules={[
            {
              pattern: /^[A-Za-z0-9+().\-]+$/,
              message:
                "Direct can only contain letters, numbers, and special characters: + ( ) - .",
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Main Line"
          name="main_line"
          rules={[
            {
              pattern: /^[A-Za-z0-9+().\-]+$/,
              message:
                "Main Line can only contain letters, numbers, and special characters: + ( ) - .",
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Toll Free"
          name="toll_free"
          rules={[
            {
              pattern: /^[A-Za-z0-9+().\-]+$/,
              message:
                "Toll Free can only contain letters, numbers, and special characters: + ( ) - .",
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Fax"
          name="fax"
          rules={[
            {
              pattern: /^[A-Za-z0-9+().\-]+$/,
              message:
                "Fax can only contain letters, numbers, and special characters: + ( ) - .",
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Website URL"
          name="website_url"
          rules={[
            {
              pattern: /^[A-Za-z0-9\/:\-_]+$/,
              message:
                "Website URL can only contain letters, numbers, and special characters: / : - _",
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default EditProfile;
