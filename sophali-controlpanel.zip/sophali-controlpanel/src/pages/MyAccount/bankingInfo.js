import { Button, Form, Input, Select } from "antd";
import React, { useEffect, useState } from "react";
import moment from "moment";
import axios from "axios";
import { useSnackbar } from "notistack";
import { loadStripe } from "@stripe/stripe-js";

const basePath = process.env.REACT_APP_API_URL;

const BankingInfo = () => {
  const [user, setUser] = useState(null);
  const { enqueueSnackbar } = useSnackbar();
  const handleSave = async (values) => {
    try {
      const {
        bank_name,
        account_holder_name,
        bank_account_number,
        bank_routing_number,
        account_type,
      } = values;

      const stripe = await loadStripe(process.env.REACT_APP_STRIPE_PUBLIC_KEY);
      const { error, token } = await stripe.createToken(
        "bank_account",
        {
          country: "CA",
          currency: "cad",
          routing_number: bank_routing_number,
          account_number: bank_account_number,
          account_holder_name: account_holder_name,
          account_holder_type: account_type,
        }
      );
      if (error) {
        console.error("[error]", error);
        enqueueSnackbar(error.message, { variant: "error" });
        return;
      } else {
        
        try {
          const response = await axios.post(
            `${basePath}/userInfo/add-banking-info-stripe`,
            {
              accountId: user.stripe_account_id,
              externalAccountToken: token.id,
            }
          );

          
        } catch (error) {
          console.error("Error:", error);
        }
      }
      const res = await axios.post(`${basePath}/userInfo/add-banking-info`, {
        id: user?.id,
        user_id: localStorage.getItem("userId"),
        bank_name,
        account_holder_name,
        bank_account_number,
        bank_routing_number,
        account_type,
      });

      enqueueSnackbar("Profile updated successfully", {
        variant: "success",
      });

      
    } catch (err) {
      enqueueSnackbar(err, { variant: "error" });
      console.error(err);
    }
  };
  const [form] = Form.useForm();

  useEffect(() => {
    async function fetchProfile() {
      const user_id = localStorage.getItem("userId");

      const res = await axios.get(
        `${basePath}/userInfo/get-banking-info?user_id=${user_id}`
      );
      
      // res.data.user.dob = moment(res.data.user.dob, "YYYY-MM-DD");
      
      setUser(res.data.bankInfo);
      form.setFieldsValue(res.data.bankInfo);
    }
    fetchProfile();
  }, []);

  return (
    <div>
      <h1>Banking Info</h1>
      <Form layout="vertical" onFinish={handleSave} form={form}>
        <Form.Item
          label="Bank Name"
          name="bank_name"
          rules={[
            {
              required: true,
              message: "Please enter your bank name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Account Holder Name"
          name="account_holder_name"
          rules={[
            {
              required: true,
              message: "Please enter the account holder name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Bank Account Number"
          name="bank_account_number"
          rules={[
            {
              required: true,
              message: "Please enter your bank account number!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Bank Routing Number (ABA)"
          name="bank_routing_number"
          rules={[
            {
              required: true,
              message: "Please enter your bank routing number!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Account Type"
          name="account_type"
          rules={[
            {
              required: true,
              message: "Please select an account type!",
            },
          ]}
        >
          <Select>
            <Select.Option value="company">Company</Select.Option>
            <Select.Option value="individual">Individual</Select.Option>
          </Select>
        </Form.Item>
        {/* <Form.Item label="Swift Code (optional)" name="swiftCode">
          <Input />
        </Form.Item>
        <Form.Item label="Bank Address (optional)" name="bankAddress">
          <Input.TextArea />
        </Form.Item> */}

        {/* Add more form items for banking info */}
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default BankingInfo;
