import { Button, Form, Input, Select, Tabs, Modal } from "antd";
import React, { useState } from "react";
import Settings from "../Setting";
import EditProfile from "./editProfile";
import ChangePassword from "./changePassword";
import BankingInfo from "./bankingInfo";
import BusinessInfo from "./businessInfo";
import QRCode from "qrcode.react"; // Import QRCode here

const { TabPane } = Tabs;

const MyAccount = () => {
  const [open, setOpen] = useState(false);

  const handleSave = (values) => {
    
  };

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>My Account</h2>
        <Button
          style={{ marginRight: "1px" }}
          type="primary"
          onClick={() => {
            setOpen(true);
          }}
        >
          View QR
        </Button>
      </div>
      <Tabs defaultActiveKey="1">
        <TabPane tab="Settings" key="1">
          <Settings />
        </TabPane>
        <TabPane tab="Business Info" key="2">
          <BusinessInfo />
        </TabPane>

        <TabPane tab="Banking Info" key="3">
          <BankingInfo />
        </TabPane>

        <TabPane tab="Edit Profile" key="4">
          <EditProfile />
        </TabPane>

        <TabPane tab="Change Password" key="5">
          <ChangePassword />
        </TabPane>
      </Tabs>

      {/* Add the modal here */}
      <Modal
        title="QR Code"
        open={open}
        onCancel={() => setOpen(false)}
        footer={null}
      >
        <QRCode value={localStorage.getItem('userId')} />
      </Modal>
    </div>
  );
};

export default MyAccount;
