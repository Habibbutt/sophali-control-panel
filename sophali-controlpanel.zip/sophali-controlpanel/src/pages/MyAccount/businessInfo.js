import { Button, Form, Input, Select } from "antd";
import React, { useEffect, useState } from "react";
import moment from "moment";
import axios from "axios";
import { useSnackbar } from "notistack";

const basePath = process.env.REACT_APP_API_URL;

const BusinessInfo = () => {
  const [user, setUser] = useState(null);
  const { enqueueSnackbar } = useSnackbar();
  const handleSave = async (values) => {
    try {
      const {
        business_name,
        business_address,
        contact_number,
        business_category,
      } = values;
      const res = await axios.post(
        `${basePath}/userInfo/add-business-info`,
        {
          id: user?.id,
          user_id: localStorage.getItem("userId"),
          business_name,
          business_address,
          contact_number,
          business_category,
        }
      );
      enqueueSnackbar("Profile updated successfully", {
        variant: "success",
      });

      
    } catch (err) {
      enqueueSnackbar(err, { variant: "error" });
      console.error(err);
    }
  };
  const [form] = Form.useForm();

  useEffect(() => {
    async function fetchProfile() {
      const user_id = localStorage.getItem("userId");

      const res = await axios.get(
        `${basePath}/userInfo/get-business-info?user_id=${user_id}`
      );
      
      // res.data.user.dob = moment(res.data.user.dob, "YYYY-MM-DD");
      
      setUser(res.data.businessInfo);
      form.setFieldsValue(res.data.businessInfo);
    }
    fetchProfile();
  }, []);

  return (
    <div>
      <h1>Business Info</h1>
      <Form layout="vertical" onFinish={handleSave} form={form}>
        <Form.Item
          label="Business Name"
          name="business_name"
          rules={[
            {
              required: true,
              message: "Please enter your business name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Business Address"
          name="business_address"
          rules={[
            {
              required: true,
              message: "Please enter your business address!",
            },
          ]}
        >
          <Input.TextArea />
        </Form.Item>
        <Form.Item
          label="Contact Number"
          name="contact_number"
          rules={[
            {
              required: true,
              message: "Please enter your contact number!",
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Business Category"
          name="business_category"
          rules={[
            {
              required: true,
              message: "Please select a business category!",
            },
          ]}
        >
          <Select>
            <Select.Option value="restaurant">Restaurant</Select.Option>
            <Select.Option value="fast_food">Fast Food</Select.Option>
            <Select.Option value="coffee_shop">Coffee Shop</Select.Option>
            <Select.Option value="ice_cream_parlor">
              Ice Cream Parlor
            </Select.Option>
            <Select.Option value="diner">Diner</Select.Option>
            <Select.Option value="cafe">Café</Select.Option>
            <Select.Option value="bakery">Bakery</Select.Option>
            <Select.Option value="bar">Bar</Select.Option>
            <Select.Option value="pub">Pub</Select.Option>
            <Select.Option value="food_truck">Food Truck</Select.Option>
            {/* Add more categories as needed */}
          </Select>
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default BusinessInfo;
