import { Button, Form, Input, DatePicker } from "antd";
import React, { useEffect, useState } from "react";
import moment from "moment";
import axios from "axios";
import { useSnackbar } from "notistack";

const basePath = process.env.REACT_APP_API_URL;

const EditProfile = () => {
  const user_id = localStorage.getItem("userId");
  const { enqueueSnackbar } = useSnackbar();
  const handleSave = async (values) => {
    try {
      const { currentPassword, newPassword, confirmNewPassword } = values;
      const res = await axios.post(`${basePath}/users/update-password`, {
        userId: user_id,
        old_password: currentPassword,
        password: newPassword,
        confirmPassword: confirmNewPassword,
      });
      enqueueSnackbar("Password updated successfully", {
        variant: "success",
      });
      
    } catch (err) {
      enqueueSnackbar(err, { variant: "error" });
      console.error(err);
    }
  };

  return (
    <div>
      <h1>Change Password</h1>
      <Form layout="vertical" onFinish={handleSave}>
        <Form.Item
          label="Current Password"
          name="currentPassword"
          rules={[
            {
              required: true,
              message: "Please enter your current password!",
            },
          ]}
        >
          <Input.Password />
        </Form.Item>
        <Form.Item
          label="New Password"
          name="newPassword"
          rules={[
            {
              required: true,
              message: "Please enter your new password!",
            },
          ]}
        >
          <Input.Password />
        </Form.Item>
        <Form.Item
          label="Confirm New Password"
          name="confirmNewPassword"
          rules={[
            {
              required: true,
              message: "Please confirm your new password!",
            },
            ({ getFieldValue }) => ({
              validator(_, value) {
                if (!value || getFieldValue("newPassword") === value) {
                  return Promise.resolve();
                }
                return Promise.reject(new Error("The passwords do not match!"));
              },
            }),
          ]}
        >
          <Input.Password />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default EditProfile;
