import React, { useEffect, useState } from "react";
import {
  Table,
  Button,
  Modal,
  Tabs,
  Typography,
  Space,
  Row,
  Col,
  Input,
  Form,
} from "antd";
import axios from "axios";
import { useSnackbar } from "notistack";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import { QrReader } from "react-qr-reader";
const { TabPane } = Tabs;
const { Title, Text } = Typography;

const Order = () => {
  const [orders, setOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [visible, setVisible] = useState(false);
  const [openQRReader, setOpenQRReader] = useState(false);
  const [collectedOrder, setCollectedOrder] = useState(null);
  const [basePath, setBasePath] = useState(process.env.REACT_APP_API_URL);
  const [activeTab, setActiveTab] = useState("new");
  const [visibleReceipt, setVisibleReceipt] = useState(false);
  const { enqueueSnackbar } = useSnackbar();

  const handleQRERROR = (err) => {
    console.error(err);
    enqueueSnackbar(err, { variant: "error" });
  };
  const handleQRSCAN = async (data) => {
    if (!data) {
      return;
    }

    await setOpenQRReader(false);
    await orderCollected(collectedOrder, data);
    setCollectedOrder(null);
  };

  const orderPickUp = async (order) => {
    setCollectedOrder(order);
    setOpenQRReader(true);
  };
  const collectedOrders = orders.filter(
    (order) => order.status === "collected"
  );
  const newOrders = orders.filter((order) => order.status === "new");
  const getTimeRemaining = (order) => {
    const now = new Date();
    const startTime = new Date(order.updatedAt);

    if (!startTime || isNaN(startTime.getTime())) {
      // Handle invalid startTime, e.g., provide a default value or throw an error
      // ...
    }

    const totalTime = order.total_time_in_minutes * 60 * 1000; // convert to milliseconds
    const endTime = new Date(startTime.getTime() + totalTime);
    const timeRemaining = endTime - now;

    return timeRemaining;
  };
  const handlePinSubmit = async (values) => {
    console.log(`🚀🚀🚀  values:`, values);
    // TODO: Check Pin's Validity
    if (true) {
      await orderCollected(collectedOrder, values.pin);
      setOpenQRReader(false);
    }
    // Handle PIN here...
  };
  const handleExportToExcel = () => {
    var ordersCopy = [];
    ordersCopy = orders.map((order) => {
      const flattenedOrderItems = order.OrderItems.reduce(
        (acc, item, index) => {
          acc[`ProductTitle-${index + 1}`] = item.Product.title;
          acc[`ProductDescription-${index + 1}`] = item.Product.description;
          acc[`ProductPrice-${index + 1}`] = item.Product.price;
          return acc;
        },
        {}
      );

      return {
        id: order.id,
        createdAt: order.createdAt,
        Status: order.status,
        UserId: order.User.id,
        UserScreenName: order.User.screenName,
        MerchantId: order.Merchant?.id,
        MerchantCompany_name: order.Merchant?.company_name,
        MerchantAddress: order.Merchant?.address,
        ...flattenedOrderItems,
      };
    });

    // Check if orders is an array and contains at least one object
    if (
      !Array.isArray(ordersCopy) ||
      ordersCopy.length === 0 ||
      typeof ordersCopy[0] !== "object"
    ) {
      console.error("Invalid orders data");
      return;
    }

    // Create a new workbook
    const workbook = XLSX.utils.book_new();

    // Convert the orders array to a worksheet
    const worksheet = XLSX.utils.json_to_sheet(ordersCopy);

    // Append the worksheet to the workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, "Orders");

    // Create a binary string representation of the workbook
    const wbout = XLSX.write(workbook, { bookType: "xlsx", type: "binary" });

    // Convert the binary string to an ArrayBuffer
    const buffer = new ArrayBuffer(wbout.length);
    const view = new Uint8Array(buffer);
    for (let i = 0; i < wbout.length; i++) {
      view[i] = wbout.charCodeAt(i) & 0xff;
    }

    // Save the ArrayBuffer as an Excel file
    const blob = new Blob([buffer], { type: "application/octet-stream" });
    saveAs(blob, "orders.xlsx");
  };
  const getColorCode = (remainingTime, totalTime) => {
    // convert total time to milliseconds
    totalTime = totalTime * 60 * 1000;
    // Calculate the elapsedPercentage
    const elapsedPercentage = ((totalTime - remainingTime) / totalTime) * 100;

    let buttonColor;
    if (elapsedPercentage >= 100) {
      buttonColor = "red";
    } else if (elapsedPercentage >= 70) {
      buttonColor = "yellow";
    } else {
      buttonColor = "green";
    }

    return buttonColor;
  };

  const acceptedOrders = orders
    .filter(
      (order) => order.status === "preparing" || order.status === "prepared"
    )
    .sort((a, b) => {
      if (a.status !== b.status) {
        // Sort by status first: preparing should come before prepared
        return a.status === "preparing" ? -1 : 1;
      } else {
        // If both orders have the same status, sort by time left
        return a.total_time_in_minutes - b.total_time_in_minutes;
      }
    });

  const cancelledOrders = orders.filter(
    (order) => order.status === "cancelled"
  );
  const handleTabChange = (key) => {
    setActiveTab(key);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    const parent_id =
      localStorage.getItem("parent_merchant_id") ||
      localStorage.getItem("userId");
    try {
      const result = await axios.get(
        `${basePath}/order/merchant-picknow-order?merchant_id=${parent_id}`
      );

      let orders = result.data.merchantPicknowOrder;

      orders = orders.map((order) => {
        let Items = [...order.OrderItems, ...order.TransferRedeemItems];
        let orderTotalTime = Items.reduce((highest, item) => {
          let timeInMinutes =
              item.Product?.time_type === 'hours'
                ? item.Product.time * 60
                : item.Product?.time ?? 0;
            return Math.max(highest, timeInMinutes);
        }, 0);

        return {
          ...order,
          total_time_in_minutes: orderTotalTime,
        };
      });

      setOrders(orders);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const acceptOrder = async (params) => {
    let orderId = params.id;
    let order = orders.find((order) => {
      return order.id === orderId;
    });
    try {
      let response = await axios.post(`${basePath}/merchants/orderStatus`, {
        user_id: params.user_id,
        merchant_id: params.merchant_id,
        merchant_name: localStorage.getItem("merchant_name"),
        order_id: params.id,
        totalOrderTime: order.total_time_in_minutes,
        status: "preparing",
        collected_color: "",
      });

      fetchOrders();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const markAsPrepared = async (params, color) => {
    try {
      let response = await axios.post(`${basePath}/merchants/orderStatus`, {
        user_id: params.user_id,
        merchant_id: params.merchant_id,
        merchant_name: localStorage.getItem("merchant_name"),
        order_id: params.id,
        status: "prepared",
        collected_color: color,
      });
      fetchOrders();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const cancelOrder = async (params) => {
    try {
      let response = await axios.post(`${basePath}/merchants/orderStatus`, {
        user_id: params.user_id,
        merchant_id: params.merchant_id,
        merchant_name: localStorage.getItem("merchant_name"),
        order_id: params.id,
        status: "cancelled",
        collected_color: "",
        type: "merchant",
      });
      fetchOrders();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const orderCollected = async (params, scanResultorPin) => {
    try {
      console.log(`🚀🚀🚀  params:`, params);
      console.log(`🚀🚀🚀  scanResultorPin:`, scanResultorPin);
      let response = await axios.post(`${basePath}/merchants/orderStatus`, {
        user_id: params.user_id,
        merchant_id: params.merchant_id,
        merchant_name: localStorage.getItem("merchant_name"),
        order_id: params.id,
        status: "collected",
        receiver_id: scanResultorPin,
        collected_color: params.collected_color,
      });
      fetchOrders();
    } catch (error) {
      console.error(error);
      enqueueSnackbar(error.response.data.message, { variant: "error" });
    }
  };
  const fetchDetails = async (orderId) => {
    try {
      let response = await axios.get(
        `${basePath}/receipt/merchant-purchase-order-m-receipt?order_id=${orderId}`
      );

      setSelectedOrder(response.data.merchantPurchaseOrderReceipt[0]);

      // setselectedOrder(response.data.merchantPurchaseOrderReceipt[0]);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDetailsClick = async (order) => {
    // setSelectedOrder(order);
    await fetchDetails(order.id);
    setVisible(true);
  };

  const handleOk = () => {
    setVisible(false);
    setSelectedOrder(null);
  };
  const handleReceiptOk = () => {
    setVisibleReceipt(false);
  };

  const columns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (text) => {
        return (
          <span>
            {new Date(text).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
              hour: "numeric",
              minute: "numeric",
              second: "numeric",
            })}{" "}
          </span>
        );
      },
    },
    {
      title: "Order",
      dataIndex: "id",
      key: "id",
      render: (text, record) => {
        return <span>P_{text}</span>;
      },
    },
    {
      title: "Total Order Time",
      dataIndex: "total_time_in_minutes",
      key: "total_time_in_minutes",
      render: (text) => {
        return <span>{text} minutes</span>;
      },
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text, record) => {
        // const statusColor = getStatusColor(record);
        if (text === "preparing") {
          const minutes = Math.floor(
            Math.abs(record.timeRemaining) / (60 * 1000)
          );
          const seconds = Math.floor(
            (Math.abs(record.timeRemaining) % (60 * 1000)) / 1000
          );
          const timePrefix = record.timeRemaining >= 0 ? "" : "-";

          return (
            <Button
              style={{
                backgroundColor: record.color,
                color: record.color == "yellow" ? "black" : "white",
              }}
              disabled
            >
              {`Preparing... (${timePrefix}${minutes} min ${seconds} sec)`}
            </Button>
          );
        } else if (text === "prepared") {
          return (
            <span
              style={{
                padding: "2px 5px",
                backgroundColor: record.collected_color,
                color: record.collected_color == "yellow" ? "black" : "white",
                borderRadius: "5px",
              }}
            >
              Prepared
            </span>
          );
        } else if (text === "collected") {
          return (
            <span
              style={{
                padding: "2px 5px",
                backgroundColor: record.collected_color,
                color: record.collected_color == "yellow" ? "black" : "white",
                borderRadius: "5px",
              }}
            >
              Collected
            </span>
          );
        } else if (text === "cancelled") {
          return <span className="gx-text-red">Cancelled</span>;
        }
      },
    },
    {
      title: "Details",
      key: "details",
      render: (text, record) => (
        <Button onClick={() => handleDetailsClick(record)}>
          Order Details
        </Button>
      ),
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) => {
        if (record.status === "preparing") {
          return (
            <Button
              onClick={() => {
                markAsPrepared(record, record.color || record.collected_color);
              }}
            >
              Mark as Prepared
            </Button>
          );
        } else if (
          record.status !== "cancelled" &&
          record.status !== "prepared" &&
          record.status !== "collected"
        ) {
          return (
            <Button
              danger
              onClick={() => {
                cancelOrder(record);
              }}
            >
              Cancel Order
            </Button>
          );
        } else if (record.status === "prepared") {
          return (
            <Button
              onClick={() => {
                // orderCollected(record);
                orderPickUp(record);
              }}
            >
              Pick Up
            </Button>
          );
        }
        return null;
      },
    },
  ];
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const options = {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
    };
    return date.toLocaleDateString("en-US", options);
  };
  const formatTime = (dateString) => {
    const date = new Date(dateString);
    const hours = date.getHours().toString().padStart(2, "0");
    const minutes = date.getMinutes().toString().padStart(2, "0");
    const seconds = date.getSeconds().toString().padStart(2, "0");
    return `${hours}:${minutes}:${seconds}`;
  };

  useEffect(() => {
    const hasPreparingOrders = orders.some(
      (order) => order.status === "preparing"
    );

    if (hasPreparingOrders) {
      const updateRemainingTime = () => {
        setOrders((prevOrders) =>
          prevOrders.map((order) => {
            if (order.status === "preparing") {
              const timeRemaining = getTimeRemaining(order);

              return {
                ...order,
                timeRemaining,
                color: getColorCode(timeRemaining, order.total_time_in_minutes),
              };
            }
            return order;
          })
        );
      };
      const timer = setInterval(updateRemainingTime, 1000);
      return () => clearInterval(timer);
    }
  }, [orders]);

  let subtotal = 0;
  let tax = 0;
  let discount = 0;
  let total = 0;

  if (selectedOrder) {
    if (selectedOrder?.OrderItems) {
      subtotal = selectedOrder?.OrderItems?.reduce(
        (acc, item) => acc + item.Product.price,
        0
      );
      selectedOrder.OrderItems.forEach((item) => {
        tax += (item.Product.price * item.Product.tax) / 100;
      });
    }
    tax = parseFloat(tax.toFixed(2));
    discount = selectedOrder?.discount_sophali_tokens / 5 || 0;
    total = subtotal + tax - discount;
    if (total < 0) {
      total = 0;
    }
  }
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Merchant Orders</h2>
        <Button
          style={{ marginRight: "1px" }}
          type="primary"
          onClick={() => {
            handleExportToExcel();
          }}
        >
          Export To Excel
        </Button>
      </div>
      <Tabs activeKey={activeTab} onChange={handleTabChange}>
        <TabPane tab="New Orders" key="new">
          <Table
            dataSource={newOrders}
            columns={columns}
            rowKey={(record) => record.id}
          />
        </TabPane>
        <TabPane tab="Accepted Orders" key="accepted">
          <Table
            dataSource={acceptedOrders}
            columns={columns}
            rowKey={(record) => record.id}
          />
        </TabPane>
        <TabPane tab="Declined" key="cancelled">
          <Table
            dataSource={cancelledOrders}
            columns={columns}
            rowKey={(record) => record.id}
          />
        </TabPane>
        <TabPane tab="Collected Orders" key="collected">
          <Table
            dataSource={collectedOrders}
            columns={columns}
            rowKey={(record) => record.id}
          />
        </TabPane>
      </Tabs>

      <Modal
        open={visible}
        onCancel={handleOk}
        footer={[
          <Button
            key="accept"
            color="primary"
            onClick={() => {
              if (selectedOrder?.status == "new") acceptOrder(selectedOrder);
              handleOk();
            }}
          >
            {selectedOrder?.status == "new" ? "Accept Order" : "Close"}
          </Button>,
          <Button
            key="receipt"
            color="primary"
            onClick={() => {
              setVisibleReceipt(true);
            }}
          >
            View Receipt
          </Button>,
        ]}
        width={1000}
        title="Order Details"
      >
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <Text strong>Purchase Item ID (P-ID):</Text>
          </Col>
          <Col span={6}>
            <Text>P_{selectedOrder?.id}</Text>
          </Col>
          <Col span={6}>
            <Text strong>Date of Transaction:</Text>
          </Col>
          <Col span={6}>
            <Text>{formatDate(selectedOrder?.createdAt)}</Text>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Time of Transaction:</p>
          </Col>
          <Col span={6}>
            <p>{formatTime(selectedOrder?.createdAt)}sec</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>UserID:</p>
          </Col>
          <Col span={6}>
            <p>U {selectedOrder?.User.id}</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>User Name:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.User.screenName}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>MerchantID:</p>
          </Col>
          <Col span={6}>
            <p>M {selectedOrder?.Merchant.id}</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Merchant Name:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.Merchant.company_name}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Merchant Address:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.Merchant.address}</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Special Instructions:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.special_instructions}</p>
          </Col>
          <Col span={6}></Col>
          <Col span={6}></Col>
        </Row>
        {selectedOrder?.OrderItems?.map((item, index) => (
          <>
            {" "}
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Item Purchased:</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.title}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Description:</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.description}</p>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Ingredients:</p>
              </Col>
              <Col span={6}>
                <p>{item.ingredients}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Addons:</p>
              </Col>
              <Col span={6}>
                <p>{item.addons}</p>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Addons Price (USD):</p>
              </Col>
              <Col span={6}>
                <p>${item.addons_total_sophali_tokens / 5}</p>
              </Col>
              <Col span={6}>
                <p
                  style={{
                    fontWeight: "bold",
                  }}
                >
                  Type:
                </p>
              </Col>
              <Col
                span={6}
                style={{
                  color: item.product_order_type == "Now" ? "#4caf50" : "",
                  fontWeight: item.product_order_type == "Now" ? "bold" : "",
                }}
              >
                <p>{item.product_order_type}</p>
              </Col>
            </Row>
            {item.product_order_type == "Transfer" && (
              <Row gutter={[16, 16]}>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>T-ID/G-ID:</p>
                </Col>
                <Col span={6}>
                  <p>{item.custom_id}</p>
                </Col>
                <Col span={6}></Col>
                <Col span={6}></Col>
              </Row>
            )}
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Price (USD):</p>
              </Col>
              <Col span={6}>
                <p>${item.Product.price}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Price (Tokens):</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.price * 5} tokens</p>
              </Col>
            </Row>
          </>
        ))}
        {selectedOrder?.TransferRedeemItems?.map((item, index) => (
          <>
            {" "}
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Item Purchased:</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.title}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Description:</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.description}</p>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Ingredients:</p>
              </Col>
              <Col span={6}>
                <p>{item.ingredients}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Addons:</p>
              </Col>
              <Col span={6}>
                <p>{item.addons}</p>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Addons Price (USD):</p>
              </Col>
              <Col span={6}>
                <p>$0</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Type:</p>
              </Col>
              <Col span={6}>
                <p>{item.product_order_type}</p>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>T-ID/G-ID:</p>
              </Col>
              <Col span={6}>
                <p>{item.custom_id}</p>
              </Col>
              <Col span={6}></Col>
              <Col span={6}></Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Price (USD):</p>
              </Col>
              <Col span={6}>
                <p>$0</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Price (Tokens):</p>
              </Col>
              <Col span={6}>
                <p>0 tokens</p>
              </Col>
            </Row>
          </>
        ))}
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Sub Total (USD):</p>
          </Col>
          <Col span={6}>
            <p>${subtotal.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Sub Total (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(subtotal * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Coupon Redeemed (USD):</p>
          </Col>
          <Col span={6}>
            <p>${discount.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Coupon Redeemed (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(discount * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Tax (USD):</p>
          </Col>
          <Col span={6}>
            <p>${tax.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Tax (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(tax * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Total (USD):</p>
          </Col>
          <Col span={6}>
            <p>${total.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Total (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(total * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
      </Modal>
      <Modal
        open={visibleReceipt}
        onCancel={handleReceiptOk}
        footer={[
          <Button
            key="accept"
            color="primary"
            onClick={() => {
              handleReceiptOk();
            }}
          >
            Close
          </Button>,
        ]}
        width={1000}
        title="Merchant Receipt"
      >
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <Text strong>Purchase Item ID (P-ID):</Text>
          </Col>
          <Col span={6}>
            <Text>P_{selectedOrder?.id}</Text>
          </Col>
          <Col span={6}>
            <Text strong>Date of Transaction:</Text>
          </Col>
          <Col span={6}>
            <Text>{formatDate(selectedOrder?.createdAt)}</Text>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Time of Transaction:</p>
          </Col>
          <Col span={6}>
            <p>{formatTime(selectedOrder?.createdAt)}sec</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>UserID:</p>
          </Col>
          <Col span={6}>
            <p>U {selectedOrder?.User.id}</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>User Name:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.User.screenName}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>MerchantID:</p>
          </Col>
          <Col span={6}>
            <p>M {selectedOrder?.Merchant.id}</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Merchant Name:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.Merchant.company_name}</p>
          </Col>
          <Col span={6}></Col>
          <Col span={6}></Col>
        </Row>
        {selectedOrder?.OrderItems?.map((item, index) => (
          <>
            {" "}
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Item Purchased:</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.title}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Addons:</p>
              </Col>
              <Col span={6}>
                <p>{item.addons}</p>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Addons Price (USD):</p>
              </Col>
              <Col span={6}>
                <p>${item.addons_total_sophali_tokens / 5}</p>
              </Col>
              <Col span={6}></Col>
              <Col span={6}></Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Price (USD):</p>
              </Col>
              <Col span={6}>
                <p>${item.Product.price}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Price (Tokens):</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.price * 5} tokens</p>
              </Col>
            </Row>
          </>
        ))}
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Sub Total (USD):</p>
          </Col>
          <Col span={6}>
            <p>${subtotal.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Sub Total (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(subtotal * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Coupon Redeemed (USD):</p>
          </Col>
          <Col span={6}>
            <p>${discount.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Coupon Redeemed (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(discount * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Tax (USD):</p>
          </Col>
          <Col span={6}>
            <p>${tax.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Tax (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(tax * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Total (USD):</p>
          </Col>
          <Col span={6}>
            <p>${total.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Total (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(total * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
      </Modal>
      <Modal
        title="Pickup Order"
        open={openQRReader}
        onCancel={() => setOpenQRReader(false)}
        footer={null}
      >
        {/* {openQRReader && (
          <QrReader
            delay={300}
            onError={handleQRERROR}
            onResult={handleQRSCAN}
            once={true} // Add this line
            style={{ width: "100%" }}
          />
        )} */}

        <Form onFinish={handlePinSubmit}>
          <Form.Item
            label="Enter User PIN"
            name="pin"
            rules={[
              { required: true, message: "Please input your PIN!" },
              {
                min: 1,
                message: "PIN should be greater than or equal to 6 characters!",
              },
            ]}
          >
            <Input.Password />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default Order;
