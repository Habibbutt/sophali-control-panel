import React, { useEffect, useState } from "react";
import {  Checkbox, Divider, Card  } from "antd";

const CheckboxGroup = Checkbox.Group;
const plainOptions = ['Merchant', 'List', 'Add', 'Edit', 'Delete'];
const defaultCheckedList = ['Merchant', 'Add'];

const Role = () => {
  
  const [checkedList, setCheckedList] = useState(defaultCheckedList);
  const [indeterminate, setIndeterminate] = useState(true);
  const [checkAll, setCheckAll] = useState(false);
  const onChange = (list) => {
    setCheckedList(list);
    setIndeterminate(!!list.length && list.length < plainOptions.length);
    setCheckAll(list.length === plainOptions.length);
  };
  const onCheckAllChange = (e) => {
    setCheckedList(e.target.checked ? plainOptions : []);
    setIndeterminate(false);
    setCheckAll(e.target.checked);
  };
  return (
    
    <div className="site-card-border-less-wrapper">
    <Card
      title="Role Management"
      bordered={false}
      style={{
        width: 920,
      }}
    >
      <Checkbox indeterminate={indeterminate} onChange={onCheckAllChange} checked={checkAll}>
        Check all
      </Checkbox>
      <Divider />
      <CheckboxGroup options={plainOptions} value={checkedList} onChange={onChange} />
    </Card>

    </div>
    
  );
};

export default Role;
