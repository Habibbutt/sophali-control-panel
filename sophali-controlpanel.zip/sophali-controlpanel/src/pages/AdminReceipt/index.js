import React, { useEffect, useState } from "react";

import {
  Button,
  Form,
  Input,
  DatePicker,
  InputNumber,
  Modal,
  Table,
} from "antd";
import axios from "axios";
import { EyeOutlined } from "@ant-design/icons";
import { useSnackbar } from "notistack";

const TopUpUserTokenModal = ({
  open,
  setOpen,
  token,
  setToken,
  onCreate,
  onCancel,
}) => {
  const [form] = Form.useForm();

  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(token || {});
  }, [token, form]);

  return (
    <Modal
      width={700}
      forceRender
      open={open}
      title={
        localStorage.getItem("userTypeId") == 3
          ? "Withdraw Merchant Token"
          : localStorage.getItem("userTypeId") == 1
          ? "Withdraw Admin Token"
          : "Top Up User Token"
      }
      okText={
        localStorage.getItem("userTypeId") == 3
          ? "Withdraw"
          : localStorage.getItem("userTypeId") == 1
          ? "Withdraw"
          : "Add"
      }
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setOpen(false);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpen(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Form.Item
          name="amount_cad"
          label={<span className="label-text">Amount in CAD</span>}
          validateTrigger={["onBlur"]}
          rules={[
            {
              required: true,
              message: "Please enter an amount in CAD.",
            },
            {
              pattern: new RegExp(/^\d+(\.d{1,2})?$/),
              message: "Please enter a valid amount in CAD.",
            },
          ]}
        >
          <InputNumber
            className="input"
            formatter={(value) =>
              `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            }
            parser={(value) => value.replace(/\$\s?|(,*)/g, "")}
            min={0}
            step={0.01}
            placeholder="Enter Amount"
          />
        </Form.Item>

        <Form.Item
          name="cardHolderName"
          label={<span className="label-text">Name on Card</span>}
          // validateTrigger={["onBlur"]}
          // rules={[
          //   {
          //     required: true,
          //     message: "Please enter the cardholder name.",
          //   },
          // ]}
        >
          <Input className="input" placeholder="cardholder name" />
        </Form.Item>

        <Form.Item
          name="creditCardNo"
          label={<span className="label-text">Card Number</span>}
          // validateTrigger={["onBlur"]}
          // rules={[
          //   {
          //     required: true,
          //     message: "Please enter a debit/credit card number.",
          //   },
          //   {
          //     pattern: new RegExp(/^\d{16}$/),
          //     message:
          //       "Please enter a valid debit/credit card number (16 digits).",
          //   },
          // ]}
        >
          <Input placeholder="Enter debit/credit card number" />
        </Form.Item>

        <Form.Item
          name="expiryDate"
          label={<span className="label-text">Card Expire Date</span>}
          // validateTrigger={["onBlur"]}
          // rules={[
          //   {
          //     required: true,
          //     message: "Please select the expiration date of the card.",
          //   },
          // ]}
        >
          <DatePicker
            className="input"
            format="MM/YY"
            placeholder="Select expiration date"
            allowClear={false}
          />
        </Form.Item>

        <Form.Item
          name="securityCode"
          label={<span className="label-text">CVV</span>}
          // validateTrigger={["onBlur"]}
          // rules={[
          //   {
          //     required: true,
          //     message: "Please enter the security code of the card.",
          //   },
          //   {
          //     pattern: new RegExp(/^\d{3,4}$/),
          //     message: "Please enter a valid security code (3 or 4 digits).",
          //   },
          // ]}
        >
          <Input
            className="input"
            maxLength={4}
            placeholder="Enter security code"
          />
        </Form.Item>

        <Form.Item
          name="zipCode"
          label={<span className="label-text">ZIP Code</span>}
          // validateTrigger={["onBlur"]}
          // rules={[
          //   {
          //     required: true,
          //     message: "Please enter the ZIP code of the card.",
          //   },
          //   {
          //     pattern: new RegExp(/^\d{5}$/),
          //     message: "Please enter a valid ZIP code (5 digits).",
          //   },
          // ]}
        >
          <Input className="input" maxLength={5} placeholder="Enter ZIP code" />
        </Form.Item>
      </Form>
    </Modal>
  );
};

const AdminReceipt = () => {
  const [tokens, setTokens] = useState([]);
  const [token, setToken] = useState(null);
  const [details, setDetails] = useState(null);
  const [open, setOpen] = useState(false);
  const [openDetail, setOpenDetail] = useState(false);
  const basePath = process.env.REACT_APP_API_URL;
  const { enqueueSnackbar } = useSnackbar();
  const fetchTokens = async () => {
    try {
      let result;
      if (localStorage.getItem("userTypeId") == 3) {
        result = await axios.get(
          `${basePath}/usertoken/getTokens?merchant_id=${localStorage.getItem(
            "userId"
          )}`
        );
      } else {
        result = await axios.get(
          `${basePath}/usertoken/getTokens?user_id=${localStorage.getItem(
            "userId"
          )}`
        );
      }
      let arr = [];
      let balance = 0;
      result.data.tokens.forEach((element) => {
        arr.push({
          id: element.id + element.type,
          transaction_id: element.helcium_transation_id,
          idForDetail: element.id,
          date: element.Date,
          earn_token: element.type == "earned" ? element.tokens : 0,
          used_token: element.type == "consumed" ? element.tokens : 0,
          balance: (balance +=
            element.type == "earned" ? element.tokens : -element.tokens),
        });
      });
      setTokens(arr.reverse());
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  useEffect(() => {
    fetchTokens();
  }, []);

  const handleCreate = async (values) => {
    let obj = {
      ...values.amount_cad,
      amount_cad: values.amount_cad,
      sophali_token_balance: values.amount_cad, // token.sophali_tokens_balance,
      user_id: localStorage.getItem("userId"),
      helcium_transation_id: new Date().getTime(),
      status: "active",
    };
    try {
      const result = await axios.post(`${basePath}/usertoken/add`, obj);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
    } finally {
      setOpen(false);
      setToken(null);
      fetchTokens();
    }
  };
  const handleWithdraw = async (values) => {
    let obj = {
      ...values.amount_cad,
      amount_cad: values.amount_cad,
      sophali_token_balance: values.amount_cad, // token.sophali_tokens_balance,
      helcium_transation_id: new Date().getTime(),
      status: "active",
    };
    if (localStorage.getItem("userTypeId") == 1) {
      obj.user_id = localStorage.getItem("userId");
    } else {
      obj.merchant_id = localStorage.getItem("userId");
    }

    try {
      const result = await axios.post(
        `${basePath}/merchants/withdraw-token`,
        obj
      );
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
    } finally {
      setOpen(false);
      setToken(null);
      fetchTokens();
    }
  };
  const getTransactionDetails = async (record) => {
    try {
      const result = await axios.get(
        `${basePath}/usertoken/getTransactionDetails?user_id=${localStorage.getItem(
          "userId"
        )}&id=${record.idForDetail}`
      );
      setDetails(result.data);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const columns = [
    {
      title: "Date",
      dataIndex: "date",
      key: "date",
    },
    {
      title: "Transaction Id",
      dataIndex: "earn_token",
      key: "transaction_id",
    },
    {
      title: "Earn Token",
      dataIndex: "earn_token",
      key: "earn_token",
    },
    {
      title: "Used Token",
      dataIndex: "used_token",
      key: "used_token",
    },
    // {
    //   title: "",
    //   key: "view",
    //   render: (text, record) => (
    //     <Button
    //       type="link"
    //       onClick={async () => {
    //         await getTransactionDetails(record);
    //         setOpenDetail(true);
    //       }}
    //     >
    //       <EyeOutlined />
    //     </Button>
    //   ),
    // },
  ];

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>{"Admin Receipts"}</h2>
      </div>
      <Table
        dataSource={tokens}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <TopUpUserTokenModal
        open={open}
        setOpen={setOpen}
        token={token}
        setToken={setToken}
        onCreate={
          localStorage.getItem("userTypeId") == 3
            ? handleWithdraw
            : localStorage.getItem("userTypeId") == 1
            ? handleWithdraw
            : handleCreate
        }
        onCancel={() => setOpen(false)}
      />
      <Modal
        open={openDetail}
        title="Transaction Details"
        onCancel={() => setOpenDetail(false)}
      >
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", marginBottom: "16px" }}>
            <p style={{ fontWeight: "bold", marginRight: "8px" }}>
              Transaction Date:
            </p>
            <p> {new Date().toLocaleDateString()} </p>
          </div>
          <div style={{ display: "flex", marginBottom: "16px" }}>
            <p style={{ fontWeight: "bold", marginRight: "8px" }}>Item:</p>
            <p> Pizza </p>
          </div>
          <div style={{ display: "flex", marginBottom: "16px" }}>
            <p style={{ fontWeight: "bold", marginRight: "8px" }}>
              Restaurant:
            </p>
            <p> ny212 </p>
          </div>
          <div style={{ display: "flex", marginBottom: "16px" }}>
            <p style={{ fontWeight: "bold", marginRight: "8px" }}>Amount:</p>
            <p> 100 Sophali tokens </p>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default AdminReceipt;
