import React, { useEffect, useState } from "react";
import { Card, Button, Modal, Form, Input, Descriptions } from "antd";
import { useSnackbar } from "notistack";
import axios from "axios";
import "./style.css"; // Import the CSS file
const basePath = process.env.REACT_APP_API_URL;
// const SubscriptionModal = ({
//   open,
//   setOpen,
//   plan,
//   setPlan,
//   onCreate,
//   onCancel,
// }) => {
//   const [form] = Form.useForm();

//   useEffect(() => {
//     form.resetFields();
//     form.setFieldsValue(plan || {});
//   }, [plan, form]);

//   return (
//     <Modal
//       visible={open}
//       title={plan ? "Edit Plan" : "Add Plan"}
//       okText={plan ? "Update" : "Add"}
//       cancelText="Cancel"
//       onCancel={() => {
//         form.resetFields();
//         onCancel();
//         setPlan(null);
//       }}
//       onOk={() => {
//         form
//           .validateFields()
//           .then((values) => {
//             form.resetFields();
//             onCreate(values);
//             setOpen(false);
//           })
//           .catch((info) => {
//             console.error("Validate Failed:", info);
//           });
//       }}
//     >
//       <Form form={form} name="form_in_modal">
//         <Form.Item
//           name="name"
//           label="Plan Name"
//           rules={[
//             {
//               required: true,
//               message: "Please Enter Plan Name!",
//             },
//           ]}
//         >
//           <Input />
//         </Form.Item>
//         <Form.Item
//           name="price"
//           label="Price"
//           rules={[
//             {
//               required: true,
//               message: "Please Enter Price!",
//             },
//           ]}
//         >
//           <Input />
//         </Form.Item>
//       </Form>
//     </Modal>
//   );
// };
//  <SubscriptionModal
//    open={open}
//    setOpen={setOpen}
//    plan={plan}
//    setPlan={setPlan}
//    onCreate={handleCreate}
//    onCancel={() => setOpen(false)}
//  />;
const Subscription = () => {
  const [plans, setPlans] = useState([]);
  const [plan, setPlan] = useState(null);
  const [open, setOpen] = useState(false);
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    fetchPlans();
  }, []);

  const fetchPlans = async () => {
    try {
      let response = await axios.get(`${basePath}/subscriptions/getAllPlans`);
      console.log(`🚀🚀🚀  response:`, response);
      setPlans(response?.data?.plans);
    } catch (error) {
      console.error(error);
      enqueueSnackbar(error.response?.data?.message || error.toString(), {
        variant: "error",
      });
    }
    // setPlans([
    //   {
    //     id: 1,
    //     name: "Bronze Plan",
    //     price: 75,
    //     features: [
    //       "Ability to offer Sophali Users your food services",
    //       "Ability to receive orders digitally respond with Acceptance",
    //       "Ability to see how many users are within your area",
    //       "Ability to see detailed reports on your business",
    //       "Ability to queue remote orders when busy",
    //       "Ability to accept payments via QR code. No PoS required",
    //     ],
    //     description: "Allow people to purchase remotely",
    //   },
    //   {
    //     id: 2,
    //     name: "Silver Plan",
    //     price: 100,
    //     features: [
    //       "All the features in the Basic plan",
    //       "Ability to send E-coupons to Sophali end users",
    //     ],
    //     description: "Reach out to your customers via E-coupons",
    //   },
    //   {
    //     id: 3,
    //     name: "Gold Plan",
    //     price: 125,
    //     features: [
    //       "All features of the Silver plan + delivery capability",
    //       "Ability to see details on drivers",
    //       "Ability to move drivers to different zones",
    //       "Ability to pool drivers with other merchants",
    //       "Ability to see breakdown of delivery charges",
    //       "Ability to login or logout the driver",
    //     ],
    //     description: "Delivery capability",
    //   },
    // ]);
  };

  // const handleCreate = async (values) => {
  //   try {
  //     if (plan) {
  //       await axios.put(`${basePath}/plans/update`, { id: plan.id, ...values });
  //       enqueueSnackbar("Plan updated successfully", { variant: "success" });
  //     } else {
  //       await axios.post(`${basePath}/plans/add`, values);
  //       enqueueSnackbar("Plan added successfully", { variant: "success" });
  //     }
  //     fetchPlans();
  //   } catch (error) {
  //     enqueueSnackbar(error.response?.data?.message || error.toString(), {
  //       variant: "error",
  //     });
  //   } finally {
  //     setOpen(false);
  //     setPlan(null);
  //   }
  // };

  // const handleDelete = async (id) => {
  //   try {
  //     await axios.delete(`${basePath}/plans/delete`, { id });
  //     enqueueSnackbar("Plan deleted successfully", { variant: "success" });
  //     setPlans(plans.filter((item) => item.id !== id));
  //   } catch (error) {
  //     enqueueSnackbar(error.response.data.message, { variant: "error" });
  //     console.error(error);
  //   }
  // };

  const cardStyle = {
    width: 350,
    margin: "15px",
  };

  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Subscription Plans</h2>
        {/* <Authorize moduleId={4} permissions="can_create"> */}
        <Button
          disabled
          style={{ marginRight: "1px" }}
          type="primary"
          onClick={() => {
            // setOpen(true);
            // setMerchant(null);
          }}
        >
          Add Subscription
        </Button>
        {/* </Authorize> */}
      </div>
      <div className="subscription-cards">
        {plans.map((plan) => (
          <Card className="subscription-card" style={cardStyle} key={plan.id}>
            <div
              style={{
                height: "100%",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <Card.Meta
                title={plan.name}
                description={
                  <>
                    <hr className="hr" />
                    <p>
                      Price: ${plan.price}
                      <br />
                      <span className="tinyText">{plan.duration}</span>
                      <br />
                    </p>
                    <p className="desc-span">
                      {plan.description}
                      <br />
                      {plan.isTrial == "yes" && (
                        <span className="tinyText">30 Days Free Trial</span>
                      )}
                    </p>

                    <div className="card-body">
                      <Descriptions column={1}>
                        {plan.Features.map((feature, index) => (
                          <Descriptions.Item key={index}>
                            <span className="bullet">&#8226;</span>
                            <span className="feature">{feature.name}</span>
                          </Descriptions.Item>
                        ))}
                      </Descriptions>
                    </div>
                  </>
                }
              />
              <div className="buttons" style={{ marginTop: "auto" }}>
                <Button
                  disabled
                  className="b"
                  type="primary"
                  block
                  // onClick={() => handleSubscribe(plan.id)}
                >
                  Edit
                </Button>
                <Button
                  disabled
                  className="b"
                  type="danger"
                  block
                  // onClick={() => handleSubscribe(plan.id)}
                >
                  Delete
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </>
  );
};

export default Subscription;
