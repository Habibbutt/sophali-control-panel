import React, { useEffect, useState } from "react";
import { Table, Button, Modal, Form, Input } from "antd";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import axios from "axios";
import Authorize from "../../components/Authorize/Authorize";
import { useSnackbar } from "notistack";

const { confirm } = Modal;

const showConfirm = (id, onDelete) => {
  confirm({
    title: "Do you want to delete this driver?",
    icon: <ExclamationCircleOutlined />,
    onOk() {
      onDelete(id);
    },
    onCancel() {},
  });
};

const AddDriverModal = ({
  open,
  setOpen,
  driver,
  setDriver,
  onCreate,
  onCancel,
}) => {
  const [form] = Form.useForm();
  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(driver || {});
  }, [driver, form]);

  return (
    <Modal
      forceRender
      open={open}
      title={driver ? "Edit Driver" : "Add Driver"}
      okText={driver ? "Update" : "Add"}
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setDriver(null);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpen(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Form.Item
          name="first_name"
          label="First Name"
          rules={[
            {
              required: true,
              message: "Please Enter First Name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="last_name" label="Last Name">
          <Input />
        </Form.Item>
        <Form.Item
          name="username"
          label="Username"
          rules={[
            {
              required: true,
              message: "Please Enter Username!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="email"
          label="Email"
          rules={[
            {
              required: true,
              message: "Please Enter Email!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="mobile" label="Mobile">
          <Input />
        </Form.Item>
        {!driver && (
          <Form.Item
            name="password"
            label="Password"
            rules={[
              {
                required: true,
                message: "Please Enter Password!",
              },
            ]}
          >
            <Input.Password />
          </Form.Item>
        )}
      </Form>
    </Modal>
  );
};

const Driver = () => {
  const [drivers, setDrivers] = useState([]);
  const [driver, setDriver] = useState(null);
  const [open, setOpen] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const basePath = process.env.REACT_APP_API_URL;
  useEffect(() => {
    fetchDrivers();
  }, []);
  const fetchDrivers = async () => {
    try {
      const result = await axios.post(`${basePath}/drivers/list`, {
        parent_id: localStorage.getItem("userId"),
      });
      setDrivers(result.data.drivers.rows);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const handleCreate = async (values) => {
    try {
      if (driver) {
        const result = await axios.post(`${basePath}/users/update`, {
          ...values,
          id: driver.id,
          parent_id: localStorage.getItem("userId"),
        });
        fetchDrivers();
      } else {
        values = {
          ...values,
          user_type_id: 6,
          user_role_id: 6,
          parent_id: localStorage.getItem("userId"),
        };
        const result = await axios.post(`${basePath}/users/add`, values);
        fetchDrivers();
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    } finally {
      setOpen(false);
      setDriver(null);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.post(`${basePath}/users/delete`, { id });
      const updatedDrivers = drivers.filter((item) => item.id !== id);
      setDrivers(updatedDrivers);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const columns = [
    {
      title: "First Name",
      dataIndex: "first_name",
      key: "first_name",
    },
    {
      title: "Last Name",
      dataIndex: "last_name",
      key: "last_name",
    },
    {
      title: "Username",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Mobile",
      dataIndex: "mobile",
      key: "mobile",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      dataIndex: "action",
      key: "action",
      render: (text, record) => (
        <span>
          <Authorize moduleId={6} permissions="can_update">
            <Button
              type="link"
              onClick={() => {
                setOpen(true);
                
                setDriver(record);
              }}
            >
              Edit
            </Button>
          </Authorize>
          <Authorize moduleId={6} permissions="can_delete">
            <Button
              type="link"
              onClick={() => {
                showConfirm(record.id, handleDelete);
              }}
            >
              Delete
            </Button>
          </Authorize>
        </span>
      ),
    },
  ];

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Drivers List</h2>
        <Authorize moduleId={6} permissions="can_create">
          <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              setOpen(true);
              setDriver(null);
            }}
          >
            Add Driver
          </Button>
        </Authorize>
      </div>
      <Table
        dataSource={drivers}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <AddDriverModal
        open={open}
        setOpen={setOpen}
        driver={driver}
        setDriver={setDriver}
        onCreate={handleCreate}
        onCancel={() => setOpen(false)}
      />
    </div>
  );
};

export default Driver;
