import React, { useEffect, useState } from "react";
import { Card, Button, Descriptions } from "antd";
import "./style.css"; // Import the CSS file
import { useSnackbar } from "notistack";
import axios from "axios";
const basePath = process.env.REACT_APP_API_URL;

const Subscription = () => {
  const [plans, setPlans] = useState([]);
  const [planId, setPlanId] = useState({});
  const [hasSubscription, setHasSubscription] = useState(false);
  const [subscriptionId, setSubscriptionId] = useState(null);
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    fetchPlans();
  }, []);

  const fetchPlans = async () => {
    try {
      let response = await axios.get(`${basePath}/subscriptions/getAllPlans`);
      console.log(`🚀🚀🚀  response:`, response);
      setPlans(response?.data?.plans);
    } catch (error) {
      console.error(error);
      enqueueSnackbar(error.response?.data?.message || error.toString(), {
        variant: "error",
      });
    }
  };
  const getSubscription = async () => {
    try {
      const merchantId = localStorage.getItem("userId");
      const response = await axios.get(
        `${basePath}/subscriptions/getSubscription?merchant_id=${merchantId}`
      );
      setPlanId(response?.data?.subscriptions[0]?.SubscriptionPlan?.id);
      setHasSubscription(
        response?.data?.subscriptions[0]?.SubscriptionPlan?.month_count
      );
      setSubscriptionId(response?.data?.subscriptions[0]?.id);
    } catch (error) {
      console.error(error);
      enqueueSnackbar(error.response?.data?.message || error.toString(), {
        variant: "error",
      });
    }
  };
  useEffect(() => {
    getSubscription();
  }, []);
  const handleSubscribe = async (planId) => {
    try {
      const merchantId = localStorage.getItem("userId");
      if (subscriptionId) {
        await axios.post(`${basePath}/subscriptions/changeSubscription`, {
          merchant_id: merchantId,
          subscription_id: subscriptionId,
          plan_id: planId,
        });
        enqueueSnackbar("Subscription changed successfully", {
          variant: "success",
        });
      } else {
        await axios.post(`${basePath}/subscribe`, {
          plan_id: planId,
          merchant_id: merchantId,
        });
        enqueueSnackbar("Subscription successful", { variant: "success" });
      }
      getSubscription();
    } catch (error) {
      enqueueSnackbar(error.response?.data?.message || error.toString(), {
        variant: "error",
      });
    }
  };

  const cardStyle = {
    width: 350,
    margin: "15px",
  };

  return (
    <>
      <h2>Subscription Plans</h2>
      <div className="subscription-cards">
        {plans.map((plan) => (
          <Card className="subscription-card" style={cardStyle} key={plan.id}>
            <div
              style={{
                height: "100%",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <Card.Meta
                title={plan.name}
                description={
                  <>
                    <hr className="hr" />
                    <p>
                      Price: ${plan.price}
                      <br />
                      <span className="tinyText">{plan.duration}</span>
                      <br />
                    </p>
                    <p className="desc-span">
                      {plan.description}
                      <br />
                      {!hasSubscription && (
                        <span className="tinyText">30 Days Free Trial</span>
                      )}
                    </p>

                    <div className="card-body">
                      <Descriptions column={1}>
                        {plan.Features.map((feature, index) => (
                          <Descriptions.Item key={index}>
                            <span className="bullet">&#8226;</span>
                            <span className="feature">{feature.name}</span>
                          </Descriptions.Item>
                        ))}
                      </Descriptions>
                    </div>
                  </>
                }
              />
              <div style={{ marginTop: "auto" }}>
                <Button
                  disabled={plan.id == planId}
                  className="subscribe-btn"
                  type="primary"
                  block
                  onClick={() => handleSubscribe(plan.id)}
                >
                  {plan.id == planId
                    ? "Subscribed"
                    : !hasSubscription
                    ? "Start Free Trial"
                    : "Subscribe"}
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </>
  );
};

export default Subscription;
