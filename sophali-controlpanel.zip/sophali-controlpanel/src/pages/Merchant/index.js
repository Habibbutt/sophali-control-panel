import React, { useEffect, useState } from "react";
import { Table, Button, Modal, Form, Input, Descriptions, Switch } from "antd";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import axios from "axios";
import Authorize from "../../components/Authorize/Authorize";
import { useSnackbar } from "notistack";
const { TextArea } = Input;
const { confirm } = Modal;

const showConfirm = (id, status, onActivate, onDeactivate, enqueueSnackbar) => {
  let comment = ""; // variable to hold the user's comment

  confirm({
    title: `${
      status == "active" ? "Deactivate Merchant" : "Activate Merchant"
    }`,
    icon: <ExclamationCircleOutlined />,
    content: (
      <div>
        <p>
          Are you sure you want to{" "}
          {status == "active" ? "deactivate" : "activate"} this merchant?
        </p>
        {status == "active" && (
          <Form>
            <Form.Item>
              <TextArea
                rows={4}
                placeholder="Please enter your reason for deactivation..."
                onChange={(e) => (comment = e.target.value)}
                style={{ marginTop: "10px" }}
              />
            </Form.Item>
          </Form>
        )}
      </div>
    ),
    okText: `${status == "active" ? "Deactivate" : "Activate"}`,
    cancelText: "Cancel",
    onOk() {
      return new Promise((resolve, reject) => {
        if (status == "active") {
          if (comment.trim().length > 0) {
            // add this validation
            onDeactivate(id, comment);
            resolve(); // resolve promise when complete
          } else {
            // The user has not entered a deactivation reason, you can show an error message here.
            enqueueSnackbar("Please enter a reason for deactivation.", {
              variant: "error",
            });
            reject(); // reject promise to prevent closing modal
          }
        } else {
          onActivate(id);
          resolve(); // resolve promise when complete
        }
      });
    },
  });
};
const AddMerchantModal = ({
  open,
  setOpen,
  merchant,
  setMerchant,
  onCreate,
  onCancel,
}) => {
  const [form] = Form.useForm();

  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(merchant || {});
  }, [merchant, form]);

  return (
    <Modal
      forceRender
      open={open}
      title={merchant ? "Edit Merchant" : "Add Merchant"}
      okText={merchant ? "Update" : "Add"}
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setMerchant(null);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpen(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Form.Item
          name="first_name"
          label="First Name"
          rules={[
            {
              required: true,
              message: "Please Enter First Name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="last_name" label="Last Name">
          <Input />
        </Form.Item>
        <Form.Item
          name="username"
          label="Username"
          rules={[
            {
              required: true,
              message: "Please Enter Username!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="email"
          label="Email"
          rules={[
            {
              type: "email",
              message: "The input is not valid E-mail!",
            },
            {
              required: true,
              message: "Please Enter Email!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="mobile" label="Mobile">
          <Input />
        </Form.Item>
        {!merchant && (
          <Form.Item
            name="password"
            label="Password"
            rules={[
              {
                required: true,
                message: "Please Enter Password!",
              },
              {
                min: 6,
                message: "Password must be at least 6 characters long!",
              },
            ]}
          >
            <Input.Password />
          </Form.Item>
        )}
      </Form>
    </Modal>
  );
};
const MerchantBankDetailsModal = ({ open, setOpen, bankDetails }) => {
  return (
    <Modal
      open={open}
      title="Bank Details"
      onCancel={() => setOpen(false)}
      footer={null}
      width={1000}
      centered={true}
    >
      <Descriptions bordered>
        <Descriptions.Item label="Bank Name">
          {bankDetails?.bank_name}
        </Descriptions.Item>
        <Descriptions.Item label="Account Number">
          {bankDetails?.bank_account_number}
        </Descriptions.Item>
        <Descriptions.Item label="Account Holder Name">
          {bankDetails?.account_holder_name}
        </Descriptions.Item>
        <Descriptions.Item label="Routing Number">
          {bankDetails?.bank_routing_number}
        </Descriptions.Item>
        <Descriptions.Item label="Account Type">
          {bankDetails?.account_type}
        </Descriptions.Item>
      </Descriptions>
    </Modal>
  );
};

const Merchant = () => {
  const [merchants, setMerchants] = useState([]);
  const [merchant, setMerchant] = useState(null);
  const [open, setOpen] = useState(false);
  const [bankDetailsOpen, setBankDetailsOpen] = useState(false);
  const [bankDetails, setBankDetails] = useState(null);
  const { enqueueSnackbar } = useSnackbar();
  const basePath = process.env.REACT_APP_API_URL;
  useEffect(() => {
    fetchMerchants();
  }, []);
  const fetchMerchants = async () => {
    try {
      const result = await axios.post(`${basePath}/users/list`, {
        UserTypeId: localStorage.getItem("userTypeId") == 3 ? 4 : 3,
        parent_id: localStorage.getItem("userId"),
      });
      setMerchants(result.data.users.rows);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const handleBankDetails = async (record) => {
    try {
      let res = await axios.get(
        `${basePath}/userInfo/get-banking-info?user_id=${record.id}`
      );
      console.log(`🚀🚀🚀  res:`, res);
      record = res.data.bankInfo;
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
    setBankDetails(record);
    setBankDetailsOpen(true);
  };

  const handleCreate = async (values) => {
    try {
      if (merchant) {
        await axios.post(`${basePath}/users/update`, {
          ...values,
          id: merchant.id,
          parent_id: localStorage.getItem("userId"),
        });
        enqueueSnackbar("Merchant updated successfully", {
          variant: "success",
        });
        fetchMerchants();
      } else {
        if (localStorage.getItem("userTypeId") == 3 && merchants.length >= 3) {
          enqueueSnackbar("You cannot add more than three sub merchants", {
            variant: "error",
          });
        } else {
          values = {
            ...values,
            user_type_id: localStorage.getItem("userTypeId") == 3 ? 4 : 3,
            user_role_id: localStorage.getItem("userTypeId") == 3 ? 4 : 3,
            parent_id: localStorage.getItem("userId"),
          };
          const result = await axios.post(`${basePath}/users/add`, values);
          enqueueSnackbar("Merchant added successfully", {
            variant: "success",
          });
        }
        fetchMerchants();
      }
    } catch (error) {
      console.error(error);
      enqueueSnackbar(error.response?.data?.message || error.toString(), {
        variant: "error",
      });
    } finally {
      setOpen(false);
      setMerchant(null);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.post(`${basePath}/users/delete`, { id });
      enqueueSnackbar("Merchant deleted successfully", {
        variant: "success",
      });
      const updatedMerchants = merchants.filter((item) => item.id !== id);
      setMerchants(updatedMerchants);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const handleActivate = async (id) => {
    try {
      let res = await axios.post(`${basePath}/users/activate`, {
        id,
      });
      console.log(`🚀🚀🚀  res:`, res);
      enqueueSnackbar(res.data.message, {
        variant: "success",
      });
      fetchMerchants();
    } catch (error) {
      console.error(error.response.data.message);
      enqueueSnackbar(error.response?.data?.message || error.toString(), {
        variant: "error",
      });
    }
  };
  const handleDeactivate = async (id, comment) => {
    try {
      let res = await axios.post(`${basePath}/users/deactivate`, {
        id,
        deactivation_reason: comment,
      });
      console.log(`🚀🚀🚀  res:`, res);
      enqueueSnackbar(res.data.message, {
        variant: "success",
      });
      fetchMerchants();
    } catch (error) {
      console.error(error.response.data.message);
      enqueueSnackbar(error.response.data.message, { variant: "error" });
    }
  };

  let columns = [
    {
      title: "First Name",
      dataIndex: "first_name",
      key: "first_name",
    },
    {
      title: "Last Name",
      dataIndex: "last_name",
      key: "last_name",
    },
    {
      title: "Username",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Mobile",
      dataIndex: "mobile",
      key: "mobile",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      dataIndex: "action",
      key: "action",
      render: (text, record) => (
        <span>
          <Authorize moduleId={4} permissions="can_update">
            <Button
              type="link"
              onClick={() => {
                setOpen(true);

                setMerchant(record);
              }}
            >
              Edit
            </Button>
          </Authorize>
          {/* <Authorize moduleId={4} permissions="can_delete">
            <Button
              type="link"
              onClick={() => {
                showConfirm(record.id, handleDelete);
              }}
            >
              Delete
            </Button>
          </Authorize> */}
          {localStorage.getItem("userTypeId") == 1 && (
            <>
              <Button
                type="link"
                onClick={() => {
                  console.log(`🚀🚀🚀  record:`, record);
                  showConfirm(
                    record.id,
                    record.status,
                    handleActivate,
                    handleDeactivate,
                    enqueueSnackbar
                  );
                }}
                className={record.status == "inactive" ? "" : "gx-text-red"}
              >
                {record.status == "active" ? "Deactivate" : "Activate"}
              </Button>
              <Button
                type="link"
                onClick={() => {
                  console.log(`🚀🚀🚀  record:`, record);
                  handleBankDetails(record);
                }}
              >
                View Banking Details
              </Button>
            </>
          )}
        </span>
      ),
    },
  ];
  if (localStorage.getItem("userTypeId") == 1) {
    columns.push({
      title: "Approve Merchant",
      dataIndex: "isSubscribed",
      key: "isSubscribed",
      render: (text, record) => (
        <span>
          <Switch
            checkedChildren="Approved"
            unCheckedChildren="Not Approved"
            checked={record.isSubscribed == "active" ? true : false}
            onChange={(checked) => {
              console.log(`🚀🚀🚀  checked:`, checked);
              let status = "inactive";
              if (checked) {
                status = "active";
              }
              axios
                .get(
                  `${basePath}/subscription-approve-reject?status=${status}&merchant_id=${record.id}`
                )
                .then((res) => {
                  console.log(`🚀🚀🚀  res:`, res);
                  fetchMerchants();
                })
                .catch((err) => {
                  console.log(`🚀🚀🚀  err:`, err);
                });
            }}
          />
        </span>
      ),
    });
  }
  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>
          {localStorage.getItem("userTypeId") == 3
            ? "Sub Merchant List"
            : "Merchants List"}
        </h2>
        <Authorize moduleId={4} permissions="can_create">
          <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              setOpen(true);
              setMerchant(null);
            }}
          >
            {localStorage.getItem("userTypeId") == 3
              ? "Add Sub Merchant"
              : "Add Merchant"}
          </Button>
        </Authorize>
      </div>
      <Table
        dataSource={merchants}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <AddMerchantModal
        open={open}
        setOpen={setOpen}
        merchant={merchant}
        setMerchant={setMerchant}
        onCreate={handleCreate}
        onCancel={() => setOpen(false)}
      />
      <MerchantBankDetailsModal
        open={bankDetailsOpen}
        setOpen={setBankDetailsOpen}
        bankDetails={bankDetails}
      />
    </>
  );
};

export default Merchant;
