import React, { useEffect, useState } from "react";
import { Table, Button } from "antd";
import axios from "axios";
import { useSnackbar } from "notistack";

const Order = () => {
  const [orders, setOrders] = useState([]);
  const [order, setOrder] = useState(null);
  const [open, setOpen] = useState(false);
  const basePath = process.env.REACT_APP_API_URL;
  const { enqueueSnackbar } = useSnackbar();
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const result = await axios.post(`${basePath}/user-orders`, {
          user_id: localStorage.getItem("userId"),
        });
        setOrders(result.data.orderList.rows);
      } catch (error) {
        enqueueSnackbar(error, { variant: "error" });
        console.error(error);
      }
    };

    fetchOrders();
  }, []);

  const columns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "createdAt",
    },
    {
      title: "Order",
      dataIndex: "id",
      key: "id",
    },

    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
  ];

  return (
    <div>
      <h2 style={{ marginLeft: "2px" }}>User Orders</h2>
      <Table
        dataSource={orders}
        columns={columns}
        rowKey={(record) => record.id}
      />
    </div>
  );
};

export default Order;
