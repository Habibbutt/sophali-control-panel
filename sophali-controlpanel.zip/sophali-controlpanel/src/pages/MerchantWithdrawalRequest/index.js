import React, { useEffect, useState } from "react";
import { Table, Button, Checkbox } from "antd";
import axios from "axios";
import { useSnackbar } from "notistack";

const basePath = process.env.REACT_APP_API_URL;

const MerchantWithdrawalRequest = () => {
  const [dataSource, setDataSource] = useState([]);
  const [selectedKeys, setSelectedKeys] = useState([]);
  const [allChecked, setAllChecked] = useState(false);

  const { enqueueSnackbar } = useSnackbar();

  const fetchRequests = async () => {
    try {
      const response = await axios.get(
        `${basePath}/merchantwithdrawalrequest/getAll`
      );
      console.log(`🚀🚀🚀  response:`, response);
      setDataSource(response.data.withdrawals);
    } catch (error) {
      console.log(`🚀🚀🚀  error:`, error);
      enqueueSnackbar("Error fetching data", { variant: "error" });
    }
  };
  useEffect(() => {
    fetchRequests();
  }, []);

  const columns = [
    {
      title: (
        <Checkbox
          onChange={(e) => {
            setAllChecked(e.target.checked);
            if (e.target.checked) {
              setSelectedKeys(
                dataSource
                  .filter((data) => data.status === "Pending Approval")
                  .map((data) => data.id)
              );
            } else {
              setSelectedKeys([]);
            }
          }}
          checked={allChecked}
        />
      ),
      dataIndex: "select",
      key: "select",
      render: (_, record) => (
        <Checkbox
          checked={selectedKeys.includes(record.id)}
          disabled={record.status !== "Pending Approval"}
          onChange={(e) => {
            if (e.target.checked) {
              setSelectedKeys((prevKeys) => [...prevKeys, record.id]);
            } else {
              setSelectedKeys((prevKeys) =>
                prevKeys.filter((key) => key !== record.id)
              );
              setAllChecked(false);
            }
          }}
        />
      ),
    },
    {
      title: "Date/Time",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (text) => {
        return (
          <span>
            {new Date(text).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
              hour: "numeric",
              minute: "numeric",
              second: "numeric",
            })}{" "}
          </span>
        );
      },
    },
    {
      title: "Merchant Name",
      dataIndex: "merchant_name",
      key: "merchant_name",
      render: (text, record) => {
        return (
          <span>
            {record.merchant.first_name} {record.merchant.last_name}
          </span>
        );
      },
    },
    {
      title: "Withdrawal Amount",
      dataIndex: "withdrawal_amount",
      key: "withdrawal_amount",
    },
    {
      title: "Withdrawal Fee",
      dataIndex: "sophali_fee",
      key: "sophali_fee",
    },
    {
      title: "Monthly Subscription Fee Status",
      dataIndex: "subscription_status",
      key: "subscription_status",
      render: (text) => {
        return <span>{text ? "Paid" : "Not Paid"}</span>;
      },
    },
    {
      title: "Withdrawal Status",
      dataIndex: "status",
      key: "status",
    },
    {
      title: "Actions",
      key: "action",
      render: (text, record) =>
        record.status === "Pending Approval" && (
          <span>
            <Button
              type="link"
              onClick={() => {
                accept(record);
              }}
            >
              Accept
            </Button>
            <Button
              type="link"
              onClick={() => {
                reject(record);
              }}
            >
              Reject
            </Button>
          </span>
        ),
    },
  ];
  const accept = async (record) => {
    try {
      let res = await axios.post(
        `${basePath}/merchantwithdrawalrequest/update`,
        {
          id: record.id,
          status: "Accepted",
        }
      );
      console.log(`🚀🚀🚀  res:`, res);
      setAllChecked(false);
      setSelectedKeys([]);
      fetchRequests();
      enqueueSnackbar("Successfully accepted request", { variant: "success" });
    } catch (error) {
      console.error(error);
      enqueueSnackbar("Error accepting request", { variant: "error" });
    }
  };
  const reject = async (record) => {
    try {
      let res = await axios.post(
        `${basePath}/merchantwithdrawalrequest/update`,
        {
          id: record.id,
          status: "Rejected",
        }
      );
      console.log(`🚀🚀🚀  res:`, res);
      setAllChecked(false);
      setSelectedKeys([]);
      fetchRequests();
      enqueueSnackbar("Successfully rejected request", { variant: "success" });
    } catch (error) {
      console.error(error);
      enqueueSnackbar("Error rejecting request", { variant: "error" });
    }
  };

  const acceptAll = async () => {
    try {
      let res = await axios.post(
        `${basePath}/merchantwithdrawalrequest/bulkUpdate`,
        {
          ids: selectedKeys,
          status: "Accepted",
        }
      );
      console.log(`🚀🚀🚀  res:`, res);
      setAllChecked(false);
      setSelectedKeys([]);
      fetchRequests();
      enqueueSnackbar("Successfully accepted all selected requests", {
        variant: "success",
      });
    } catch (error) {
      console.error(error);
      enqueueSnackbar("Error accepting requests", { variant: "error" });
    }
  };

  const rejectAll = async () => {
    try {
      let res = await axios.post(
        `${basePath}/merchantwithdrawalrequest/bulkUpdate`,
        {
          ids: selectedKeys,
          status: "Rejected",
        }
      );
      console.log(`🚀🚀🚀  res:`, res);
      setAllChecked(false);
      setSelectedKeys([]);
      fetchRequests();
      enqueueSnackbar("Successfully rejected all selected requests", {
        variant: "success",
      });
    } catch (error) {
      console.error(error);
      enqueueSnackbar("Error rejecting requests", { variant: "error" });
    }
  };

  return (
    <div>
      <div className="gx-d-flex gx-justify-content-between">
        {" "}
        <h2 style={{ marginLeft: "2px" }}>Withdrawal Requests</h2>
        <div>
          <Button
            type="primary"
            onClick={acceptAll}
            disabled={!selectedKeys.length}
          >
            Accept All
          </Button>
          <Button
            type="primary"
            onClick={rejectAll}
            disabled={!selectedKeys.length}
          >
            Reject All
          </Button>
        </div>
      </div>
      <Table
        dataSource={dataSource}
        columns={columns}
        rowKey={(record) => record.id}
      />
    </div>
  );
};

export default MerchantWithdrawalRequest;
