import React, { useEffect, useState } from "react";
import { Table, Button } from "antd";
import axios from "axios";
import { useSnackbar } from "notistack";

const Notification = () => {
  const [notifications, setNotifications] = useState([]);
  const [notification, setNotification] = useState(null);
  const [open, setOpen] = useState(false);
  const basePath = process.env.REACT_APP_API_URL;
  const { enqueueSnackbar } = useSnackbar();
  const fetchNotifications = async () => {
    try {
      const result = await axios.get(
        `${basePath}/notifications?merchant_id=${localStorage.getItem(
          "userId"
        )}`
      );
      
      setNotifications(result.data);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  useEffect(() => {
    fetchNotifications();
  }, []);
  const markAsRead = async (record) => {
    try {
      const result = await axios.post(
        `${basePath}/notifications/mark-as-read`,
        {
          id: record.id,
          merchant_id: localStorage.getItem("userId"),
        }
      );
      
      fetchNotifications();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const columns = [
    {
      title: "Date/Time",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (text) => {
        return (
          <span>
            {new Date(text).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
              hour: "numeric",
              minute: "numeric",
              second: "numeric",
            })}{" "}
          </span>
        );
      },
    },
    {
      title: "Message",
      dataIndex: "message",
      key: "message",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      key: "action",
      render: (text, record) =>
        record.status === "unread" ? (
          <span>
            <Button
              type="link"
              onClick={() => {
                markAsRead(record);
              }}
            >
              Mark as Read
            </Button>
          </span>
        ) : null,
    },
  ];

  return (
    <div>
      <h2 style={{ marginLeft: "2px" }}>Merchant Notifications</h2>
      <Table
        dataSource={notifications}
        columns={columns}
        rowKey={(record) => record.id}
      />
    </div>
  );
};

export default Notification;
