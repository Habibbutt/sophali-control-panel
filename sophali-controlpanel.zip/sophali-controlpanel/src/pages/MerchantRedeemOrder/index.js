import React, { useEffect, useState } from "react";
import { Table, Button, Modal, Tabs, Typography, Input, Row, Col } from "antd";
import axios from "axios";
import { useSnackbar } from "notistack";
const { TabPane } = Tabs;
const {  Text } = Typography;

const Order = () => {
  const [orders, setOrders] = useState([]);
  const [order, setOrder] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [visible, setVisible] = useState(false);
  const [searchModal, setSearchModal] = useState(false);
  const [basePath, setBasePath] = useState(process.env.REACT_APP_API_URL);
  const [activeTab, setActiveTab] = useState("new");
  const [giftId, setGiftId] = useState("");

  const { enqueueSnackbar } = useSnackbar();
  const collectedOrders = orders.filter(
    (order) => order.status === "collected"
  );
  const newOrders = orders.filter((order) => order.status === "preparing");
  const handleTabChange = (key) => {
    setActiveTab(key);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleSearch = async () => {
    try {
      const response = await axios.get(
        `${basePath}/order/merchant-redeem-order-search?custom_id=${giftId}`
      );

      setOrder(response.data.merchantRedeemOrder);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const fetchOrders = async () => {
    const parent_id =
      localStorage.getItem("parent_merchant_id") ||
      localStorage.getItem("userId");
    try {
      const result = await axios.get(
        `${basePath}/order/merchant-redeem-order?merchant_id=${parent_id}`
      );

      let orders = result.data.merchantRedeemOrder;
      orders = orders.map((order) => {
        order.createdAt = order.Order.createdAt;
        return order;
      });

      // orders = orders.map((order) => {
      //   let orderTotalTime = order.OrderItems.reduce((total, item) => {
      //     let timeInMinutes =
      //       item.Product.time_type === "hours"
      //         ? item.Product.time * 60
      //         : item.Product.time;
      //     return total + timeInMinutes;
      //   }, 0);
      //   return {
      //     ...order,
      //     total_time_in_minutes: orderTotalTime,
      //   };
      // });
      //
      setOrders(orders);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const orderCollected = async (params) => {
    try {
      let response = await axios.post(
        `${basePath}/merchants/orderStatusItems`,
        {
          user_id: params.user_id,
          merchant_id: params.merchant_id,
          merchant_name: localStorage.getItem("merchant_name"),
          item_id: params.id,
          status: "collected",
        }
      );
      fetchOrders();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const orderPreparing = async () => {
    try {
      let response = await axios.post(
        `${basePath}/merchants/orderStatusItems`,
        {
          user_id: order.Order.user_id,
          merchant_id: order.Order.merchant_id,
          merchant_name: localStorage.getItem("merchant_name"),
          item_id: order.id,
          status: "preparing",
        }
      );
      setSearchModal(false);
      fetchOrders();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const fetchDetails = async (orderId) => {
    try {
      let response = await axios.get(
        `${basePath}/receipt/merchant-redeem-item-r-receipt?item_id=${orderId}`
      );
      setSelectedOrder(response.data.merchantRedeemItemReceipt[0]);

      // setselectedOrder(response.data.merchantPurchaseOrderReceipt[0]);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDetailsClick = async (order) => {
    // setSelectedOrder(order);
    await fetchDetails(order.id);
    setVisible(true);
  };

  const handleOk = () => {
    setVisible(false);
    setSelectedOrder(null);
  };

  const columns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (text) => {
        return (
          <span>
            {new Date(text).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
              hour: "numeric",
              minute: "numeric",
              second: "numeric",
            })}{" "}
          </span>
        );
      },
    },
    {
      title: "Order",
      dataIndex: "custom_id",
      key: "custom_id",
    },
    // {
    //   title: "Total Order Time",
    //   dataIndex: "total_time_in_minutes",
    //   key: "total_time_in_minutes",
    //   render: (text) => {
    //     return <span>{text} minutes</span>;
    //   },
    // },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
    },
    {
      title: "Details",
      key: "details",
      render: (text, record) => (
        <Button onClick={() => handleDetailsClick(record)}>
          Merchant Reciept
        </Button>
      ),
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) => {
        if (record.status === "preparing") {
          return (
            <Button
              onClick={() => {
                orderCollected(record);
              }}
            >
              Mark as Recieved
            </Button>
          );
        }
        return null;
      },
    },
  ];
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const options = {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
    };
    return date.toLocaleDateString("en-US", options);
  };
  const formatTime = (dateString) => {
    const date = new Date(dateString);
    const hours = date.getHours().toString().padStart(2, "0");
    const minutes = date.getMinutes().toString().padStart(2, "0");
    const seconds = date.getSeconds().toString().padStart(2, "0");
    return `${hours}:${minutes}:${seconds}`;
  };

  let subtotal = 0;
  let tax = 0;
  let discount = 0;
  let total = 0;

  if (selectedOrder) {
    if (selectedOrder?.OrderItems) {
      subtotal = selectedOrder?.OrderItems?.reduce(
        (acc, item) => acc + item.Product.price,
        0
      );
      selectedOrder.OrderItems.forEach((item) => {
        tax += (item.Product.price * item.Product.tax) / 100;
      });
    }
    tax = parseFloat(tax.toFixed(2));
    discount = selectedOrder?.discount_sophali_tokens / 5 || 0;
    total = subtotal + tax - discount;
    if (total < 0) {
      total = 0;
    }
  }
  return (
    <div>
      <h2 style={{ marginLeft: "2px" }}>Merchant Redeem Orders</h2>
      <Tabs activeKey={activeTab} onChange={handleTabChange}>
        <TabPane tab="New Orders" key="new">
          <div>
            {" "}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "baseline",
              }}
            >
              <h2 style={{ marginLeft: "2px" }}>Products List</h2>
              <Button
                style={{ marginRight: "1px" }}
                type="primary"
                onClick={() => {
                  setSearchModal(true);
                  // setProduct("");
                }}
              >
                Search Redeem Order
              </Button>
            </div>
            <Table
              dataSource={newOrders}
              columns={columns}
              rowKey={(record) => record.id}
            />
          </div>
        </TabPane>
        <TabPane tab="Collected Orders" key="collected">
          <Table
            dataSource={collectedOrders}
            columns={columns}
            rowKey={(record) => record.id}
          />
        </TabPane>
      </Tabs>

      <Modal
        open={visible}
        onOk={handleOk}
        onCancel={handleOk}
        footer={[
          <Button key="close" onClick={handleOk}>
            Close
          </Button>,
        ]}
        width={1000}
        title="Merchant Receipt"
      >
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <Text strong>Purchase Item ID (P-ID):</Text>
          </Col>
          <Col span={6}>
            <Text>{selectedOrder?.OrderItems[0].custom_id}</Text>
          </Col>
          <Col span={6}>
            <Text strong>Date of Transaction:</Text>
          </Col>
          <Col span={6}>
            <Text>{formatDate(selectedOrder?.createdAt)}</Text>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Time of Transaction:</p>
          </Col>
          <Col span={6}>
            <p>{formatTime(selectedOrder?.createdAt)}sec</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>UserID:</p>
          </Col>
          <Col span={6}>
            <p>U {selectedOrder?.User.id}</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>User Name:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.User.screenName}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>MerchantID:</p>
          </Col>
          <Col span={6}>
            <p>M {selectedOrder?.Merchant.id}</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Merchant Name:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.Merchant.company_name}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Merchant Address:</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.Merchant.address}</p>
          </Col>
        </Row>
        {selectedOrder?.OrderItems?.map((item, index) => (
          <>
            {" "}
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Item Purchased:</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.title}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Description:</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.description}</p>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Price (USD):</p>
              </Col>
              <Col span={6}>
                <p>${item.Product.price}</p>
              </Col>
              <Col span={6}>
                <p style={{ fontWeight: "bold" }}>Price (Tokens):</p>
              </Col>
              <Col span={6}>
                <p>{item.Product.price * 5} tokens</p>
              </Col>
            </Row>
          </>
        ))}
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Sub Total (USD):</p>
          </Col>
          <Col span={6}>
            <p>${subtotal.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Sub Total (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(subtotal * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Coupon Redeemed (USD):</p>
          </Col>
          <Col span={6}>
            <p>${discount.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Coupon Redeemed (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(discount * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Tax (USD):</p>
          </Col>
          <Col span={6}>
            <p>${tax.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Tax (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(tax * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
        {/* <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Gratuity (USD):</p>
          </Col>
          <Col span={6}>
            <p>${selectedOrder?.gratuity_usd}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Gratuity (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.gratuity_sophali} tokens</p>
          </Col>
        </Row> */}
        {/* <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Delivery Charges (USD):</p>
          </Col>
          <Col span={6}>
            <p>${selectedOrder?.delivery_charges_usd}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Delivery Charges (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{selectedOrder?.delivery_charges_sophali} tokens</p>
          </Col>
        </Row> */}
        {/* <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Transaction Charges (USD):</p>
          </Col>
          <Col span={6}>
            <p>$0.40</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Transaction Charges (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>2 tokens</p>
          </Col>
        </Row> */}
        <Row gutter={[16, 16]}>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Total (USD):</p>
          </Col>
          <Col span={6}>
            <p>${total.toFixed(2)}</p>
          </Col>
          <Col span={6}>
            <p style={{ fontWeight: "bold" }}>Total (Tokens):</p>
          </Col>
          <Col span={6}>
            <p>{(total * 5).toFixed(2)} tokens</p>
          </Col>
        </Row>
      </Modal>
      <Modal
        title="Search"
        open={searchModal}
        width={800}
        okText="Start Preparing"
        onOk={orderPreparing}
        onCancel={() => {
          setSearchModal(false);
        }}
      >
        <Row gutter={[16, 16]}>
          <Col span={20}>
            <Input
              placeholder="Enter Transfer/Gift ID"
              value={giftId}
              onChange={(e) => setGiftId(e.target.value)}
            />
          </Col>
          <Col span={4}>
            <Button
              type="primary"
              onClick={() => {
                handleSearch();
              }}
            >
              Search
            </Button>
          </Col>
        </Row>
        <br />
        {order && (
          <Row gutter={[16, 16]}>
            <Col span={24}>
              <Row gutter={[16, 16]}>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Order ID:</p>
                </Col>
                <Col span={6}>
                  <p>{order.custom_id}</p>
                </Col>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Order Date:</p>
                </Col>
                <Col span={6}>
                  <p>{formatDate(order.Order.createdAt)}</p>
                </Col>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Order Status:</p>
                </Col>
                <Col span={6}>
                  <p>{order.status}</p>
                </Col>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Ingredients:</p>
                </Col>
                <Col span={6}>
                  <p>{order.ingredients}</p>
                </Col>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Addons:</p>
                </Col>
                <Col span={6}>
                  <p>{order.addons}</p>
                </Col>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Addons Price (USD):</p>
                </Col>
                <Col span={6}>
                  <p>${order.addons_total_sophali_tokens / 5}</p>
                </Col>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Order Type:</p>
                </Col>
                <Col span={6}>
                  <p>{order.product_order_type}</p>
                </Col>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Product Title:</p>
                </Col>
                <Col span={6}>
                  <p>{order.Product.title}</p>
                </Col>
                <Col span={6}>
                  <p style={{ fontWeight: "bold" }}>Product Price:</p>
                </Col>
                <Col span={6}>
                  <p>${order.Product.price}</p>
                </Col>
              </Row>
            </Col>
          </Row>
        )}
      </Modal>
    </div>
  );
};

export default Order;
