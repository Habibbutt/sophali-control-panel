import { Button, Form, Input, Select, Tabs, DatePicker } from "antd";
import React from "react";
import Product from "../Product";
import Category from "../Category";
import Addons from "../Addons";

const { TabPane } = Tabs;

const Menu = () => {
  const handleSave = (values) => {
    
  };

  return (
    <div>
      <h1>Menu</h1>
      <Tabs defaultActiveKey="1">
        <TabPane tab="Category" key="1">
          <Category />
        </TabPane>

        <TabPane tab="Product" key="3">
          <Product />
        </TabPane>

        <TabPane tab="Addons" key="2">
          <Addons />
        </TabPane>
      </Tabs>
    </div>
  );
};

export default Menu;
