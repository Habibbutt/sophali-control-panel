import { ExclamationCircleOutlined } from "@ant-design/icons";
import { Button, Form, Input, Modal, Table } from "antd";
import axios from "axios";
import React, { useCallback, useEffect, useState } from "react";
import Authorize from "../../components/Authorize/Authorize";
import { useSnackbar } from "notistack";

const { confirm } = Modal;

const showConfirm = (id, onDelete) => {
  confirm({
    title: "Do you want to delete this user?",
    icon: <ExclamationCircleOutlined />,
    onOk() {
      onDelete(id);
    },
    onCancel() {},
  });
};

const AddUserModal = ({ open, setOpen, user, setUser, onCreate, onCancel }) => {
  const [form] = Form.useForm();
  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(user || {});
  }, [user, form]);

  return (
    <Modal
      forceRender
      open={open}
      title={user ? "Edit User" : "Add User"}
      okText={user ? "Update" : "Add"}
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setUser(null);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpen(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Form.Item
          name="first_name"
          label="First Name"
          rules={[
            {
              required: true,
              message: "Please Enter First Name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="last_name" label="Last Name">
          <Input />
        </Form.Item>
        <Form.Item
          name="username"
          label="Username"
          rules={[
            {
              required: true,
              message: "Please Enter Username!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="email"
          label="Email"
          rules={[
            {
              required: true,
              message: "Please Enter Email!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="mobile" label="Mobile">
          <Input />
        </Form.Item>
        {!user && (
          <Form.Item
            name="password"
            label="Password"
            rules={[
              {
                required: true,
                message: "Please Enter Password!",
              },
            ]}
          >
            <Input.Password />
          </Form.Item>
        )}
      </Form>
    </Modal>
  );
};

const Users = () => {
  const [users, setUsers] = useState([]);
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState(null);
  const basePath = process.env.REACT_APP_API_URL;
  const { enqueueSnackbar } = useSnackbar();
  const fetchData = useCallback(async () => {
    try {
      const result = await axios.post(`${basePath}/users/list`, {
        UserTypeId: 5,
        parent_id: localStorage.getItem("userId"),
      });
      setUsers(result.data.users.rows);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  }, [enqueueSnackbar, basePath]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleCreate = async (values) => {
    try {
      if (user) {
        await axios.post(`${basePath}/users/update`, {
          ...values,
          id: user.id,
          parent_id: localStorage.getItem("userId"),
        });
        enqueueSnackbar("User updated successfully", {
          variant: "success",
        });
        fetchData();
      } else {
        values = {
          ...values,
          user_type_id: 5,
          user_role_id: 5,
          parent_id: localStorage.getItem("userId"),
        };
        await axios.post(`${basePath}/users/add`, values);
        enqueueSnackbar("User added successfully", {
          variant: "success",
        });
        fetchData();
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    } finally {
      setOpen(false);
      setUser(null);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.post(`${basePath}/users/delete`, { id });
      enqueueSnackbar("User deleted successfully", {
        variant: "success",
      });
      fetchData();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const columns = [
    {
      title: "First Name",
      dataIndex: "first_name",
      key: "first_name",
    },
    {
      title: "Last Name",
      dataIndex: "last_name",
      key: "last_name",
    },
    {
      title: "Username",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Mobile",
      dataIndex: "mobile",
      key: "mobile",
    },
    {
      title: "Actions",
      key: "action",
      render: (text, record) => (
        <span>
          <Authorize moduleId={5} permissions="can_update">
            <Button
              type="link"
              onClick={() => {
                setOpen(true);
                setUser(record);
              }}
            >
              Edit
            </Button>
          </Authorize>
          <Authorize moduleId={5} permissions="can_delete">
            <Button
              type="link"
              onClick={() => {
                showConfirm(record.id, handleDelete);
              }}
            >
              Delete
            </Button>
          </Authorize>
        </span>
      ),
    },
  ];

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Users List</h2>
        <Authorize moduleId={5} permissions="can_create">
          <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              setOpen(true);
              setUser(null);
            }}
          >
            Add User
          </Button>
        </Authorize>
      </div>
      <Table
        dataSource={users}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <AddUserModal
        open={open}
        setOpen={setOpen}
        user={user}
        setUser={setUser}
        onCreate={handleCreate}
        onCancel={() => setOpen(false)}
      />
    </div>
  );
};

export default Users;
