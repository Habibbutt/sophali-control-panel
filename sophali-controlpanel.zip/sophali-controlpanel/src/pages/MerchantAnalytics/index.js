import { useLocation } from "react-router-dom";
import React, { useEffect, useState, useRef } from "react";
import { Row, Col, Card, DatePicker, Select, Table } from "antd";
import { Line, Pie, Bar } from "@ant-design/charts";
import axios from "axios";
import moment from "moment";

const { RangePicker } = DatePicker;

function MerchantAnalytics() {
  const [analyticsData, setAnalyticsData] = useState([]);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const basePath = process.env.REACT_APP_API_URL;

  useEffect(() => {
    fetchData();
  }, [fromDate, toDate, selectedUser]);
  const fetchData = async () => {
    const merchantId = localStorage.getItem("userId");
    const formattedFromDate = fromDate ? fromDate.format("YYYY-MM-DD") : null;
    const formattedToDate = toDate ? toDate.format("YYYY-MM-DD") : null;
    const userId = selectedUser ? selectedUser : null;

    const result = await axios.get(
      `${basePath}/analytics/merchant-analytics?merchant_id=${merchantId}&from_date=${formattedFromDate}&to_date=${formattedToDate}&user_id=${userId}`
    );
    setAnalyticsData(result.data.merchantAnalytics);

    const result1 = await axios.get(
      `${basePath}/users/subscribe-user-list/${merchantId}`
    );
    console.log(`🚀🚀🚀  result1.data:`, result1.data);

    setUsers(result1.data.userList.filter((e) => !e.checkout_date));
  };
  const handleUserChange = (value) => {
    setSelectedUser(value);
  };
  const tableData = analyticsData.map((item) => {
    return {
      key: item.id,
      date: moment(item.createdAt).format("YYYY-MM-DD"),
      sophaliTokens: item.total_sophali_tokens,
      usdAmount: (+item.total_sophali_tokens / 5).toFixed(2), // assuming there is a usd_amount field in your data
    };
  });
  const columns = [
    {
      title: "Date of Transaction",
      dataIndex: "date",
      key: "date",
    },
    {
      title: "Sophali Tokens",
      dataIndex: "sophaliTokens",
      key: "sophaliTokens",
    },
    {
      title: "USD Amount",
      dataIndex: "usdAmount",
      key: "usdAmount",
    },
  ];
  // Prepare data for charts
  const SalesData = analyticsData.map((item) => {
    console.log(`🚀🚀🚀  item:`, item);
    console.log(`🚀🚀🚀  item:`, item.createdAt);
    console.log(`🚀🚀🚀  item:`, item.total_sophali_tokens);
    return {
      date: moment(item.createdAt).format("YYYY-MM-DD"),
      sales: item.total_sophali_tokens,
    };
  });

  const productsSoldData = analyticsData.reduce((acc, item) => {
    item.OrderItems.forEach((orderItem) => {
      acc[orderItem.Product.title] =
        (acc[orderItem.Product.title] || 0) + item.OrderItems.length;
    });
    return acc;
  }, {});
  const productsSoldArray = Object.entries(productsSoldData).map(
    ([product, quantity]) => ({ product, quantity })
  );

  function determineStatus(collectedColor) {
    let status = "On Time";
    if (collectedColor === "red") {
      status = "Late";
    } else if (collectedColor === "yellow") {
      status = "Almost Late";
    } else if (collectedColor === "green") {
      status = "On Time";
    }
    return status;
  }

  const deliveryTimesData = analyticsData.reduce((acc, item) => {
    const deliveryStatus = determineStatus(item.collected_color);
    acc[deliveryStatus] = (acc[deliveryStatus] || 0) + 1;
    return acc;
  }, {});

  const deliveryTimesArray = Object.entries(deliveryTimesData).map(
    ([status, count]) => ({ status, count })
  );
  console.log(`🚀🚀🚀  deliveryTimesArray:`, deliveryTimesArray);

  // Chart configurations
  const lineConfig = {
    data: SalesData,
    xField: "date",
    yField: "sales",
  };
  console.log(`🚀🚀🚀  SalesData:`, SalesData);

  const pieConfig = {
    appendPadding: 10,
    data: productsSoldArray,
    angleField: "quantity",
    colorField: "product",
    radius: 0.8,
    label: { type: "outer", content: "{percentage}" },
  };

  const barConfig = {
    data: deliveryTimesArray,
    xField: "count",
    yField: "status",
  };
  const handleDateChange = (dates) => {
    setFromDate(dates[0]);
    setToDate(dates[1]);
  };

  // inside your MerchantAnalytics component
  const transactionsRef = useRef(null);

  const location = useLocation();

 useEffect(() => {
   if (location.hash === "#transactions" && transactionsRef.current) {
     // Scroll the transactions element into view
     transactionsRef.current.scrollIntoView({
       block: "start",
       inline: "nearest",
       behavior: "smooth",
     });
   }
 }, [location]);


  return (
    <div>
      <h2>Merchant Analytics</h2>
      <RangePicker
        style={{ marginBottom: "10px" }}
        onChange={handleDateChange}
      />
      <Select
        style={{ width: 120 }}
        placeholder="Select User"
        onChange={handleUserChange}
      >
        <Select.Option value={null}>All Users</Select.Option>
        {users?.map((user) => (
          <Select.Option key={user.id} value={user.id}>
            {user.screenName
              ? user.screenName
              : user.first_name + " " + user.last_name}
          </Select.Option>
        ))}
      </Select>
      <Row gutter={16}>
        <Col span={8}>
          <Card title="Sales">
            <Line {...lineConfig} />
          </Card>
        </Col>
        <Col span={8}>
          <Card title="Most Sold Item">
            <Pie {...pieConfig} />
          </Card>
        </Col>
        <Col span={8}>
          <Card title="On Time vs Late Deliveries">
            <Bar {...barConfig} />
          </Card>
        </Col>
      </Row>
      <Row gutter={16}>
        <Col span={24}>
          <Card
            ref={transactionsRef}
            style={{ scrollMargin: "102px" }}
            id="transactions"
            title="Transactions"
          >
            <Table dataSource={tableData} columns={columns} />
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default MerchantAnalytics;
