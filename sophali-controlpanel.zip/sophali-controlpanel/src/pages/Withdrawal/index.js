import { Button, Card, Form, Col, Row, Input } from "antd";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useSnackbar } from "notistack";
import moment from "moment";
import Receipt from "./Receipt"; // Assuming Receipt.js is in the same directory
import "./App.css";

const BankingInfo = () => {
  const [form] = Form.useForm();
  const { enqueueSnackbar } = useSnackbar();
  const [balance, setBalance] = useState("0.00");
  const [transactionRecord, setTransactionRecord] = useState([]);
  const [totalWithdrawals, setTotalWithdrawals] = useState("0.00");
  const [lastWithdrawalAmount, setLastWithdrawalAmount] = useState("0.00");
  const [basePath] = useState(process.env.REACT_APP_API_URL);
  const [user_id] = useState(localStorage.getItem("userId"));
  const [receiptVisible, setReceiptVisible] = useState(false);
  const [selectedTransactionRecord, setSelectedTransactionRecord] = useState(null);

  const handleSave = async (values) => {
    try {
      const { email, password, withdrawalAmount } = values;
      const formattedAmount = withdrawalAmount.replace("$", "");
      const response = await axios.post(`${basePath}/admin/withdrawals`, {
        email,
        password,
        withdrawal_amount: formattedAmount,
        id: user_id,
      });
      if (response.data?.code === 200) {
        enqueueSnackbar(response.data?.message || "Withdraw successfully", {
          variant: "success",
        });
        await fetchData();
        form.resetFields();
      } else {
        enqueueSnackbar(response.data?.message || "Withdraw failed", {
          variant: "error",
        });
      }
    } catch (error) {
      enqueueSnackbar(
        error.response?.data?.message || "An unexpected error occurred",
        { variant: "error" }
      );
    }
  };

  useEffect(() => {
    fetchData();
  }, [basePath, enqueueSnackbar, user_id]);

  async function fetchData() {
    try {
      const response = await axios.get(
        `${basePath}/admin/card/withdrawals?id=${user_id}`
      );
      if (response.data.code === 200) {
        setBalance(response.data.data.balance);
        setTotalWithdrawals(response.data.data.totalWithdrawals);
        setLastWithdrawalAmount(response.data.data.lastWithdrawal.amount_cad);
        setTransactionRecord(response.data.data.withdrawalRecords);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      enqueueSnackbar("Failed to fetch data.", { variant: "error" });
    }
  }

  const handleViewClick = (record) => {
    setSelectedTransactionRecord(record);
    setReceiptVisible(true);
  };

  const handleCloseReceipt = () => {
    setReceiptVisible(false);
  };

  return (
    <div>
      <h1>Withdrawal Amount</h1>
      <div style={{ display: "flex", justifyContent: "left" }}>
        <Card title="Total Balance" style={{ width: 300, margin: "0 16px" }}>
          ${parseFloat(balance).toFixed(2)}
        </Card>
        <Card title="Last Withdrawal" style={{ width: 300, margin: "0 16px" }}>
          ${parseFloat(lastWithdrawalAmount).toFixed(2)}
        </Card>
        <Card title="Total Withdrawal" style={{ width: 300, margin: "0 16px" }}>
          ${parseFloat(totalWithdrawals).toFixed(2)}
        </Card>
      </div>
      <Form
        layout="horizontal"
        style={{ paddingTop: "50px" }}
        form={form}
        onFinish={handleSave}
      >
        <Row gutter={24}>
          <Col style={{ padding: "0 15px" }}>
            <Form.Item
              label="Email"
              name="email"
              rules={[{ required: true, message: "Please enter your Email!" }]}
            >
              <Input style={{ width: "200px" }} />
            </Form.Item>
          </Col>
          <Col style={{ padding: "0 15px" }}>
            <Form.Item
              label="Password"
              name="password"
              rules={[
                { required: true, message: "Please enter your password!" },
              ]}
            >
              <Input.Password style={{ width: "200px" }} />
            </Form.Item>
          </Col>
          <Col style={{ padding: "0 15px" }}>
            <Form.Item
              label="Withdrawal Amount"
              name="withdrawalAmount"
              rules={[
                {
                  required: true,
                  message: "Please enter your withdrawal amount!",
                },
              ]}
            >
              <Input placeholder="$" style={{ width: "200px" }} />
            </Form.Item>
          </Col>
          <Col style={{ padding: "0 30px" }}>
            <Form.Item>
              <Button
                type="primary"
                htmlType="submit"
                style={{ background: "#1574ef", color: "white" }}
              >
                Withdraw
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Time</th>
              <th>Amount</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {transactionRecord.length > 0 ? (
              transactionRecord.map((item, index) => (
                <tr key={index}>
                  <td>{moment(item.createdAt).format("YYYY-MM-DD")}</td>
                  <td>{moment(item.createdAt).format("HH:mm A")}</td>
                  <td>${parseFloat(item.amount_cad).toFixed(2) || "0.00"}</td>
                  <td>
                    <button onClick={() => handleViewClick(item)}>View</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No Transactions Record found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <Receipt
        visible={receiptVisible}
        onClose={handleCloseReceipt}
        transactionRecord={selectedTransactionRecord}
      />
    </div>
  );
};

export default BankingInfo;
