import React, { useEffect, useState } from "react";
import { ExclamationCircleOutlined, UploadOutlined } from "@ant-design/icons";
import ImgCrop from "antd-img-crop";
import moment from "moment";
import { useSelector, useDispatch } from "react-redux";
import { setAdminTax } from "../../appRedux/actions/Common";

import {
  Button,
  Form,
  Input,
  InputNumber,
  Modal,
  Select,
  Table,
  Upload,
  Image,
  DatePicker,
  Checkbox,
  Tooltip,
} from "antd";
import axios from "axios";
import Authorize from "../../components/Authorize/Authorize";
import { useSnackbar } from "notistack";
const { confirm } = Modal;

const basePath = process.env.REACT_APP_API_URL;

const showConfirm = (id, onDelete) => {
  confirm({
    title: "Do you want to delete this product?",
    icon: <ExclamationCircleOutlined />,
    onOk() {
      onDelete(id);
    },
    onCancel() {},
  });
};
const AddProductModal = ({
  categories,
  open,
  setOpen,
  product,
  setProduct,
  onCreate,
  onCancel,
  handleChange,
  // handleUpload,
}) => {
  const [form] = Form.useForm();
  const [fileList, setFileList] = useState([]);
  const [isTransferable, setIsTransferable] = useState(false);
  const dispatch = useDispatch();

  const onChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };

  const onTransferChange = (e) => {
    setIsTransferable(e.target.checked);
  };

  const onPreview = async (file) => {
    let src = file.url;
    if (!src) {
      src = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file.originFileObj);
        reader.onload = () => resolve(reader.result);
      });
    }
    const image = new Image();
    image.src = src;
    const imgWindow = window.open(src);
    imgWindow?.document.write(image.outerHTML);
  };
  const onRemove = () => {
    product.uuids = "";
    setFileList([]);
  };
  useEffect(() => {
    form.resetFields();
    if (product) {
      product.transfer_expire_date = moment(product.transfer_expire_date);
      setIsTransferable(product.is_transferable);
      form.setFieldsValue(product);
    }
  }, [product, form]);

  const fetchAdminTaxData = async (dispatch) => {
    try {
      const response = await axios.get(`${basePath}/setting/1`);
      dispatch(setAdminTax(response?.data?.settings?.tax));
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    fetchAdminTaxData(dispatch);
  }, [dispatch]);

  const tax = localStorage.getItem("tax");

  const adminTax = useSelector((state) => state.common.adminTax);
  console.log(`🚀🚀🚀  adminTax:`, adminTax)

  return (
    <Modal
      forceRender
      open={open}
      title={product ? "Edit Product" : "Add Product"}
      okText={product ? "Update" : "Add"}
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setProduct("");
        setFileList([]);
        setIsTransferable(false);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate({ ...values, fileList });
            setOpen(false);
            setFileList([]);
            setIsTransferable(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
        initialValues={{
          size: "All",
        }}
      >
        <Form.Item
          name="cat_id"
          label="Category"
          rules={[
            {
              required: true,
              message: "Please select category!",
            },
          ]}
        >
          <Select
            options={categories}
            size={"small"}
            className="mission-status"
            value={undefined || null || ""}
          />
        </Form.Item>
        <Form.Item
          name="title"
          label="Title"
          rules={[
            {
              required: true,
              message: "Please Enter Title!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="description" label="Description">
          <Input />
        </Form.Item>
        <Form.Item name="ingredients" label="Ingredients">
          <Input.TextArea
            placeholder="Enter comma separated ingredients"
            rows={4}
          />
        </Form.Item>
        <Form.Item name="stock" label="Stock">
          <InputNumber />
        </Form.Item>
        <Form.Item
          name="size"
          label="Size"
          rules={[
            {
              required: true,
              message: "Please Enter Size!",
            },
          ]}
        >
          <Select
            options={[
              { value: "All", label: "All" },
              { value: "Small", label: "Small" },
              { value: "Medium", label: "Medium" },
              { value: "Large", label: "Large" },
            ]}
            size={"small"}
            className="mission-status"
            value={undefined || null || ""}
          />
        </Form.Item>
        <Form.Item
          name="price"
          label="Price in USD"
          rules={[
            {
              required: true,
              message: "Please enter price!",
            },
          ]}
        >
          <InputNumber />
        </Form.Item>
        <Form.Item
          name="time"
          label="Time to make"
          rules={[{ required: true, message: "Please enter time!" }]}
        >
          <InputNumber />
        </Form.Item>
        <Form.Item
          name="time_type"
          label="Time Type"
          rules={[{ required: true, message: "Please select time type!" }]}
        >
          <Select
            options={[
              { value: "minutes", label: "Minutes" },
              { value: "hours", label: "Hours" },
            ]}
            className="time-select"
            value={undefined || null || ""}
          />
        </Form.Item>
        <Form.Item
          name="is_transferable"
          label="Is Transferable.?"
          valuePropName="checked"
        >
          <Checkbox onChange={onTransferChange} />
        </Form.Item>
        {isTransferable && (
          <>
            <Form.Item
              name="transfer_expire_date"
              label={
                <Tooltip
                  title={
                    <span className="label-text">Transfer Expire Date</span>
                  }
                >
                  <span className="label-text">Transfer Expire Date</span>
                </Tooltip>
              }
              initialValue={moment().add(1, "year")}
            >
              <DatePicker
                className="input"
                format="MM/DD/YYYY"
                placeholder="Select expiration date"
                allowClear={false}
              />
            </Form.Item>
            <Form.Item
              name="number_of_days"
              label={
                <Tooltip
                  title={<span className="label-text">Number of days</span>}
                >
                  <span className="label-text">Number of days</span>
                </Tooltip>
              }
              initialValue={30}
            >
              <InputNumber />
            </Form.Item>
          </>
        )}
        <Form.Item name="discount" label="Discount">
          <InputNumber />
        </Form.Item>
        <Form.Item
          name="tax"
          label={
            <Tooltip
              title={`Set Tax Rate (Default Global Tax Rate: ${
                tax != "null" ? tax : adminTax
              }%):`}
            >
              <span className="label-text">
                {`Set Tax Rate (Default Global Tax Rate: ${
                  tax != "null" ? tax : adminTax
                }%):`}
              </span>
            </Tooltip>
          }
        >
          <InputNumber
            formatter={(value) => `${value}%`}
            parser={(value) => value.replace("%", "")}
          />
        </Form.Item>
        <Form.Item name="images" label="Image">
          <ImgCrop rotationSlider>
            <Upload
              name="Files"
              action={`${basePath}/upload`}
              listType="picture-card"
              fileList={
                product && product.uuids && JSON.parse(product.uuids).length
                  ? [
                      {
                        url: `${basePath}/getFileById?uuid=${
                          product &&
                          product?.uuids &&
                          JSON.parse(product.uuids)[0]
                        }`,
                      },
                    ]
                  : null || fileList
              }
              onChange={onChange}
              onPreview={onPreview}
              onRemove={onRemove}
            >
              {(product.uuids == "[]" || !product.uuids) &&
                fileList.length < 1 &&
                "+ Upload"}
            </Upload>
          </ImgCrop>
        </Form.Item>
      </Form>
    </Modal>
  );
};

const Product = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [product, setProduct] = useState("");
  const [open, setOpen] = useState(false);
  const [addons, setAddons] = useState([]);
  const [selectedAddons, setSelectedAddons] = useState([]);
  const [addonsModalVisible, setAddonsModalVisible] = useState(false);

  const basePath = process.env.REACT_APP_API_URL;
  const { enqueueSnackbar } = useSnackbar();
  useEffect(() => {
    fetchCategories();
    fetchProducts();
  }, []);
  // useEffect(() => {}, []);
  let parent_id;
  if (
    localStorage.getItem("parent_merchant_id") &&
    localStorage.getItem("userTypeId") == 4
  ) {
    parent_id = localStorage.getItem("parent_merchant_id");
  } else {
    parent_id = localStorage.getItem("userId");
  }
  const fetchProducts = async () => {
    try {
      const result = await axios.get(
        `${basePath}/products/list?added_by=${parent_id}`
      );
      setProducts(result.data.products.rows);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const fetchAddons = async (record) => {
    try {
      setProduct(record);
      const result = await axios.get(
        `${basePath}/addons/list?added_by=${parent_id}`
      );
      setAddons(result.data.addons.rows);
      const result1 = await axios.get(
        `${basePath}/productAddons/list?product_id=${record.id}`
      );

      setSelectedAddons(
        result1.data.productAddons.map((addon) => addon.addons_id)
      );
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const handleProductAddonsSave = async () => {
    try {
      const result = await axios.post(`${basePath}/productAddons/add`, {
        product_id: product.id,
        addon_ids: selectedAddons,
      });
      enqueueSnackbar(result.data.message, { variant: "success" });
      setAddonsModalVisible(false);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const handleAddonSelection = (addonId) => {
    if (selectedAddons.includes(addonId)) {
      // Remove the addon from the selected addons list
      setSelectedAddons((prevSelectedAddons) =>
        prevSelectedAddons.filter((id) => id !== addonId)
      );
    } else {
      // Add the addon to the selected addons list
      setSelectedAddons((prevSelectedAddons) => [
        ...prevSelectedAddons,
        addonId,
      ]);
    }
  };

  async function fetchCategories() {
    const res = await axios.get(
      `${basePath}/categories/list?parent_id=${parent_id}`
    );
    setCategories(
      res.data.categories.rows.map((element) => ({
        value: element.id,
        label: element.title,
      }))
    );
  }

  const handleCreate = async (values) => {
    if (!values.uuids) {
      values.uuids = JSON.stringify(
        values.fileList.map((item) => {
          return item.response.data;
        })
      );
      if (values.uuids == "[]") {
        values.uuids = product.uuids;
      }
      delete values.fileList;
    }

    try {
      if (product) {
        const result = await axios.post(`${basePath}/product/update`, {
          ...values,
          id: product.id,
        });
        enqueueSnackbar("Product updated successfully", {
          variant: "success",
        });
        fetchCategories();
        fetchProducts();
      } else {
        const result = await axios.post(`${basePath}/product/add`, {
          ...values,
          parent_id: parent_id,
          added_by: parent_id,
        });
        enqueueSnackbar("Product added successfully", {
          variant: "success",
        });
        const resultList = await axios.get(
          `${basePath}/products/list?added_by=${parent_id}`
        );
        fetchCategories();
        fetchProducts();
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    } finally {
      setOpen(false);
      setProduct("");
    }
  };
  const handleDelete = async (id) => {
    try {
      await axios.post(`${basePath}/product/delete`, { id });
      enqueueSnackbar("Product deleted successfully", {
        variant: "success",
      });
      const updatedProducts = products.filter((item) => item.id !== id);
      setProducts(updatedProducts);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const columns = [
    {
      title: "Image",
      dataIndex: "uuids",
      key: "uuids",
      render: (text, record) => {
        return (
          <Image
            width={50}
            src={`${basePath}/getFileById?uuid=${
              record && record?.uuids && JSON.parse(record.uuids)[0]
            }`}
          ></Image>
        );
      },
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      dataIndex: "action",
      key: "action",
      render: (text, record) => (
        <span>
          <Button
            type="link"
            onClick={() => {
              // Open the addons modal
              fetchAddons(record);

              setAddonsModalVisible(true);
            }}
          >
            Add Addons
          </Button>

          <Authorize moduleId={3} permissions="can_update">
            <Button
              type="link"
              onClick={async () => {
                setOpen(true);

                setProduct(record);
              }}
            >
              Edit
            </Button>
          </Authorize>
          <Authorize moduleId={3} permissions="can_delete">
            <Button
              type="link"
              onClick={() => {
                showConfirm(record.id, handleDelete);
              }}
            >
              Delete
            </Button>
          </Authorize>
        </span>
      ),
    },
  ];
  if (localStorage.getItem("userTypeId") == 1) {
    columns.unshift({ title: "Merchant Name", dataIndex: "merchant_name" });
  }
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Products List</h2>
        <Authorize moduleId={3} permissions="can_create">
          <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              setOpen(true);
              setProduct("");
            }}
          >
            Add Product
          </Button>
        </Authorize>
      </div>
      <Table
        dataSource={products}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <AddProductModal
        open={open}
        setOpen={setOpen}
        product={product}
        setProduct={setProduct}
        onCreate={handleCreate}
        categories={categories}
        // handleUpload={handleUpload}
        onCancel={() => setOpen(false)}
      />
      <Modal
        title="Select Addons"
        open={addonsModalVisible}
        okText="Add"
        onOk={() => {
          // Save the selected addons
          handleProductAddonsSave();
        }}
        onCancel={() => {
          // Close the addons modal
          setAddonsModalVisible(false);
          setSelectedAddons([]);
        }}
      >
        {/* Display a checkbox for each addon */}
        {addons.map((addon) => (
          <Checkbox
            key={addon.id}
            checked={selectedAddons.includes(addon.id)}
            onChange={() => handleAddonSelection(addon.id)}
          >
            {addon.title}
          </Checkbox>
        ))}
      </Modal>
    </div>
  );
};

export default Product;
