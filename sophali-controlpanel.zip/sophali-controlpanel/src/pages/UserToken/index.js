import React, { useEffect, useState } from "react";
import { Button, Form, InputNumber, Modal, Table } from "antd";
import axios from "axios";
import { useSnackbar } from "notistack";
import QRCode from "qrcode.react";
import { useSelector, useDispatch } from "react-redux";
import { setAdminWithdrawFee } from "../../appRedux/actions/Common";
const basePath = process.env.REACT_APP_API_URL;

const TopUpUserTokenModal = ({ open, setOpen, token, onCreate, onCancel }) => {
  const adminWithdrawFee = useSelector(
    (state) => state.common.adminWithdrawFee
  );
  const [form] = Form.useForm();
  const [amountTokens, setAmountTokens] = useState(0);

  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(token || {});
  }, [token, form]);

  return (
    <Modal
      width={700}
      forceRender
      open={open}
      title={
        localStorage.getItem("userTypeId") == 3
          ? "Withdraw Merchant Token"
          : localStorage.getItem("userTypeId") == 1
          ? "Withdraw Admin Token"
          : "Top Up User Token"
      }
      okText={
        localStorage.getItem("userTypeId") == 3
          ? "Withdraw"
          : localStorage.getItem("userTypeId") == 1
          ? "Withdraw"
          : "Add"
      }
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setOpen(false);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpen(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 8,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <Form.Item
          name="amount_cad"
          label={<span className="label-text">Amount in CAD</span>}
          validateTrigger={["onBlur"]}
          style={{ width: "100% !important" }}
          rules={[
            {
              required: true,
              message: "Please enter amount in cad.",
            },
          ]}
        >
          <InputNumber
            min={0}
            step={1}
            placeholder="Enter Amount"
            style={{ width: "100%" }}
            onChange={(value) => setAmountTokens(value)}
          />
        </Form.Item>
        <p>
          Your current withdrawal fee is{" "}
          {(amountTokens * adminWithdrawFee) / 100} Sophali Tokens. Please take
          this into account when entering the withdrawal amount.
        </p>
      </Form>
    </Modal>
  );
};

const UserTokens = () => {
  const dispatch = useDispatch();
  const [withdrawLimit, setWithdrawLimit] = useState(7);
  const adminWithdrawFee = useSelector(
    (state) => state.common.adminWithdrawFee
  );
  const [tokens, setTokens] = useState([]);
  const [balance, setBalance] = useState(0);
  const [token, setToken] = useState(null);
  const [details, setDetails] = useState(null);
  const [open, setOpen] = useState(false);
  const [openDetail, setOpenDetail] = useState(false);
  const basePath = process.env.REACT_APP_API_URL;
  const { enqueueSnackbar } = useSnackbar();
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const fetchAdminWithdrawalData = async (dispatch) => {
    try {
      const response = await axios.get(`${basePath}/setting/1`);
      dispatch(setAdminWithdrawFee(response?.data?.settings?.withdraw_fee));
      setWithdrawLimit(response?.data?.settings?.withdraw_limit);
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    fetchAdminWithdrawalData(dispatch);
  }, [dispatch]);

  const fetchTokens = async () => {
    try {
      let result;
      if (localStorage.getItem("userTypeId") == 3) {
        result = await axios.get(
          `${basePath}/merchants/merchant-consumed-token?merchant_id=${localStorage.getItem(
            "userId"
          )}`
        );
      } else {
        result = await axios.get(
          `${basePath}/admin/admin-token-balance?user_id=${localStorage.getItem(
            "userId"
          )}`
        );
      }
      console.log(`🚀🚀🚀  result:`, result);
      let res = await axios.get(
        `${basePath}/merchants/merchant-token-balance?user_id=${localStorage.getItem(
          "userId"
        )}`
      );
      console.log(`🚀🚀🚀  res:`, res);
      setBalance(res.data.balance);
      let arr = [];
      let array = result.data.merchantEarnedToken
        ? result.data.merchantEarnedToken
        : result.data.adminTokenBalance;
      array.forEach((element) => {
        if (element.status == "active") {
          arr.push({
            id: element.id,
            date: element.createdAt,
            amount_cad: element.amount_cad,
            sophali_fee: element.sophali_fee,
            status: element.status,
          });
        }
      });
      setTokens(arr.reverse());
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  useEffect(() => {
    fetchTokens();
  }, []);

  const handleCreate = async (values) => {
    let obj = {
      amount_cad: values.amount_cad,
      user_id: localStorage.getItem("userId"),
      helcium_transation_id: new Date().getTime(),
      status: "active",
    };
    try {
      await axios.post(`${basePath}/usertoken/add`, obj);
      enqueueSnackbar("Tokens topped up successfully", {
        variant: "success",
      });
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
    } finally {
      setOpen(false);
      setToken(null);
      fetchTokens();
    }
  };
  const handleWithdraw = async (values) => {
    let sophali_fee = (values.amount_cad * adminWithdrawFee) / 100;
    let obj = {
      withdrawal_amount: +values.amount_cad - +sophali_fee,
      amount_cad: +values.amount_cad - +sophali_fee,
      sophali_fee,
      // TODO: Fix the following when  subscription gets handled
      subscription_status: "unpaid",
    };
    if (localStorage.getItem("userTypeId") == 1) {
      obj.user_id = localStorage.getItem("userId");
    } else {
      obj.merchant_id = localStorage.getItem("userId");
    }

    try {
      await axios.post(`${basePath}/merchantwithdrawalrequest/add`, obj);
      enqueueSnackbar(
        "Withdrawal went for approval you will soon receive notification regarding your withdrawal",
        {
          variant: "success",
        }
      );
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
    } finally {
      setOpen(false);
      setToken(null);
      fetchTokens();
    }
  };
  // const handleWithdraw = async (values) => {
  //   let obj = {
  //     amount_usd: values.amount_tokens / 5,
  //     sophali_tokens: values.amount_tokens,
  //     sophali_token_balance: values.amount_tokens * 5, // token.sophali_tokens_balance,
  //     helcium_transation_id: new Date().getTime(),
  //     status: "active",
  //   };
  //   if (localStorage.getItem("userTypeId") == 1) {
  //     obj.user_id = localStorage.getItem("userId");
  //   } else {
  //     obj.merchant_id = localStorage.getItem("userId");
  //   }

  //   try {
  //     await axios.post(`${basePath}/merchants/withdraw-token`, obj);
  //     enqueueSnackbar("Tokens withdrawn successfully", {
  //       variant: "success",
  //     });
  //   } catch (error) {
  //     enqueueSnackbar(error.response.data.message, { variant: "error" });
  //   } finally {
  //     setOpen(false);
  //     setToken(null);
  //     fetchTokens();
  //   }
  // };
  const getTransactionDetails = async (record) => {
    try {
      const result = await axios.get(
        `${basePath}/usertoken/getTransactionDetails?user_id=${localStorage.getItem(
          "userId"
        )}&id=${record.idForDetail}`
      );
      setDetails(result.data);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const columns = [
    {
      title: "Date",
      dataIndex: "date",
      key: "date",
      render: (text) => {
        return (
          <span>
            {new Date(text).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
              hour: "numeric",
              minute: "numeric",
              second: "numeric",
            })}{" "}
          </span>
        );
      },
    },
    {
      title: "Amount in CAD",
      dataIndex: "amount_cad",
      key: "amount_cad",
    },
    {
      title: "Sophali Fee",
      dataIndex: "sophali_fee",
      key: "sophali_fee",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
    },

    {
      title: "QR Code",
      key: "qrcode",
      render: (text, record) => {
        return (
          <Button
            type="link"
            onClick={() => {
              setDetails(record);
              setQrModalOpen(true);
            }}
          >
            Show QR Code
          </Button>
        );
      },
    },
  ];
  const isTokenOlder = (days) => {
    if (tokens[0]) {
      const tokenDate = new Date(tokens[0].date);
      const currentDate = new Date();

      // Get difference in milliseconds
      const diffTime = Math.abs(currentDate - tokenDate);

      // Convert difference to days
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      if (!days) return diffDays >= 7;
      else return diffDays >= days;
    }
    return true;
  };
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
          }}
        >
          <h2 style={{ marginLeft: "2px" }}>
            {localStorage.getItem("userTypeId") == 3
              ? "Merchant Tokens"
              : localStorage.getItem("userTypeId") == 1
              ? "Admin Tokens"
              : "User Tokens"}
          </h2>
          <span
            style={{
              marginLeft: "10px",
              fontSize: "smaller",
              alignSelf: "flex-start",
            }}
          >
            {balance}
          </span>
        </div>

        <Button
          style={{ marginRight: "1px" }}
          disabled={
            localStorage.getItem("userTypeId") == 3 &&
            !isTokenOlder(withdrawLimit)
          }
          type="primary"
          onClick={() => {
            setOpen(true);
            setToken(null);
          }}
        >
          {localStorage.getItem("userTypeId") == 3
            ? "Withdraw"
            : localStorage.getItem("userTypeId") == 1
            ? "Withdraw"
            : "Top Up"}
        </Button>
      </div>
      <Table
        dataSource={tokens}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <TopUpUserTokenModal
        open={open}
        setOpen={setOpen}
        token={token}
        setToken={setToken}
        onCreate={
          localStorage.getItem("userTypeId") == 3
            ? handleWithdraw
            : localStorage.getItem("userTypeId") == 1
            ? handleWithdraw
            : handleCreate
        }
        onCancel={() => setOpen(false)}
      />
      <Modal
        title="QR Code"
        open={qrModalOpen}
        onCancel={() => setQrModalOpen(false)}
        footer={null}
      >
        <QRCode value={JSON.stringify(details)} />
      </Modal>

      <Modal
        open={openDetail}
        title="Transaction Details"
        onCancel={() => setOpenDetail(false)}
      >
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", marginBottom: "16px" }}>
            <p style={{ fontWeight: "bold", marginRight: "8px" }}>
              Transaction Date:
            </p>
            <p> {new Date().toLocaleDateString()} </p>
          </div>
          <div style={{ display: "flex", marginBottom: "16px" }}>
            <p style={{ fontWeight: "bold", marginRight: "8px" }}>Item:</p>
            <p> Pizza </p>
          </div>
          <div style={{ display: "flex", marginBottom: "16px" }}>
            <p style={{ fontWeight: "bold", marginRight: "8px" }}>
              Restaurant:
            </p>
            <p> ny212 </p>
          </div>
          <div style={{ display: "flex", marginBottom: "16px" }}>
            <p style={{ fontWeight: "bold", marginRight: "8px" }}>Amount:</p>
            <p> 100 Sophali tokens </p>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default UserTokens;
