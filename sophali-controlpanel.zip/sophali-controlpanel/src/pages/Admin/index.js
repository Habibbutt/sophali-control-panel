import React, { useEffect, useState } from "react";
import { Table, Button, PageHeader } from "antd";
import { useSnackbar } from "notistack";

import axios from "axios";
import AddAdminModal from "./adminModal";
import showConfirm from "./confirmModal";
import Authorize from "../../components/Authorize/Authorize";

const Admin = () => {
  const { enqueueSnackbar } = useSnackbar();

  const [users, setUsers] = useState([]);
  const [user, setUser] = useState(null);
  const [open, setOpen] = useState(false);
  const basePath = process.env.REACT_APP_API_URL;
  useEffect(() => {
    fetchUsers();
  }, []);
  const fetchUsers = async () => {
    try {
      const result = await axios.post(`${basePath}/users/list`, {
        UserTypeId: 2,
        parent_id: localStorage.getItem("userId"),
      });
      setUsers(result.data.users.rows);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      enqueueSnackbar(error, { variant: "error" });

      console.error(error);
    }
  };

  const handleCreate = async (values) => {
    
    try {
      if (user) {
        const result = await axios.post(`${basePath}/users/update`, {
          ...values,
          id: user.id,
          parent_id: localStorage.getItem("userId"),
        });
        enqueueSnackbar("Admin updated successfully", { variant: "success" });

        fetchUsers();
      } else {
        values = {
          ...values,
          user_type_id: 2,
          user_role_id: 2,
          parent_id: localStorage.getItem("userId"),
        };
        const result = await axios.post(`${basePath}/users/add`, values);
        enqueueSnackbar("Admin created successfully", { variant: "success" });
        fetchUsers();
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    } finally {
      setOpen(false);
      setUser(null);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.post(`${basePath}/users/delete`, { id });
      enqueueSnackbar("Admin deleted successfully", {
        variant: "success",
      });

      const updatedUsers = users.filter((item) => item.id !== id);
      setUsers(updatedUsers);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const columns = [
    {
      title: "First Name",
      dataIndex: "first_name",
      key: "first_name",
    },
    {
      title: "Last Name",
      dataIndex: "last_name",
      key: "last_name",
    },
    {
      title: "Username",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Mobile",
      dataIndex: "mobile",
      key: "mobile",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      dataIndex: "action",
      key: "action",
      render: (text, record) => (
        <span>
          <Authorize moduleId={1} permissions="can_update">
            <Button
              type="link"
              onClick={() => {
                setOpen(true);
                
                setUser(record);
              }}
            >
              Edit
            </Button>
          </Authorize>
          <Authorize moduleId={1} permissions="can_delete">
            <Button
              type="link"
              onClick={() => {
                showConfirm(record.id, handleDelete);
              }}
            >
              Delete
            </Button>
          </Authorize>
        </span>
      ),
    },
  ];

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Admins List</h2>
        <Authorize moduleId={1} permissions="can_create">
          <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              setOpen(true);
              setUser(null);
            }}
          >
            Add Admin
          </Button>
        </Authorize>
      </div>
      <Table
        dataSource={users}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <AddAdminModal
        open={open}
        setOpen={setOpen}
        user={user}
        setUser={setUser}
        onCreate={handleCreate}
        onCancel={() => setOpen(false)}
      />
    </div>
  );
};

export default Admin;
