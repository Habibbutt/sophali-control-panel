import React, { useEffect } from "react";
import { Form, Input, Select, Modal } from "antd";

const { Option } = Select;
const AddAdminModal = ({ open, setOpen, user, setUser, onCreate, onCancel }) => {
    const [form] = Form.useForm();
    useEffect(() => {
        form.resetFields();
        form.setFieldsValue(user || {});
    }, [user, form]);

    return (
        <Modal
            forceRender
            open={open}
            title={user ? "Edit Admin" : "Add Admin"}
            okText={user ? "Update" : "Add"}
            cancelText="Cancel"
            onCancel={() => {
                form.resetFields();
                onCancel();
                setUser(null);
            }}
            onOk={() => {
                form
                    .validateFields()
                    .then((values) => {
                        form.resetFields();
                        onCreate(values);
                        setOpen(false);
                    })
                    .catch((info) => {
                        
                    });
            }}
        >
            <Form
                form={form}
                name="form_in_modal"
                labelCol={{
                    span: 6,
                    style: { textAlign: 'left' }
                }}
                wrapperCol={{
                    span: 18,
                }}
            >
                <Form.Item
                    name="first_name"
                    label="First Name"
                    rules={[
                        {
                            required: true,
                            message: 'Please Enter First Name!',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    name="last_name"
                    label="Last Name"
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    name="username"
                    label="Username"
                    rules={[
                        {
                            required: true,
                            message: 'Please Enter Username!',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    name="email"
                    label="Email"
                    rules={[
                        {
                            required: true,
                            message: 'Please Enter Email!',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    name="mobile"
                    label="Mobile"
                >
                    <Input />
                </Form.Item>
                {!user && (<Form.Item
                    name="password"
                    label="Password"
                    rules={[
                        {
                            required: true,
                            message: 'Please Enter Password!',
                        },
                    ]}
                >
                    <Input.Password />
                </Form.Item>)}
            </Form>
        </Modal>
    );
};

export default AddAdminModal;