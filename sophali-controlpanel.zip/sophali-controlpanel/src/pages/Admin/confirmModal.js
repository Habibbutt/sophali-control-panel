import { Modal } from "antd";
import { ExclamationCircleOutlined } from '@ant-design/icons';
const { confirm } = Modal;

const showConfirm = (id, onDelete) => {
    confirm({
        title: 'Do you want to delete this admin?',
        icon: <ExclamationCircleOutlined />,
        onOk() {
            onDelete(id);
        },
        onCancel() { },
    });
};
export default showConfirm;