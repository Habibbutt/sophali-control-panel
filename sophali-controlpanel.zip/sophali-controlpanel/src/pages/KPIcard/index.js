import React, { useEffect, useState } from "react";
import { Card, CardContent, Grid, Typography } from "@mui/material";
import FavoriteIcon from "@mui/icons-material/Favorite";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUsers,
  faStoreAlt,
  faBank,
  faUtensils,
} from "@fortawesome/free-solid-svg-icons";
import axios from "axios";

const dummyKPIs = [
  {
    id: 1,
    title: "Total Revenue",
    Icon: faBank,
    value: "$65,650",
    service: "65% lower growth",
    color: "red", // Adjustable color
  },
  {
    id: 2,
    title: "Orders",
    Icon: faUtensils,
    value: 3455,
    service: "Product-wise sales",
    color: "#FFC300", // Adjustable color
  },
  // {
  //   title: "Sales",
  //   value: 5693,
  //   Icon: faBoxOpen,
  //   service: "Weekly Sales",
  //   color: "green", // Adjustable color
  // },
  {
    id: 3,

    title: "Merchants",
    Icon: faStoreAlt,
    value: 246,
    service: "Product-wise sales",
    color: "#0066CC", // Adjustable color
  },
  {
    id: 4,
    title: "Users",
    Icon: faUsers,
    value: 246,
    service: "Product-wise sales",
    color: "#0066CC", // Adjustable color
  },
];

const Home = () => {
  const [dashboardInfo, setDashboardInfo] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const basePath = process.env.REACT_APP_API_URL;
        const response = await axios.get(`${basePath}/admin/dashboard-info`);
        if (response.data?.data) {
          const updatedKPIs = dummyKPIs.map(kpi => {
            switch (kpi.title) {
              case "Total Revenue":
                return { ...kpi, value: `$${response.data.data.revenue.toFixed(2)}` };
              case "Orders":
                return { ...kpi, value: response.data.data.ordersCount };
              case "Users":
                return { ...kpi, value: response.data.data.totalUser };
              case "Merchants":
                return { ...kpi, value: response.data.data.totalMerchant };
              default:
                return kpi;
            }
          });
          setDashboardInfo(updatedKPIs);
        }
        else {
          setDashboardInfo(dummyKPIs);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setDashboardInfo(dummyKPIs);

      }
    };

    fetchData();
  }, []);

  return (
    <Grid container spacing={2} style={{ paddingTop: "10px" }}>
      {dashboardInfo && dashboardInfo.length && dashboardInfo.map((kpi, index) => (
        <Grid key={index} item xs={12} sm={6} md={3}>
          <Card style={{ ...styleCard, height: "10rem" }}>
            <CardContent style={{ paddingTop: "25px", display: "flex", flexDirection: "column" }}>
              <div style={{ display: "flex", alignItems: "center", marginBottom: "10px" }}>
                {/* Icon */}
                <FontAwesomeIcon
                  icon={kpi.Icon}
                  style={{
                    fontSize: "24px",
                    color: kpi.color,
                    marginRight: "10px",
                  }}
                />
                {/* KPI Title */}

              </div>
              <Typography variant="subtitle2" style={{ fontSize: "16px", alignSelf: "flex-end", marginTop: "-25px" }}>
                {kpi.title}
              </Typography>
              {/* KPI Value */}
              <Typography variant="h4" style={{ alignSelf: "flex-end", marginTop: "auto" }}>
                {kpi.value}
              </Typography>
              {/* KPI Service */}
              <Typography variant="subtitle1" style={{ fontSize: "10px", marginTop: "15px", alignSelf: "flex-start" }}>
                <FavoriteIcon style={{ fontSize: "16px", marginRight: "5px" }} />
                {kpi.service}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default Home;

/* STYLE */
const styleCard = {
  backgroundColor: "white",
  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
};
