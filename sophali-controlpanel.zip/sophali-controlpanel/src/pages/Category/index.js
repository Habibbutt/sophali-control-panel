import { ExclamationCircleOutlined } from "@ant-design/icons";
import { Button, Form, Input, Modal, Table } from "antd";
import axios from "axios";
import React, { useEffect, useState } from "react";
import Authorize from "../../components/Authorize/Authorize";
import { useSnackbar } from "notistack";

const { confirm } = Modal;

const showConfirm = (id, onDelete) => {
  confirm({
    title: "Do you want to delete this category?",
    icon: <ExclamationCircleOutlined />,
    onOk() {
      onDelete(id);
    },
    onCancel() {},
  });
};
const AddCategoryModal = ({
  open,
  setOpen,
  category,
  setCategory,
  onCreate,
  onCancel,
}) => {
  const [form] = Form.useForm();

  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(category || {});
  }, [category, form]);
  return (
    <Modal
      forceRender
      open={open}
      title={category ? "Edit Category" : "Add Category"}
      okText={category ? "Update" : "Add"}
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setCategory(null);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpen(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Form.Item
          name="title"
          label="Title"
          rules={[
            {
              required: true,
              message: "Please Enter Title!",
            },
          ]}
        >
          <Input />
        </Form.Item>
      </Form>
    </Modal>
  );
};
const Category = () => {
  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState(null);
  const [open, setOpen] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const basePath = process.env.REACT_APP_API_URL;
  useEffect(() => {
    fetchCategories();
  }, []);
  let parent_id;
  if (
    localStorage.getItem("parent_merchant_id") &&
    localStorage.getItem("userTypeId") == 4
  ) {
    parent_id = localStorage.getItem("parent_merchant_id");
  } else {
    parent_id = localStorage.getItem("userId");
  }
  async function fetchCategories() {
    const res = await axios.get(
      `${basePath}/categories/list?parent_id=${parent_id}`
    );
    setCategories(res.data.categories.rows);
  }
  const handleCreate = async (values) => {
    try {
      if (category) {
        const result = await axios.post(`${basePath}/category/update`, {
          ...values,
          id: category.id,
        });
        enqueueSnackbar("Category updated successfully", {
          variant: "success",
        });

        fetchCategories();
      } else {
        const result = await axios.post(`${basePath}/category/add`, {
          ...values,
          parent_id: parent_id,
          added_by: parent_id,
        });
        enqueueSnackbar("Category added successfully", {
          variant: "success",
        });

        fetchCategories();
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    } finally {
      setOpen(false);
      setCategory(null);
    }
    // const res = await axios.post(`${basePath}/category/add`, values);

    // const listCategory = await axios.get(`${basePath}/categories/all`)
    // setCategories(listCategory.data.categories.rows);
    // setOpen(false);
  };
  const handleDelete = async (id) => {
    try {
      await axios.post(`${basePath}/category/delete`, { id });
      enqueueSnackbar("Category deleted successfully", {
        variant: "success",
      });
      const updatedCategories = categories.filter((item) => item.id !== id);
      setCategories(updatedCategories);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const columns = [
    {
      title: "Category Name",
      dataIndex: "title",
    },

    {
      title: "Status",
      dataIndex: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      key: "action",
      render: (text, record) => (
        <span>
          <Authorize moduleId={3} permissions="can_update">
            <Button
              type="link"
              onClick={() => {
                setOpen(true);
                setCategory(record);
              }}
            >
              Edit
            </Button>
          </Authorize>
          <Authorize moduleId={3} permissions="can_delete">
            <Button
              type="link"
              onClick={() => {
                showConfirm(record.id, handleDelete);
              }}
            >
              Delete
            </Button>
          </Authorize>
        </span>
      ),
    },
  ];
  if (localStorage.getItem("userTypeId") == "1") {
    columns.unshift({ title: "Merchant Name", dataIndex: "merchant_name" });
  }
  // const data = categories.map(category => ({
  //   ...category,
  // }))
  return (
    // <div>
    //   <div style={{ display: "flex", justifyContent: "space-between" }}><h2 className="title gx-mb-4"><IntlMessages id="sidebar.category" /></h2>
    //     <Button type="primary"
    //       onClick={() => {
    //         setOpen(true);
    //       }} size="small">Add</Button>
    //   </div>
    //   <Widget styleName="gx-order-history"
    //     title={
    //       <h2 className="h4 gx-text-capitalize gx-mb-0">
    //         Category Listing</h2>
    //     } extra={
    //       <p className="gx-text-primary gx-mb-0 gx-pointer">Details</p>
    //     }>

    //     <div className="gx-table-responsive">
    //       <Table className="gx-table-no-bordered" columns={columns} dataSource={data} pagination={false} bordered={false}
    //         size="small" />
    //     </div>
    //     <AddCategoryModal
    //       open={open}
    //       onCreate={onCreate}
    //       onCancel={() => {
    //         setOpen(false);
    //       }}
    //     />
    //   </Widget>
    // </div >
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Categories List</h2>
        <Authorize moduleId={3} permissions="can_create">
          <Button
            style={{ marginRight: "1px" }}
            type="primary"
            onClick={() => {
              setOpen(true);
              setCategory(null);
            }}
          >
            Add Category
          </Button>
        </Authorize>
      </div>
      <Table
        dataSource={categories}
        columns={columns}
        rowKey={(record) => {
          return record.id;
        }}
      />
      <AddCategoryModal
        open={open}
        setOpen={setOpen}
        category={category}
        setCategory={setCategory}
        onCreate={handleCreate}
        onCancel={() => setOpen(false)}
      />
    </div>
  );
};

export default Category;
