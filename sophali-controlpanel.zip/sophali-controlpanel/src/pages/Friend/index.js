import React, { useEffect, useState } from "react";
import { Table, Button, Form, Modal, InputNumber, Input } from "antd";
import axios from "axios";
import Link from "antd/lib/typography/Link";
import { useSnackbar } from "notistack";

const ShareTokensModal = ({
  openShare,
  setOpenShare,
  friend,
  setFriend,
  onCreate,
  onCancel,
}) => {
  const [form] = Form.useForm();
  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(friend || {});
  }, [friend, form]);

  return (
    <Modal
      forceRender
      open={openShare}
      title="Send Tokens"
      okText="Send"
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setFriend(null);
      }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
            setOpenShare(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Form.Item
          name="amount_cad"
          label="Amount in CAD"
          rules={[
            {
              required: true,
              message: "Please Enter Amount in CAD!",
            },
          ]}
        >
          <InputNumber min={1} max={10000} step={5} />
        </Form.Item>
      </Form>
    </Modal>
  );
};
const AddBuddyModal = ({
  openAdd,
  setOpenAdd,
  friend,
  setFriend,
  onCreate,
  onCancel,
  getUserByEmail,
}) => {
  const [form] = Form.useForm();

  useEffect(() => {
    form.resetFields();
    form.setFieldsValue(friend || {});
  }, [friend, form]);

  return (
    <Modal
      forceRender
      open={openAdd}
      title="Add Buddy"
      okText="Add"
      cancelText="Cancel"
      onCancel={() => {
        form.resetFields();
        onCancel();
        setFriend(null);
      }}
      okButtonProps={{ disabled: friend ? false : true }}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(friend);
            setOpenAdd(false);
          })
          .catch((info) => {
            console.info("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="form_in_modal"
        labelCol={{
          span: 6,
          style: { textAlign: "left" },
        }}
        wrapperCol={{
          span: 18,
        }}
      >
        <Link
          style={{
            display: "flex",
            flexDirection: "row-reverse",
            padding: "5px 5px 5px",
          }}
        >
          verify user
        </Link>
        <Form.Item
          name="email"
          label="Email"
          rules={[
            {
              required: true,
              message: "Please Enter Email!",
            },
          ]}
        >
          <Input onBlur={getUserByEmail} />
        </Form.Item>
        <Form.Item name="name" label="Name">
          <Input disabled={true} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

const Friend = () => {
  const [friends, setFriends] = useState([]);
  const [friend, setFriend] = useState(null);
  const [openShare, setOpenShare] = useState(false);
  const [openAdd, setOpenAdd] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const basePath = process.env.REACT_APP_API_URL;
  useEffect(() => {
    fetchFriends();
  }, []);
  const fetchFriends = async () => {
    try {
      const result = await axios.post(`${basePath}/users/getAllFriends`, {
        user_id: localStorage.getItem("userId"),
      });
      setFriends(result.data.userFriends);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const getUserByEmail = async (e) => {
    let email = e.target.value;
    try {
      const result = await axios.post(`${basePath}/users/search`, {
        email,
      });
      result.data.users.rows[0].name = `${
        result.data.users.rows[0].first_name
      } ${result.data.users.rows[0].last_name || ""}`;

      enqueueSnackbar("User fetched successfully", {
        variant: "success",
      });
      if (result.data.users.count > 0) {
        setFriend(result.data.users.rows[0]);
      }
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const handleRemove = async (values) => {
    try {
      let obj = {
        user_id: values.id,
        friend_id: localStorage.getItem("userId"),
      };
      await axios.post(`${basePath}/users/removefriend`, obj);
      const result = await axios.post(`${basePath}/users/getAllFriends`, {
        user_id: localStorage.getItem("userId"),
      });
      enqueueSnackbar("Friend removed successfully", {
        variant: "success",
      });
      fetchFriends();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const handleAdd = async (values) => {
    try {
      let obj = {
        user_id: localStorage.getItem("userId"),
        friend_id: values.id,
      };
      await axios.post(`${basePath}/users/addfriend`, obj);
      const result = await axios.post(`${basePath}/users/getAllFriends`, {
        user_id: localStorage.getItem("userId"),
      });
      enqueueSnackbar("Friend added successfully", {
        variant: "success",
      });
      fetchFriends();
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };
  const handleShare = async (values) => {
    try {
      let obj = {
        user_id: friend.id,
        sender_user_id: localStorage.getItem("userId"),
        helcium_transation_id: null,
        amount_cad: values.amount_cad,
        amount_cad: values.amount_cad,
        sophali_token_balance: values.amount_cad,
        status: friend.status,
      };
      const result = await axios.post(`${basePath}/usertoken/transfer`, obj);
      enqueueSnackbar("Tokens shared successfully", {
        variant: "success",
      });
      // setFriends(result.data.userFriends);
    } catch (error) {
      enqueueSnackbar(error.response.data.message, { variant: "error" });
      console.error(error);
    }
  };

  const columns = [
    {
      title: "First Name",
      dataIndex: "first_name",
      key: "first_name",
    },
    {
      title: "Last Name",
      dataIndex: "last_name",
      key: "last_name",
    },
    {
      title: "Username",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Mobile",
      dataIndex: "mobile",
      key: "mobile",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => {
        return <span className="gx-text-red">{text}</span>;
      },
    },
    {
      title: "Actions",
      dataIndex: "action",
      key: "action",
      render: (text, record) => (
        <span>
          <Button
            type="link"
            onClick={() => {
              handleRemove(record);
            }}
          >
            Remove buddy
          </Button>
          {record.friend_id && (
            <Button
              // const ...
              type="link"
              onClick={() => {
                setOpenShare(true);
                setFriend(record);
              }}
            >
              Share Tokens
            </Button>
          )}
        </span>
      ),
    },
  ];

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <h2 style={{ marginLeft: "2px" }}>Buddy List</h2>
        <Button
          style={{ marginRight: "1px" }}
          type="primary"
          onClick={() => {
            setOpenAdd(true);
            setFriend(null);
          }}
        >
          Add Buddy
        </Button>
      </div>
      <Table
        dataSource={friends}
        columns={columns}
        rowKey={(record) => record.id}
      />
      <ShareTokensModal
        openShare={openShare}
        setOpenShare={setOpenShare}
        friend={friend}
        setFriend={setFriend}
        onCreate={handleShare}
        onCancel={() => setOpenShare(false)}
      />
      <AddBuddyModal
        getUserByEmail={getUserByEmail}
        openAdd={openAdd}
        setOpenAdd={setOpenAdd}
        friend={friend}
        setFriend={setFriend}
        onCreate={handleAdd}
        onCancel={() => setOpenAdd(false)}
      />
    </div>
  );
};

export default Friend;
